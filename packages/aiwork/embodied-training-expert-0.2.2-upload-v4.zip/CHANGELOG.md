# Changelog · embodied-training-expert

All notable changes to this AiWork expert plugin will be documented here.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/); versioning follows SemVer.

## [0.2.2] — 2026-09-07

### Changed（新增「代码与资产准备」环节）
- **第 0.5 步 代码与资产准备（硬门禁）**：专家提示词与 `training-orchestration` Skill 在环境检查（第 0 步）通过之后、执行 demo/预检/训练之前，新增代码与资产准备环节——从 `https://github.com/ant-research/Open-AoE` 克隆代码并固定 `git_sha`（同时作为可复现四要素之一）、安装依赖；按目标机器人 profile 拉取机器人本体与执行器（灵巧手/夹爪）URDF/MJCF 及 mesh 资产并逐一校验可解析；任一失败立即停止并如实报告。
- **defaultInitPrompt**：默认指令补充「环境确认可用后，先从 Open-AoE 仓库拉取代码与 URDF 资产，再执行 demo」。
- **硬性禁止** 新增：不得在代码与资产未就绪时开始 demo 或训练，不得绕过失败的克隆/依赖/资产校验。

## [0.2.1] — 2026-09-07

### Changed（开箱即跑默认指令 + 环境硬门禁）
- **defaultInitPrompt**：首条默认指令改为可直接运行的开箱任务——使用从 ModelScope 下载的 OpenAoE-2000h 样例数据（https://www.modelscope.cn/datasets/inclusionAI/OpenAoE-2000h）对 ACT 模型做 smoke train（小 batch、约 20 步、5–10 分钟内完成），并展示 loss 曲线。
- **环境检查（第 0 步，硬门禁）**：专家提示词与 `training-orchestration` Skill 新增「环境检查」环节——本包在 Linux + GPU 系统验证打包，任何执行类环节前先检查 `uname -s` 与 `nvidia-smi`；本机不适配（如 macOS）时停止本地执行，要求用户提供 Linux + GPU 服务器 SSH 信息，验证连通后所有命令在远程服务器执行。环境结论写入数据体检 JSON `environment` 字段。
- **硬性禁止** 新增：不得跳过环境检查直接生成或执行训练/预检命令，不得在本机不适配且无 SSH 目标时假装执行。

## [0.2.0] — 2026-09-07

### Changed（专家团 → 专家形态改造，功能不变）
- **产品形态**：`product.kind` 由 `expert-team` 改为 `expert`；包名由 `embodied-training-team` 更名为 `embodied-training-expert`。
- **单专家提示词**：`agents/embodied-training-expert.md` 合并原主专家（训练总监）与四位成员（数据分析师 / 配方推荐师 / 训练执行工程师 / 评测分析师）的全部职责、输出契约与硬性约束；9 步流水线、模型家族决策树、可复现四要素、命令交付契约与评测/失败分析 JSON 契约保持不变，由单一专家亲自端到端执行。"命令由专家生成、用户在自己算力上执行"的边界不变。
- **plugin.json**：`primary=embodied-training-expert`，`subagents=[]`。
- **manifest.json**：`display.members` 收敛为 1 位 `role=lead`；display 名称改为「具身模型训练专家 / Embodied Model Training Expert」；tags / quickPrompts / defaultInitPrompt 不变。
- **Skill**：5 个 Skill 全部保留，方法内容不变；仅把编排与描述文案中的"主专家/成员/委派"表述改为单专家阶段执行；与人类数据转换专家的补数据衔接协议保留。
- **资产**：移除 4 张成员头像，保留并重命名专家头像 `embodied-training-expert.png`。
- 校验：`tools/validate_plugin.py` 未改动，两个正样本 ✅ 通过。

### Removed
- 4 份子 agent markdown（`data-schema-analyst` / `recipe-recommender` / `training-runner` / `evaluation-analyst`），其职责与产出契约已并入单专家提示词。

## [0.1.1] — 2026-09-02

### Changed
- 成员显示名改为简明职位名：训练总监 / 数据分析师 / 配方推荐师 / 训练执行工程师 / 评测分析师（去掉了 0.1.0 的拟人代号）。

### Added
- 配套真跑实现包 `openaoe_e2e-0.1.1`（单独交付），提供可执行 CLI：`openaoe-train / openaoe-infer`，使本专家团可端到端产出 **真实模型 checkpoint（.pt）+ 训练 log（jsonl）+ 训练曲线（png）+ 模型调用说明**。
- 已在 Linux 服务器上真跑验证：在转换得到的 LeRobot v2.1 数据集上训练 ACT-lite（真 transformer 策略，672K 参数，100 步），loss 0.80→0.22，产出可加载的 best.pt/last.pt 与推理示例。

## [0.1.0] — 2026-09-02

### Added
- 首次交付，符合《技能/专家/专家团包结构规范 V2》。
- `plugin.json`：`primary=embodied-training-lead`，4 个 `subagents`。
- `manifest.json`：`product.kind=expert-team`，双语 display，含 tags / quickPrompts / defaultInitPrompt / members。
- 5 份 agent markdown：主专家（训练总监）+ 4 位成员（数据分析师 / 配方推荐师 / 训练执行工程师 / 评测分析师）。
- 5 个 Skill：
  - `training-orchestration`（主专家编排，含 9 步 checklist、模型家族决策树、可复现四要素）
  - `data-inventory-and-schema`（数据体检 + Schema 对齐）
  - `recipe-catalog`（VLA / WAM / WM / Latent-Action 首批 16 个 Recipe id）
  - `env-preflight-and-smoke`（预检模板 + smoke override + 故障排查）
  - `eval-and-failure-analysis`（离线 + LIBERO/Meta-World/Isaac + 真机清单 + 失败三类）
- 命令交付契约：所有训练与评测命令供用户在自有算力执行。

### Known Limits
- 首版 Recipe references 尚未展开到每个 recipe 的独立文件；`references/recipes/<id>.md` 将在 0.2 补齐。
- 未包含 `commands/` 与 `hooks/`（V2 未生效，不得打包）。
- 未包含 `mcp.json`（v0 不引入远端任务提交，全部用户自执行）。
- 部分 Recipe 权重（π0.5、GR00T N1.7）需要用户自行取得上游授权。
