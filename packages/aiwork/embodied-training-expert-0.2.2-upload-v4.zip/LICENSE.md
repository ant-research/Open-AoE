# License

Copyright 2026 Ant Tianji Lab (OpenAoE Contributors)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this plugin except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

## Component licenses

This plugin bundles or references the following components; each retains its
own license. Consumers must respect the strictest applicable terms.

| Component | Origin | License |
| --- | --- | --- |
| Plugin code (agents, skills, manifests) | This repo | Apache-2.0 |
| Skill script copies under `skills/*/scripts/` | OpenAoE (github.com/ant-research/Open-AoE) | Apache-2.0 |
| ACT / Diffusion Policy code | Upstream repos | check upstream (mostly MIT / Apache-2.0) |
| π0.5 / π0.5-lite weights | Physical Intelligence | check upstream |
| SmolVLA weights | Hugging Face | Apache-2.0 (weights: check upstream card) |
| GR00T N1.7 weights | NVIDIA | NVIDIA license — user must obtain authorization |
| H-RDT / VITRA | Upstream | check upstream |
| WAM/WM family (DreamZero, LingBot-VA, Ctrl-World, iVideoGPT, GenieRedux, LAOM, AdaWorld, DreamDojo) | Various | check each upstream |
| LIBERO / Meta-World benchmarks | Upstream | MIT / research-only (per bench) |
| Isaac Sim / Isaac Lab | NVIDIA | NVIDIA Omniverse license |
| Datasets used for training | End-user provided | End-user terms |

The presence of a component here does not grant additional rights beyond its
own license. Users are responsible for confirming that pretraining weights,
benchmarks, simulators, and datasets can be used lawfully in their target
scenario (research / non-commercial / commercial).
