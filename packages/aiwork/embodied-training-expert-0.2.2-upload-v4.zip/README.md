# 具身模型训练专家 · Embodied Model Training Expert

一个 AiWork Agent Plugin（`product.kind: expert`），把 Ego / UMI / 真机 / 公开 / 仿真数据自动用于具身模型（VLA / WAM / WM）训练与评测。**所有训练与评测命令由本专家生成，由用户在自己的算力上执行。**

> v0.2.0 起由「专家团」（expert-team，1 主 + 4 子）改造为「专家」（expert，单一专家）：原主专家与四位成员（数据分析师 / 配方推荐师 / 训练执行工程师 / 评测分析师）的职责、输出契约与硬性约束全部合并进单一专家提示词，由一位专家端到端亲自执行，功能与交付物不变。

## 专家能力

| 阶段 | 职责 |
| --- | --- |
| 流水线编排 | 9 步流水线计划、跨阶段核验、迭代裁决 |
| 数据与 Schema 分析 | 数据盘点、Schema 对齐、混合建议 |
| Recipe 推荐 | 从 Recipe Catalog 选 2–3 个候选（含降级路径） |
| 训练命令生成 | 预检、smoke test、训练命令、实验跟踪配置 |
| 评测与失败分析 | 离线/仿真/真机评测、失败聚类、迭代建议 |

## 目录结构

```
embodied-training-expert/
├── .aiwork-plugin/
│   ├── plugin.json
│   └── manifest.json
├── agents/                 # 1 份专家 markdown（单专家端到端）
├── skills/                 # 5 个 Skill
│   ├── training-orchestration/
│   ├── data-inventory-and-schema/
│   ├── recipe-catalog/
│   ├── env-preflight-and-smoke/
│   └── eval-and-failure-analysis/
├── assets/avatars/
├── README.md
├── CHANGELOG.md
└── LICENSE.md
```

## 安装

见交付目录中的 `INSTALL.md`。

## 使用示例

- "我有 200 小时 Ego 数据和 20 小时真机数据，推荐一个预训练加微调方案。"
- "检查这批 LeRobot 数据能不能训练 SmolVLA，先给我一个 smoke test 命令。"
- "比较 ACT、Diffusion Policy 和一个 VLA 模型在同一数据上的成本与效果。"
- "分析这次训练为什么 loss 正常但仿真成功率很低。"
- "找出模型失败最多的任务，并给出应该补采哪些数据的建议。"

## 边界

- 本专家**不代替用户执行训练**：产出的都是可直接复制的命令、预检脚本、smoke test、评测方案。
- 训练必须先跑 smoke test；正式训练前必须绑定 `git_sha / data_version / config_hash / seed` 四要素。
- 真机评测必须先通过安全清单（限位、速度、碰撞、软/硬急停、人工审批）。
- 只报 loss 不算训练成功。

## 覆盖的 Recipe 家族

- **VLA**：ACT、Diffusion Policy、π0.5-lite、π0.5、SmolVLA、GR00T N1.7、H-RDT、VITRA
- **WAM**：DreamZero、LingBot-VA、Ctrl-World、iVideoGPT
- **WM / Latent-Action**：GenieRedux、LAOM、AdaWorld、DreamDojo

首批共 16 个 Recipe id 在 `skills/recipe-catalog/` 中登记；新增 Recipe 需以补充 `references/recipes/<id>.md` 的形式加入。

## 依赖与许可

- 本包遵循 **Apache License 2.0**（见 `LICENSE.md`）。
- 训练权重、数据集、仿真基准各自遵循上游许可，见 `LICENSE.md` "Component licenses" 章节。
- 首批 Recipe 中，部分权重（π0.5、GR00T N1.7）可能需上游授权。

## 版本

见 `CHANGELOG.md`。当前 `0.2.0`（专家团 → 专家形态改造，功能不变）。

## 校验

```bash
python3 tools/validate_plugin.py plugins/embodied-training-expert
```
