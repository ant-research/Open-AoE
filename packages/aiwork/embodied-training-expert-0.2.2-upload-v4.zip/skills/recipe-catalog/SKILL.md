---
name: recipe-catalog
description: 具身模型训练 Recipe 目录。每个条目登记：模型家族、代码路径、超参默认、显存/时长预估、参考文献、已知风险。具身模型训练专家只能从此目录选，不得虚构。覆盖 VLA / WAM / WM / Latent-Action 四大家族，首批 12+ 条 Recipe。
version: 0.1.0
activation: auto
tags:
  - recipes
  - vla
  - world-model
  - wam
  - latent-action
---

# Recipe Catalog

**Recipe 目录**。每一个 Recipe 推荐必须能在这里找到条目。新增 Recipe 需以 PR 形式加入 `references/recipes/`。

## VLA 家族（预测动作）

### ACT
- **id**: `act`
- **适用**: 小数据（<10h 真机），单任务
- **观察窗**: 1；**动作段**: 100
- **显存**: 12 GB；**单卡**: 4–8 h
- **references**: `references/recipes/act.md`

### Diffusion Policy
- **id**: `diffusion_policy`
- **适用**: 10–100h，单/多任务
- **观察窗**: 2；**动作段**: 16
- **显存**: 24 GB；**单卡**: 24–48 h
- **references**: `references/recipes/diffusion_policy.md`

### π0.5-lite
- **id**: `pi05_lite`
- **适用**: 30–200h，多任务
- **显存**: 40 GB；**多卡**（2×A100 起）: 36 h
- **references**: `references/recipes/pi05_lite.md`

### π0.5
- **id**: `pi05`
- **适用**: >100h + Ego 混合
- **显存**: 80 GB；**多卡**（4×A100 起）: 96 h
- **risks**: 单卡 <80GB 显存不适用；权重许可需确认
- **references**: `references/recipes/pi05.md`

### SmolVLA
- **id**: `smolvla`
- **适用**: 10–100h，多任务，资源受限
- **显存**: 16 GB；**单卡**: 12–24 h
- **references**: `references/recipes/smolvla.md`

### GR00T N1.7
- **id**: `groot_n17`
- **适用**: >200h，跨本体
- **显存**: 80 GB；**多卡**（8×A100）: 120 h
- **risks**: 权重需 NVIDIA 授权
- **references**: `references/recipes/groot_n17.md`

### H-RDT
- **id**: `hrdt`
- **适用**: 双臂人形，>100h
- **显存**: 48 GB；**多卡**（4×A100）: 96 h
- **references**: `references/recipes/hrdt.md`

### VITRA
- **id**: `vitra`
- **适用**: 视觉-触觉-动作联合
- **references**: `references/recipes/vitra.md`

## WAM 家族（动作条件视频）

### DreamZero
- **id**: `dreamzero`
- **适用**: 视频 + 动作对，无需真机
- **references**: `references/recipes/dreamzero.md`

### LingBot-VA
- **id**: `lingbot_va`
- **references**: `references/recipes/lingbot_va.md`

### Ctrl-World
- **id**: `ctrl_world`
- **references**: `references/recipes/ctrl_world.md`

### iVideoGPT
- **id**: `ivideogpt`
- **references**: `references/recipes/ivideogpt.md`

## WM / Latent-Action 家族

### GenieRedux
- **id**: `genie_redux`
- **references**: `references/recipes/genie_redux.md`

### LAOM
- **id**: `laom`
- **references**: `references/recipes/laom.md`

### AdaWorld
- **id**: `adaworld`
- **references**: `references/recipes/adaworld.md`

### DreamDojo
- **id**: `dream_dojo`
- **references**: `references/recipes/dream_dojo.md`

## Recipe 条目字段规范

每份 `references/recipes/<id>.md` 必须包含：

```yaml
id: <string>
family: vla | wam | wm | latent_action
stages: [pretrain, finetune, sft, lora, ...]
observation: {cameras: <int>, fps: <int>, window: <int>}
action: {horizon: <int>, coordinate: <str>, delta_or_absolute: <str>}
hparams: {bs: <int>, lr: <float>, steps: <int>, optimizer: <str>, warmup: <int>}
resources: {vram_gb: <int>, single_gpu_hours: <int>, multi_gpu: {gpus: <int>, hours: <int>}}
code_path: <openaoe subpath or upstream repo@sha>
pretrained_weights: {url: <str>, size_gb: <int>, license: <str>} | null
risks: [<str>]
references: [<url or doc>]
```

## 硬约束

- Recipe 只能从此目录选；虚构的 id 一律拒绝。
- Recipe 版本升级需在 `CHANGELOG.md` 中记录。
- 每个条目必须能追溯到具体代码路径与文献。
