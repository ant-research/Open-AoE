---
name: eval-and-failure-analysis
description: 具身模型评测方法与失败聚类。覆盖离线指标、仿真基准（LIBERO / Meta-World / Isaac）、真机评测清单、失败样本的三类分析（感知/决策/执行）与迭代建议生成。具身模型训练专家在评测与失败分析阶段使用。
version: 0.1.0
activation: auto
tags:
  - evaluation
  - libero
  - meta-world
  - isaac
  - failure-analysis
---

# Evaluation & Failure Analysis

## 离线指标

### VLA
- **action_mse / action_mae**：分维度报告（arm vs hand 分开）。
- **action_kl**：预测分布 vs 数据分布（Diffusion Policy 常用）。
- **success_rate_on_val**：如果 val 集包含完整 episode，可算离线成功率。

### WAM
- **PSNR / SSIM / LPIPS**：预测帧质量。
- **FVD**：视频分布距离。
- **action_conditioning_fidelity**：给不同动作输入，预测画面差异是否符合物理。

### WM / Latent-Action
- **latent_action_consistency**：同一段视频反复编码，潜在动作稳定性。
- **downstream_probe**：用潜在动作训一个下游任务，看能否解码回真实动作。

## 仿真基准

| 基准 | 覆盖 | 命令模板 |
| --- | --- | --- |
| LIBERO-10 / LIBERO-90 | 桌面单臂多任务 | `python -m openaoe.eval.sim --bench libero_10 --ckpt <path>` |
| Meta-World MT10 / MT50 | 桌面单臂多任务 | `python -m openaoe.eval.sim --bench meta_world_mt10 --ckpt <path>` |
| Isaac Franka Kitchen | Isaac Sim 高保真 | `python -m openaoe.eval.sim --bench isaac_kitchen --ckpt <path>` |
| Isaac Humanoid | 人形 | `python -m openaoe.eval.sim --bench isaac_humanoid --ckpt <path>` |
| 企业自定义 | 需注册环境 | `python -m openaoe.eval.sim --bench custom:<name> --ckpt <path>` |

### 指标默认
- 每任务 20 次 rollout；报告 `success_rate ± std`。
- 鲁棒性变体：初始位置扰动、观察扰动、光照扰动，各 10 次。

## 真机评测清单

**任何真机评测启动前必须完成**：

- [ ] 关节位置限位软件保护开启
- [ ] 关节速度上限设置（通常为 max 的 30% 起步）
- [ ] 关节加速度上限设置
- [ ] 力矩上限设置
- [ ] 碰撞检测开启（自碰撞 + 环境碰撞）
- [ ] 软急停：模型输出监视器，异常动作触发暂停
- [ ] 硬急停：物理按钮，操作员手边
- [ ] 人工审批：每个新任务/新场景，操作员先看仿真回放
- [ ] 现场记录：多机位视频、力/触觉日志、任务成功判定人

### 分阶段
1. **桌面 sanity**：单一物体、无干扰、5 次成功再进阶。
2. **工作空间内**：加入干扰物、变换初始位置。
3. **全任务闭环**：完整任务流程，操作员保持能一键急停。

## 失败聚类三类

对失败 rollout，先按"失败发生的阶段"分：

- **感知失败**（perception）：模型看错或看不到关键物体。
  - 特征：目标物体处像素级看，模型注意力偏离；或光照/遮挡异常。
  - 建议：补数据（对应场景）、增数据增广、检查观察 Schema。
- **决策失败**（decision）：看对了但决定错。
  - 特征：动作序列朝错方向，或反复徘徊。
  - 建议：延长 action horizon、换更大模型、检查任务分布。
- **执行失败**（execution）：决策对了但物理没跟上。
  - 特征：目标点到位但抓取/开合时序偏。
  - 建议：调整控制频率、加入低层控制器、检查 action Schema 的 delta/absolute。

## 迭代建议模板

```json
{
  "action": "collect_more_data | change_representation | upgrade_model | tune_curriculum",
  "target": "<具体任务或场景>",
  "detail": "<具体如何做>",
  "estimated_cost": "<GPU 小时 或 数据小时>",
  "expected_gain": "<预期提升区间>"
}
```

## References

- `references/libero-usage.md` — LIBERO 环境配置
- `references/isaac-lab-usage.md` — Isaac Lab 快速上手
- `references/real-robot-checklist.md` — 真机安全清单完整版
- `references/failure-taxonomy.md` — 失败分类的详细示例
