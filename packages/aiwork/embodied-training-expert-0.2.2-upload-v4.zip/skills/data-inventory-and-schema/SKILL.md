---
name: data-inventory-and-schema
description: 具身数据盘点与 observation/state/action Schema 对齐方法。覆盖 OpenAoE Ego、UMI、LeRobot、Open X-Embodiment、DROID、企业私有与仿真数据的常见 Schema 差异、对齐操作与混合训练建议。具身模型训练专家在数据盘点与 Schema 对齐阶段使用。
version: 0.1.0
activation: auto
tags:
  - dataset-inventory
  - schema-alignment
  - lerobot
  - open-x-embodiment
---

# Data Inventory & Schema Alignment

## 数据形态速览

| 形态 | 关键特征 | 典型 action Schema |
| --- | --- | --- |
| OpenAoE Ego | 头戴/胸戴/手机，含 MANO 或关键点 | joint_position 或 eef_pose（视目标 profile） |
| UMI | 手持夹爪 + 相机 + IMU | eef_pose + gripper_open |
| LeRobot 真机 | 遥操作或自主，含视频+状态+动作 | joint_position 或 eef_delta（各仓库不同） |
| Open X-Embodiment | 22+ 机构、多机器人 | 混杂，需 per-shard 解析 |
| DROID | Franka 单臂大规模 | eef_delta（7 维） |
| 企业私有 | 视厂商而定 | 视厂商而定 |
| 仿真合成 | Isaac / MuJoCo / Sapien | 与真机 profile 一致或简化 |

## 8 项体检

对每个数据集依次过：

1. **规模**：总时长、片段数、任务分布、语言标注覆盖率。
2. **观察**：相机数、分辨率、fps、模态（RGB / 深度 / 触觉 / 力）。
3. **状态**：state 向量维度、关节顺序、单位、坐标系。
4. **动作**：action 维度、坐标（joint_position / eef_pose / eef_delta）、绝对/增量、单位、控制频率。
5. **时序同步**：相机、状态、动作时间戳是否严格对齐。
6. **任务描述**：是否有 language；有则统计长度分布。
7. **失败样本**：是否已标注失败；失败比例。
8. **许可**：可否用于训练、可否商用。

## Schema 对齐操作

### joint_position ↔ eef_pose
- joint_position → eef_pose：正运动学，直接算。
- eef_pose → joint_position：需 IK，注意奇异位形；用上一帧解 warm start。

### absolute ↔ delta
- absolute → delta：一阶差分。
- delta → absolute：累积积分，容易漂移；用状态锚定（每 N 步用真实 state 复位）。

### 单位与坐标系
- 单位不一致（rad vs deg，m vs mm）：批量线性变换。
- 坐标系不一致（robot_base vs world vs camera）：需机器人外参；缺则不建议对齐。

## 混合训练建议

| 情况 | 建议 |
| --- | --- |
| 同机器人 profile + 相同 action Schema | 直接混训 |
| 同机器人 + Schema 可对齐 | 对齐后混训，标注来源 |
| 不同机器人 + 相同任务空间 | 用跨本体模型（GR00T / RDT）或 embodiment token |
| 不同机器人 + 不同任务 | 建议分开预训练，共享 backbone |
| Ego 人类数据 + 真机数据 | 用作预训练，微调时以真机为主 |

## References

- `references/lerobot-schema.md` — LeRobot 常见 Schema 变体
- `references/open-x-embodiment.md` — OXE 数据集清单与差异
- `references/schema-align-recipes.md` — 常见对齐操作命令示例
