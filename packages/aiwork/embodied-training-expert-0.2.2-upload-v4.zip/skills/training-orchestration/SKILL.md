---
name: training-orchestration
description: 具身模型训练专家的编排 Skill，包含 9 步流水线 checklist、模型家族决策树、可复现性四要素、命令交付契约与与人类数据转换专家的衔接协议。具身模型训练专家（embodied-training-expert）使用。
version: 0.1.0
activation: auto
release_default: "on"
tags:
  - orchestration
  - training
  - pipeline
---

# Training Orchestration

具身模型训练专家的作战手册。**常驻加载**。

## 1. 9 步流水线 checklist

| 步 | 执行 | 输入 | 产出 | 通过条件 |
| --- | --- | --- | --- | --- |
| 0 环境检查（硬门禁） | 专家本人 | 本机或 SSH 目标 | 环境结论（OS / GPU / execution_host） | `uname -s` = Linux 且 `nvidia-smi` 可用；否则停止本地执行，向用户索取 Linux + GPU 服务器的 SSH 信息，验证连通后所有命令在远程执行 |
| 0.5 代码与资产准备（硬门禁） | 专家本人 | 步 0 确认的执行主机 | Open-AoE 仓库（固定 git_sha）+ 目标机器人/执行器 URDF 资产 | 克隆 `https://github.com/ant-research/Open-AoE` 并固定 commit、依赖安装完成；目标 profile 的 URDF/MJCF 与 mesh 齐全且可解析；任一失败立即停止并报告 |
| 1 定义目标 | 专家本人 | 用户对话 | 模型家族 + 目标机器人 + 任务集 + 预算 | 四项齐备，缺任一必须回问 |
| 2 数据盘点 | 专家本人 | 数据路径 | 数据体检 + 混合建议 | 至少 1 个可用数据集 |
| 3 Schema 对齐 | 专家本人 | 体检结论 | 对齐后的统一 Schema 描述 | 目标模型家族与 Schema 兼容 |
| 4 Recipe 推荐 | 专家本人 | 数据 + 机器人 + GPU + 预算 | 2–3 个候选 Recipe + 降级路径 | 每个 Recipe 可追溯到 `recipe-catalog` |
| 5 环境预检 | 专家本人 | 选定 Recipe + 用户环境 | preflight 脚本 + 预检结果 | ALL PREFLIGHT CHECKS PASSED |
| 6 训练命令 | 专家本人 | 预检通过 | smoke test + 正式训练命令 | smoke 5–10 分钟内通过 |
| 7 离线/仿真评测 | 专家本人 | checkpoint | 评测方案 + 命令 | 至少 1 项行为指标 |
| 8 真机评测 | 专家本人 | checkpoint + 真机资源 | 真机清单 + 分阶段计划 | 清单完整、有 kill switch |
| 9 失败分析 | 专家本人 | 评测日志 | 失败聚类 + 迭代建议 | 建议可追踪到具体动作 |

## 2. 模型家族决策树

```
输入：数据形态 + 数据规模 + 目标
├─ 目标是"直接控制机器人"（预测动作）
│   ├─ < 5h 真机 → ACT / Diffusion Policy
│   ├─ 10–100h → Diffusion Policy / SmolVLA / π0.5-lite
│   └─ >100h + Ego 混合 → π0.5 / GR00T / H-RDT / VITRA
├─ 目标是"预测未来画面"（动作条件视频）
│   └─ WAM 家族：DreamZero / LingBot-VA / Ctrl-World / iVideoGPT
└─ 目标是"学习环境规律 / 潜在动作"
    └─ WM / Latent-Action：GenieRedux / LAOM / AdaWorld / DreamDojo
```

## 3. 可复现性四要素

任何一次训练命令交付必须绑定：

- `git_sha`（代码版本）
- `data_version`（数据集版本或 hash）
- `config_hash`（配置文件 sha256）
- `seed`（随机种子，显式指定）

## 4. 命令交付契约

交给用户的每一段命令必须写清楚：

- **前置条件**：Python/CUDA/PyTorch 版本、依赖包、权重文件、数据路径。
- **执行环境**：单机/多机、单卡/多卡、启动方式（`python -m` / `torchrun` / `accelerate`）。
- **预估资源**：显存峰值、单卡时长、总 GPU 小时、磁盘用量。
- **产物路径**：checkpoint、日志、评测报告的目标目录。
- **成功判定**：什么日志片段/指标出现算 smoke 通过、算训练完成。

## 5. 与人类数据转换专家的衔接

失败分析（步 9）给出"应补数据"时，专家应生成一份「补数据请求单」，格式：

```yaml
purpose: "补充低光照 pick_place 数据 5 小时"
target_robot_profile: "g1_inspire_v1"
task_language: "..."
required_hours: 5
constraints: ["低光照", "红杯子", "多角度"]
downstream_recipe: "diffusion_policy_g1_inspire"
```

用户可以把这份请求单发给人类数据转换专家，或转交给数据采集流程。

## 6. 硬约束

- 步 0 未通过（本机非 Linux + GPU 且无可用 SSH 目标）：拒绝生成任何执行类命令，不得假装执行。
- 步 0.5 未通过（Open-AoE 代码或机器人/执行器 URDF 资产未就绪）：拒绝进入预检与训练，不得绕过。
- 步 2 未通过：拒绝进入步 4。
- 步 5 未通过：拒绝生成步 6 命令。
- 步 6 未跑 smoke：拒绝给正式训练命令。
- 步 8 无清单：拒绝建议真机执行。
- 只报 loss：拒绝声明训练成功。

## References

- `references/family-decision-tree.md` — 决策树详版
- `references/reproducibility-checklist.md` — 四要素记录规范
- `references/handoff-with-conversion-team.md` — 与人类数据转换专家的补数据协议
