---
name: env-preflight-and-smoke
description: 训练环境预检与 smoke test 方法论。产出预检脚本模板、smoke test 参数默认值、常见失败与修复清单。具身模型训练专家在预检与 smoke 阶段使用；命令由用户在自己算力上执行。
version: 0.1.0
activation: auto
tags:
  - preflight
  - smoke-test
  - environment
requires:
  bins:
    - python3
---

# Env Preflight & Smoke Test

## 预检清单

预检脚本 `preflight.sh` 必须至少覆盖以下 8 项。任一项失败即 FAIL，并给出修复建议。

```bash
# 1. Python & CUDA
python3 --version
nvcc --version 2>/dev/null || echo "cuda toolkit missing"
python3 -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available(), 'devices', torch.cuda.device_count())"

# 2. 关键依赖 import
python3 - <<'PY'
mods = ["torch", "lerobot", "hydra", "einops", "diffusers", "wandb"]
for m in mods:
    try:
        __import__(m); print("OK", m)
    except Exception as e:
        print("MISS", m, e)
PY

# 3. GPU 显存实测
python3 - <<'PY'
import torch
if torch.cuda.is_available():
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        print(f"gpu {i}: {p.name} {p.total_memory/1e9:.1f} GB")
PY

# 4. 数据路径可读
ls -la "$DATA_ROOT" >/dev/null && echo "OK data_root" || echo "FAIL data_root"

# 5. 数据版本 hash（示例）
find "$DATA_ROOT" -type f -name "*.parquet" | head -20 | xargs -I{} sha256sum {} | sort | sha256sum

# 6. 预训练权重
[ -f "$PRETRAINED_CKPT" ] && sha256sum "$PRETRAINED_CKPT" || echo "no pretrained (may be ok)"

# 7. 磁盘剩余
df -h "$OUT_ROOT"

# 8. 网络与 wandb
python3 -c "import wandb; print('wandb', wandb.__version__)"
```

## Smoke Test 默认参数

在 Recipe 的正式配置基础上覆盖：

```yaml
# smoke override
train.steps: 20
train.batch_size: 2          # 或 Recipe 默认的 1/16
train.log_every: 1
train.eval_every: 999999     # smoke 不做 eval
data.subset_size: 32         # 只取 32 条样本
wandb.mode: offline          # smoke 不上传
```

## Smoke 成功判定

必须同时满足：

1. 5–10 分钟内跑完（不含数据首次下载）。
2. 前 20 步 loss 有下降（哪怕微小）。
3. 无 CUDA OOM、无 NaN、无 hang。
4. Checkpoint 目录被创建。
5. 日志文件不为空。

## 常见失败与修复

| 症状 | 原因 | 修复 |
| --- | --- | --- |
| CUDA OOM | batch size 太大 / Recipe 不匹配显存 | 降 bs、开梯度累积、换更小 Recipe |
| loss NaN | lr 太高 / 数据异常 | 降 lr、加 grad clip、检查数据 |
| DataLoader hang | num_workers 太大 / 数据路径慢 | 降 num_workers、预热磁盘缓存 |
| DDP 卡在初始化 | 端口冲突 / NCCL 配置 | 换 `--master_port`、检查 `NCCL_DEBUG=INFO` |
| wandb login 失败 | 无网络 / token 未配置 | `wandb offline` 或 `WANDB_MODE=disabled` |
| 权重下载失败 | 网络受限 | 手动下载放到 `PRETRAINED_CKPT` |

## 分布式启动建议

```bash
# 单机多卡
torchrun --nproc_per_node=$NGPU --master_port=29500 -m <trainer> <args>

# 多机（示例，2 机 × 8 卡）
torchrun --nnodes=2 --node_rank=$RANK \
  --master_addr=$MASTER_IP --master_port=29500 \
  --nproc_per_node=8 -m <trainer> <args>
```

## References

- `references/preflight-template.sh` — 完整预检脚本
- `references/smoke-configs/` — 各 Recipe 的 smoke override yaml
- `references/troubleshooting.md` — 更多故障案例
