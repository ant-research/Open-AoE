---
name: openaoe-data-ops
description: "OpenAoE-2000h 第一人称数据集的检索、质检、可视化与子集下载全流程工具（ModelScope inclusionAI/OpenAoE-2000h）。适用于：'从 OpenAoE 筛选数据'、'OpenAoE 数据质检/质量检查'、'按 kitchen 场景/时长/机型/任务/FOV/分辨率/手别/置信度筛选样本'、'下载数据子集/样本'、'第一人称/ego/具身数据集分析、概览、可视化'、'渲染官方级单样本审阅视频（MANO 手部叠加+标注面板+3D 世界系）' 等任务。能力：全量元数据索引（23k+ 样本，版本化水位/增量更新）、多维组合筛选、L1 全量元数据 + L2 抽样 npz 分层质检、维度分布与样本卡片可视化、官方 aoe-visualization 逐样本端到端渲染视频（速度可调）、按类别 sha256 校验断点续传下载与血缘 manifest。边界：只读数据集（不上传/不写回）；不含模型训练与重靶标代码；MANO 衍生文件许可隔离见 references/license-notes.md。"
version: "1.0.0"
tags:
  - dataset
  - quality-check
  - filter
  - visualization
  - download
  - embodied
  - egocentric
requires:
  bins:
    - python3
  tools:
    - shell
---

# OpenAoE Data Ops — 第一人称数据集（OpenAoE-2000h）筛选/质检/可视化/子集下载

以 ModelScope `inclusionAI/OpenAoE-2000h`（约 700h+/2000h，23,640+ 样本持续上传）为对象，
一条命令链完成：**索引 → 多维筛选 → 分层质检 → 可视化 → 类别化子集下载（含血缘 manifest）**。
所有操作只读远端（不做上传/写回），本地工作目录约定 `.cache/`（索引与临时缓存）、`data/`（下载数据）、
`figures/`（图表）、`qc_report.md/qc.parquet`（质检产物）。

## Execution Mode

**Script Chain（单会话直跑）** — 由 orchestrator 或用户按六阶段工作流串行调用
`scripts/` 下 6 个 CLI（无子智能体、无 MCP 依赖）。**token 可选**：公开数据集
支持匿名访问（2026-09 实测 meta/tree/下载含 LFS 均放行，开箱即用）；`.env` /
环境变量 token 仅作鉴权兜底与限流缓解，读取后绝不打印。

依赖：python3 + requests + pandas + pyarrow + matplotlib + numpy（标准沙箱即装即用）。
**深检渲染（可选阶段）**额外需要 opencv-python + pyrender + trimesh + PyOpenGL
（GL 不可用时官方渲染自动降级 NumPy flat-shaded）+ 系统 ffmpeg（可选，H.264 转码）+
一次性 MANO 模型（注册下载 pkl 后 `render_videos.py --convert-mano` 转换，见
vendor/aoe-vis/NOTICE-vendor.md）。

Agent 沙箱纪律：**生成脚本/文件一律用 write 工具**（exec/shell 只负责运行）；
exec + heredoc / 重定向写文件会被安全策略拒绝。

## Workspace 约定

| 路径 | 含义 | 生成者 |
| --- | --- | --- |
| `.cache/openaoe_index.parquet` (+`.state.json`) | 全量元数据索引（一行一样本）+ 断点/版本水位 | build_index.py |
| `.cache/l2/<sample>/` | L2 深检 npz 缓存（可复用） | quality_check.py |
| `subset.json` | 筛选结果（filters/统计/样本列表） | filter.py |
| `qc_report.md` + `qc.parquet` | 分层质检报告 + 机器可读明细 | quality_check.py |
| `figures/` | 分布图/交叉热力图/样本卡片 + `_gallery.md` | visualize.py |
| `figures/videos/<sid>/AoE_output_vis.mp4` | 官方级单样本审阅视频 + `_gallery.md`（vendor 渲染） | render_videos.py |
| `data/openaoe_subset/` | 子集数据 + `_openaoe_manifest.json` + 署名 `ATTRIBUTION.md` | download_subset.py |

## Workflow（六阶段）

### Phase 0 需求澄清

把筛选意图转成维度清单。**先问用途再选深度**：

- 训练子集 → 需限定 scene/时长/机型均衡；L1 必跑 + 建议 L2 抽样（hands 有效性直接影响下游 retarget）
- 评估集 → 建议稳定排序（`--order id`）+ manifest 血缘 + 固定抽样种子说明
- 数据概览 → 只到 Phase 2/4（返回命中数与分布，不下载）
- 八个维度：场景 `scene` / 时长 `duration` / 机型 `brand,model` / 任务 `task=verb+object` /
  FOV / 分辨率 `resolution` / 手别 `hand` / 置信度 `confidence`
  （字段映射与批次差异兜底见 `references/dataset-schema.md`）
- token（可选）：数据集为公开仓库，**匿名可访问**（2026-09 实测 meta/tree/文件下载含
  LFS Range 均放行），无 token 开箱即用；高频访问或遇 401/403 时在 `.env` 写
  `token=ms-...`（或环境变量 `OPENAOE_MS_TOKEN`）。可用
  `python3 scripts/openaoe_client.py --meta` 单点验证（无 token 时提示匿名模式）

### Phase 1 索引（一次构建多次复用）

1. 检查 `.cache/openaoe_index.parquet` 是否存在且不过期：state 的 `revision.root_total` /
   `dataset_gmt_modified` 与当前 API 快照比对（数据集持续上传，数值增大 → 过期）
2. **预置 seed（优先路径）**：skill 包自带 `seed/` 目录（parquet+state 两件套，
   详见 `seed/README.md`），先复制到 .cache/ 再做一次增量，**免去 75 分钟全量构建**：
   ```bash
   cp seed/openaoe_index.parquet* .cache/
   python3 scripts/build_index.py --out .cache/openaoe_index.parquet --incremental
   ```
3. 缺失（也无 seed）→ 全量构建；过期/有新上传 → `--incremental`；中断 → 直接重跑（断点续跑到 state）
4. 全量成本约 95k 请求 / 0.5–1h（16 workers）；冒烟可用 `--limit 50`

```bash
python3 scripts/build_index.py --out .cache/openaoe_index.parquet --workers 16
```

> seed 两件套已随 skill 包内置（`seed/`）；索引构建产物落工作区 `.cache/`，且
> **增量写回不要指向 skill 包内的 seed/**（安装目录保持只读，先复制到工作区）。
> `--index` 可指向任意路径（需 state 文件同名相邻），也可直接只读引用
> `<skill 安装路径>/seed/openaoe_index.parquet`。

### Phase 2 筛选 + 预览（先看命中数，用户确认后再进入下载）

```bash
python3 scripts/filter.py --index .cache/openaoe_index.parquet \
    --scene kitchen --min-duration 60 --task "use+cup" --hand right --limit 20 \
    --out subset.json
```

`subset.json` 自带：每维度单独命中数（空结果时给放宽线索）、命中子集分布摘要
（scenes/verbs/objects/hands/duration 统计）。**先向用户返回命中统计**
（例："命中 137 个，场景分布 kitchen 89 / living room 48，确认下载前 20 个？"），
确认后进入 Phase 3/5。质量要求高时加 `--qc-pass`（把 L1 关键闸门前置到筛选阶段）。

**多层迭代筛选（R1 粗筛 → 看分布 → R2/R3 细筛）**：动词语义常宽于直觉（如 `stir`
覆盖搅汤/拌面/拌沙拉，非仅"炒菜"）。推荐分层收敛——粗维度宽进（verb/scene），
每轮看 verbs/objects 分布找方向，再用 `--from-subset` 在上轮命中内叠加条件：

```bash
# R1 粗筛：宽动词 + 场景（不带 --limit，保存完整命中集）
python3 scripts/filter.py --index .cache/openaoe_index.parquet \
    --scene kitchen --verb stir --out r1.json
# 细筛前先看上轮命中分布（不写文件；也支持不带 --from-subset 看全库 R0 概览）
python3 scripts/filter.py --index .cache/openaoe_index.parquet \
    --from-subset r1.json --preview-only
# R2 细筛：在上轮 740 个命中内叠加 object 收敛（例：只留锅具类样本）
python3 scripts/filter.py --index .cache/openaoe_index.parquet \
    --from-subset r1.json --object wok --object pan --min-avg-conf 0.9 --out r2.json
# R3 可继续 --from-subset r2.json …；每轮自动先打印上轮命中分布再打印本轮命中摘要，
# 各维度命中数分母 = 本轮输入集（上轮命中），方法学上与一次性组合筛选等价
```

> ⚠ 上轮若带 `--limit`/`--order random`，subset.json 只含抽出的 N 个（脚本会警告），
> 后续细筛仅作用于这 N 个——multi-round 收敛流程请在**末轮**才做随机抽样/限条数。

### Phase 3 质检（分层）

```bash
python3 scripts/quality_check.py --subset subset.json --level l1                        # L1 全量
python3 scripts/quality_check.py --subset subset.json --level both --sample-ratio 0.05  # + L2 抽样
```

- **L1（必跑，全量可行）**：标注时间/帧连续性、bbox 合法/越界、hand 枚举、置信度、
  内参-分辨率一致（上游 PR #1 移除样本的问题类型；裁决用 vi.fx↔uv.fov_x 真对齐对，
  广角/变焦样本跳过原始 fovH —— 语义细节见 references/dataset-schema.md §4.1）、
  畸变系数、元数据完整性 —— 只需 3 个小 JSON
- **L2（候选集大或用途敏感时）**：抽样下载 `hands.npz/camera_traj.npz`，查
  pred_valid 比例、帧数对齐（T vs 末段 end_frame）、focal 自洽、轨迹矩阵形状 ——
  全量约 70GB+ 不可行，按 `--sample-ratio`（默认 0.05）抽样
- 大子集快查可用 `--use-index`（0 请求，基于索引预计算 flag，规则粒度受限）
- 产物：`qc_report.md`（人读，规则通过率矩阵+建议）+ `qc.parquet`（机读，逐样本逐规则）

### Phase 4 可视化

```bash
python3 scripts/visualize.py --index .cache/openaoe_index.parquet \
    --dims scene,duration,verb,resolution,hand --cross scene,hand \
    --sample-cards 12 --out figures/
```

产出 `figures/dist_*.png`（单维分布）、`figures/cross_a__b.png`（交叉热力）、
`figures/sample_cards.png`（抽样下载样本库自带 overview.png 拼卡片）与 `figures/_gallery.md`。

**Phase 4b 深检渲染（官方级单样本视频，按需接入）** — vendor 的官方
`aoe-visualization`（`vendor/aoe-vis/`）渲染与官方 demo 完全一致的审阅视频
（ego 底片 + MANO 手部 mesh/骨架叠加 + 腕部轨迹 + 动作标注面板 + 世界系 3D +
时间轴）。质量审查 L2 的视觉复核手段，也可在下载后批量做：

```bash
python3 scripts/render_videos.py --subset subset.json --data-root data/openaoe_subset \
    --out figures/videos
```

- **自动补齐**：渲染必需 6 类别（annotation/video_info/undistorted_info/
  undistorted_video/hands/camera_traj）缺失时自动调 download_subset.py 幂等补下载
  （已下载文件自动跳过）；raw_video 作为底片兜底
- **速度旋钮**（用户要快就给出对应参数，默认=官方全参数画质）：
  `--stride 2`（隔帧，时长减半）｜ `--max-frames 450`（只渲染前 N 帧，推荐审查流
  "先渲开头 15s 判断质量"）｜ `--no-world`（关 3D 世界面板）｜ `--no-mesh`
  `--no-trails` `--no-keypoints`（逐项瘦身）｜ `--target-height 540`（降行高）
- **耗时画像**：Mac arm64 CGL 实测 ~76ms/帧（GL 渲染环节），90s 样本全参数约
  5-7 分钟；`--stride 2` 减半，`--max-frames 300` ≈ 1 分钟。抽样 3-10 个样本
  挂后台是常态用法
- **一次性准备**：环境自检 `--check`；MANO 模型转换
  `--convert-mano MANO_RIGHT.pkl MANO_LEFT.pkl`（注册 mano.is.tue.mpg.de 下载；
  npz 不入 git、不随包分发）
- 产物 `figures/videos/<sid>/AoE_output_vis.mp4` + `_gallery.md`（耗时与参数血缘）

### Phase 5 子集下载（类别化 + 校验 + 断点续传）

```bash
python3 scripts/download_subset.py --subset subset.json \
    --categories annotation,video_info,hands --out data/openaoe_subset --workers 4
```

- 类别：`annotation | video_info | undistorted_info | undistorted_video | hands | camera_traj |
  overview | hands_video | raw_video`；聚合别名 `minimal`（仅 3 个 JSON，无 MANO 顾虑）/
  `recon`（hands+traj+overview，含 MANO 限制）/ `all`
- 每文件 tree 查 Size+sha256 → 下载（Range 断点续传 + `.part` 临时）→ sha256/体积校验
- **重跑同一命令 = 自动续传**（已完成且校验通过的文件跳过）
- 体积经验值：annotation ~7KB；hands ~3.1MB/2.8min 样本；raw_video 50–90MB/样本

### Phase 6 交付报告（血缘三件套）

汇总交付：`subset.json`（筛选条件与命中统计）+ `qc_report.md`（质量结论）+
`data/openaoe_subset/_openaoe_manifest.json`（revision 血缘 + 每文件 sha256）+ `figures/_gallery.md`。
向用户明确声明：
1. 署名要求（Open-AoE + arXiv:2607.14183；`ATTRIBUTION.md` 已自动随附）
2. **MANO 衍生文件限制**：含 hands/camera_traj/overview/hands_video 的子集再分发受 MANO license
   约束（详见 `references/license-notes.md`）
3. 数据集仍在上传中，结果复现以 manifest 的 revision 快照为准

## 命令卡（Quick Reference）

| 意图 | 命令 | 关键参数 |
| --- | --- | --- |
| 建索引 | `build_index.py --out .cache/index.parquet [--incremental \| --limit N \| --only id,id]` | `--workers 16` `--no-sizes` |
| 筛选 | `filter.py --index … [--scene s] [--min-duration 60] [--task "grasp+cup"] [--hand both] [--fov-x-gt 100] [--resolution 720] [--brand samsung] [--min-avg-conf 0.8] [--qc-pass] [--limit 20]` | `--from-subset rN.json`（上轮命中内细筛，多层收敛）`--preview-only`（只看分布线索）`--order random --seed N`（命中集随机抽样：**"先抽例验收再全量"流程**，限制在 --limit 之前发生）`--order duration_desc` `--exclude "verb+object"` `--dominant-verb stir --dominant-verb flip --verb-rank-le 3 [--min-verb-ratio 0.3]`（**按动作时长占比筛"真实以某动作为主"的样本**：炒菜时长排进前三/占比≥30%；依赖索引 `verb_durations` 列） |
| 质检 | `quality_check.py --subset subset.json --level l1\|l2\|both [--sample-ratio 0.05] [--use-index]` | `--min-conf 0.3` `--l2-limit 50`；`--use-index`（0 请求离线快查，直接用索引预计算 flag）+ `--verify-fail`（仅对 intrinsics_ok 空/False 的可疑样本回源现算复核，现算为准，True 样本仍 0 请求） |
| 可视化 | `visualize.py --index … [--dims scene,duration,…] [--cross scene,hand] [--sample-cards 12] [--pie]` | `--pie` 类别维度加占比饼图（top-6+others；`--pie-only` 纯饼模式）；`--out figures/` |
| 深检渲染 | `render_videos.py --subset subset.json\|--samples id1,id2 --data-root data/ … [--stride 2] [--max-frames 450] [--no-world]` | 自动补齐缺失 6 类别（`--no-download` 关闭）；速度旋钮 `--no-mesh/--no-trails/--no-keypoints/--target-height 540`；`--check` 环境自检；`--convert-mano R.pkl L.pkl` 一次性 MANO 转换；`--out figures/videos/` |
| 下载 | `download_subset.py --subset subset.json --categories minimal\|annotation,hands\|all --out data/` | `--workers 4` `--no-verify` |
| 调试 | `openaoe_client.py --meta \| --ls <dir> \| --download <path> -o out` | token/连通性首选 |

## 错误处理

| 错误类型 | 现象 | 策略 |
| --- | --- | --- |
| 限流（429/5xx） | `[retry] 第 n 次退避…` 日志 | client 自动指数退避 + 自适应降速；频发则 `--workers` 减半；索引断点续跑 |
| token 失效 | 匿名模式报 `TokenError: 匿名访问被拒（401/403）`；token 模式报 `token 鉴权失败` | 匿名遭 401/403 → 在 `.env` 写 `token=` / 环境变量 `OPENAOE_MS_TOKEN`（公开仓库策略变更时兜底）；token 失效 → 换有效 token；`openaoe_client.py --meta` 单点验证 |
| 索引过期 | state 的 `root_total` < 当前快照值 | `build_index.py --incremental` 增量拉新样本目录 |
| 空结果 | `命中 0` + 各维度命中数 | 依次放宽：换 scene 关键词（先看 visualize 的 scene 分布）→ 去 duration/fov 限制 → 提高 `--limit` |
| 部分样本元数据缺失 | 索引 `status=partial/missing` | 容忍（上游亦有缺）；L1 fld01 会点名；下载失败记 manifest |
| 下载 sha256 校验失败 | manifest `status=failed, sha256 不匹配` | 重跑该文件（自动换 .part 重下）；仍失败 → 上游数据变更，先 `--incremental` 重建索引 |
| 传输中断 | `.part` 残留 | 重跑同一命令（Range 续传），无需清理 |
| 环境缺依赖 | ImportError | `pip install requests pandas pyarrow matplotlib numpy` |
| API 行为漂移 | tree 分页异常 / 总数量级畸变 | 按 `references/modelscope-api.md` 坑位清单复测；SDK/HF 兜底 |
| MANO 未准备 | `错误：MANO 缺失 …` | 注册 mano.is.tue.mpg.de 下载 pkl → `render_videos.py --convert-mano R L`（转 chumpy 需 `pip install chumpy`，numpy≥1.24 shim 已内置） |
| GL 不可用 | 渲染日志 `[warn] GL 不可用`，输出为 NumPy flat-shaded | `pip install pyrender trimesh PyOpenGL`；Linux 走 EGL（GPU），Mac 走 CGL；CI/容器无 GL → 接受降级或换 GPU 机器 |
| 无 ffmpeg | `[warn] 无 ffmpeg`；输出 mp4v 编码、`--max-frames` 失效 | `brew install ffmpeg` / `apt install ffmpeg`；或不用 `--max-frames`（用 `--stride`/`--no-world` 提速） |
| 渲染出现 RuntimeWarning（NaN/overflow in matmul） | 世界系面板对 pred_valid=False 帧的 NaN 关节做矩阵运算 | 官方原行为（非错误），渲染不受影响；嫌吵可忽略或设 `PYTHONWARNINGS=ignore::RuntimeWarning` |

## Test Scenarios

### 场景 1：正常流（厨房长样本）
**Prompt**: "把 OpenAoE 里厨房场景、时长≥60 秒的样本筛出来，质检后下载前 20 个的标注和手部数据，给我报告。"
**Expected Results**:
- Phase 2 `--scene kitchen --min-duration 60` 返回命中数与分布；用户确认后 `--limit 20`
- Phase 3 L1 全量 + L2 抽样（`--sample-ratio 0.05`，至少 1 个）
- Phase 5 manifest sha256 全绿、`ATTRIBUTION.md` 齐备（含 MANO 提示）
- 交付物：subset.json + qc_report.md + manifest + 图集

### 场景 2：空结果流（放宽条件指导）
**Prompt**: "找 FOV>110 度的双手机操作样本。"
**Expected Results**:
- 命中 0（库里 fov_x 主分布 ~72°/101°），控制台列各维度命中数（`fov_x_gt: 0`）
- 依据本文档提示放宽路径：`--fov-x-gt 100` 或去掉 FOV 条件；先给 fov 分布图再定阈值
- 不触发任何下载

### 场景 3：参数模糊流（维度澄清）
**Prompt**: "帮我搞一批扫地机器人的数据。"
**Expected Results**:
- Phase 0 转维度清单：场景（kitchen/living room）、任务动词（clean/wipe/pick up）、
  时长/机型要求、是否需要 MANO 手部数据（涉及许可与体积）
- 给 2–3 组候选 filter 命令与预期命中量级，用户选定后按正常流执行

## References

| 文档 | 内容 |
| --- | --- |
| `references/dataset-schema.md` | 字段表/坐标系/批次差异兜底/索引行 schema/数据合同（先读） |
| `references/modelscope-api.md` | API 实测坑位（翻页 0=1、LFS 302、限流、版本水位） |
| `references/license-notes.md` | 署名要求 + MANO 衍生文件许可隔离 |
| `templates/subset-manifest.json` | 下载血缘 manifest 的 schema 参照 |
| `templates/qc-report.md` | 质检报告模板（占位符由 quality_check.py 填充） |
| `scripts/aoe_parsing.py` | 字段解析与聚合的单一事实源（含批次差异兜底） |

## Notes for Extension

- 网络层（`openaoe_client.py`）与解析层（`aoe_parsing.py`）正交，为泛化具身数据 skill
  （embodied-data-ops）预留上移路径：换数据源 = 重写 client + parsing，五个上层脚本逻辑不变
  （索引行 schema 保持一致）。
