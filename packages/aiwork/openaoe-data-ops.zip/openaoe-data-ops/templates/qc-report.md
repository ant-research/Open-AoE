# OpenAoE 数据质检报告（qc_report）

- 生成时间：{{generated_at}}
- 数据集：{{dataset}}（revision gmt_modified={{gmt_modified}}）
- 输入来源：{{source}}（subset.json / --samples / index 全量）
- 检查样本数：{{n_samples}}；整体全绿样本：{{n_all_pass}}（{{pct_pass}}%）
- 检查级别：{{levels}}（L1 元数据 [ + L2 抽样深检]）
- L2 抽样说明：{{l2_note}}

## 规则通过率

| 规则 | 名称 | 级别(severity) | 通过 | 失败样本示例 |
| --- | --- | --- | --- | --- |
| ann01 | 标注时间连续性 | error | n_pass/n | … |
| ann02 | 帧序连续性 | error | n_pass/n | … |
| ann03 | 时长-帧数自洽 | warn | n_pass/n | … |
| ann04 | bbox 合法性 | error | n_pass/n | … |
| ann05 | bbox 画幅越界 | warn | n_pass/n | … |
| ann06 | 置信度下限 | warn | n_pass/n | … |
| ann07 | hand 枚举合法 | error | n_pass/n | … |
| vi01 | 内参-分辨率一致（PR #1 类型；vi1.1：fx↔去畸变fov_x） | error | n_pass/n | … |
| vi02 | 畸变系数合法 | warn | n_pass/n | … |
| vi03 | 去畸变对齐 | warn | n_pass/n | … |
| fld01 | 元数据完整性 | error | n_pass/n | … |
| hnd01 | hands.npz 可载入 | error | n_pass/n | … |
| hnd02 | 手部有效帧比例 | warn | n_pass/n | … |
| hnd03 | 帧数对齐 | warn | n_pass/n | … |
| hnd04 | focal 自洽 | warn | n_pass/n | … |
| traj01 | camera_traj.npz 可载入 | error | n_pass/n | — |
| traj02 | 轨迹与手帧一致 | warn | n_pass/n | — |

## 结论与建议

- {{自动结论：未发现 failed 规则触发… / 失败 Top 规则及建议（vi01→剔除或 --qc-pass；ann01/02→分裁剪或剔除）}}

> 机器可读明细见 qc.parquet（列：sample_id, rule_id, level, severity, passed, detail）。
