#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 索引多维筛选 → subset.json（工作流 Phase 2：筛选 + 命中预览）。

筛选维度（⟷ 标注/元数据字段映射见 references/dataset-schema.md）：
  --scene            场景（标注 segments[].scene，子串/大小写不敏感，可多次 OR）
  --min/-max-duration 时长区间（秒，来自末段 end_ts）
  --min/-max-frames  帧数区间
  --brand/-model     机型（video_info.deviceInfo）
  --task             任务对 verb+object（如 "grasp+cup"；object 支持子串；可多次 OR）
  --verb / --object  单独按动词/物体筛（子串匹配）
  --hand             手别 left/right/both/none（原子动作出现即命中）
  --min-avg-conf     平均置信度下限（atomic_action[].confidence 均值）
  --min-conf         最低置信度下限（所有原子动作均需 ≥）
  --resolution       分辨率（"1280x720" / "720" 均可匹配）
  --fov-x/y-gt/lt    FOV 阈值（undistorted_video_info.fov_x/y_degrees）
  --min-segments     最少标注分段数
  --qc-pass          仅保留 L1 关键 flag 通过的样本（ts/frame 连续、内参自洽、无坏 bbox）
  --exclude TASK     排除任务对（可多次）
  --order            排序（duration_desc / duration_asc / id / segments_desc）
  --limit N          命中上限

多层迭代筛选（R1 粗筛 → 看分布 → R2/R3 细筛；动词语义常宽于直觉，如 stir 含搅汤/拌面）：
  --from-subset F    在上轮 subset.json 的命中样本内继续叠加条件收敛
  --preview-only     不筛选不写文件，仅打印输入集（上轮命中或全库）分布线索
  每轮自动打印：上轮命中分布（细筛方向）→ 本轮命中摘要（verbs/objects/scenes/时长/手别）
  ⚠ 多层收敛流程在上轮不放 --limit（否则 subset 只含抽样样本）；末轮才随机抽样/限条数。

空结果时输出各维度单独命中数（帮助放宽条件，对应 SKILL.md 错误处理表）。

用法示例：
    python3 filter.py --index .cache/openaoe_index.parquet \
        --scene kitchen --min-duration 60 --fov-x-gt 100 --task "grasp+cup" --limit 20 \
        --out subset.json
    # R1 粗筛（宽动词）→ 看分布 → R2 细筛（object 收敛到锅具）：
    python3 filter.py --index .cache/openaoe_index.parquet \
        --scene kitchen --verb stir --out r1.json
    python3 filter.py --index .cache/openaoe_index.parquet --from-subset r1.json --preview-only
    python3 filter.py --index .cache/openaoe_index.parquet \
        --from-subset r1.json --object wok --object pan --min-avg-conf 0.9 --out r2.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from typing import Any, Dict, List, Optional

import pandas as pd

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from aoe_parsing import as_dict, as_list, norm_token  # noqa: E402


def _task_hit(tasks, verb: Optional[str], obj: Optional[str]) -> bool:
    """--task "verb+object"：verb 精确、object 子串；单独给 verb/object 时同规则。"""
    pairs = [norm_token(t) for t in as_list(tasks)]
    for p in pairs:
        if "+" not in p:
            continue
        v, _, o = p.partition("+")
        if verb and obj:
            if (verb in v) and (obj in o):
                return True
        elif verb:
            if verb in v:
                return True
        elif obj:
            if obj in o:
                return True
    return False


def _parse_verb_durations(vd) -> Dict[str, tuple]:
    """索引 verb_durations 列（list<string> "verb:seconds:rank"）→ {verb: (seconds, rank)}。"""
    out: Dict[str, tuple] = {}
    for item in as_list(vd):
        parts = str(item).rsplit(":", 2)
        if len(parts) == 3:
            verb, sec, rank = parts
            try:
                out[norm_token(verb)] = (float(sec), int(rank))
            except ValueError:
                continue
    return out


def _dominant_verb_hit(vd, total, verbs, rank_le, min_ratio) -> bool:
    """--dominant-verb 时长排名/占比判定：命中集里任一动词满足排名≤rank_le 且 占比≥min_ratio。"""
    parsed = _parse_verb_durations(vd)
    if not parsed:
        return False
    tot = num(total) or 0.0
    hit_secs = 0.0
    best_rank = None
    for v in verbs:
        for pv, (sec, rank) in parsed.items():
            if v in pv:  # 子串匹配，与 --verb 口径一致
                hit_secs += sec
                best_rank = rank if best_rank is None else min(best_rank, rank)
    if best_rank is None:
        return False
    if rank_le is not None and best_rank > rank_le:
        return False
    if min_ratio is not None:
        if tot <= 0 or (hit_secs / tot) < min_ratio:
            return False
    return True


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="OpenAoE 索引多维筛选 → subset.json")
    p.add_argument("--index", default=".cache/openaoe_index.parquet", help="索引 parquet 路径")
    p.add_argument("--out", default="subset.json", help="输出 subset.json 路径")
    p.add_argument("--from-subset", metavar="SUBSET_JSON",
                   help="多层筛选：在上轮 subset.json 命中的样本内继续收敛（R1 粗筛→R2/R3 细筛）")
    p.add_argument("--preview-only", action="store_true",
                   help="不筛选不写文件：仅打印输入集（上轮命中或全量索引）分布线索，供细筛定方向")
    p.add_argument("--scene", action="append", help="场景（可多次，OR，子串匹配）")
    p.add_argument("--min-duration", type=float, help="最短时长（秒）")
    p.add_argument("--max-duration", type=float, help="最长时长（秒）")
    p.add_argument("--min-frames", type=int, help="最少帧数")
    p.add_argument("--brand", help="设备品牌（如 samsung / vivo，子串）")
    p.add_argument("--model", help="设备型号（如 SM-S9080）")
    p.add_argument("--task", action="append", help='任务对 "verb+object"（可多次，OR）')
    p.add_argument("--verb", action="append", help="动词（可多次，OR）")
    p.add_argument("--object", action="append", help="物体（可多次，OR，子串）")
    p.add_argument("--hand", choices=["left", "right", "both", "none"],
                   help="至少出现一个该手别的原子动作")
    p.add_argument("--min-avg-conf", type=float, help="平均置信度下限")
    p.add_argument("--min-conf", type=float, help="最低置信度下限（更严格）")
    p.add_argument("--resolution", help='分辨率（"1280x720" 或 "720"）')
    p.add_argument("--fov-x-gt", type=float, help="fov_x_deg 下限")
    p.add_argument("--fov-x-lt", type=float, help="fov_x_deg 上限")
    p.add_argument("--fov-y-gt", type=float, help="fov_y_deg 下限")
    p.add_argument("--fov-y-lt", type=float, help="fov_y_deg 上限")
    p.add_argument("--min-segments", type=int, help="最少标注分段数")
    p.add_argument("--dominant-verb", action="append",
                   help="判定'主导动作'的动词集（可多次，OR；默认 stir,flip,toss 即'炒菜'）；"
                        "配合 --verb-rank-le / --min-verb-ratio 按时长占比筛真实以该动作为主的样本")
    p.add_argument("--verb-rank-le", type=int, metavar="N",
                   help="要求 --dominant-verb 里至少一个动词的累计时长在该样本所有动词中排名 ≤ N"
                        "（例：3 = 炒菜时长排进前三；依赖索引 verb_durations 列）")
    p.add_argument("--min-verb-ratio", type=float, metavar="R",
                   help="要求 --dominant-verb 累计时长 / 样本总动作时长 ≥ R（0~1；例 0.2 = 占比≥20%%）")
    p.add_argument("--qc-pass", action="store_true",
                   help="仅保留 L1 关键 flag 全过（连续性/内参/坏bbox=0）的样本")
    p.add_argument("--exclude", action="append", help='排除任务对 "verb+object"（可多次）')
    p.add_argument("--order", default="id",
                   choices=["id", "duration_desc", "duration_asc", "segments_desc",
                            "conf_desc", "random"],
                   help="输出排序；random=命中集内随机抽取（配 --limit 与 --seed，"
                        "用于'抽例验收再全量'流程）")
    p.add_argument("--seed", type=int, default=20260902,
                   help="random 抽样种子（写入 subset.json，评估集复现用）")
    p.add_argument("--limit", type=int, help="命中数上限（random 时即抽样数）")
    p.add_argument("--strict", action="store_true",
                   help="严格模式：scene/task 匹配词语精确而非子串（默认子串）")
    return p.parse_args(argv)


def num(x) -> Optional[float]:
    try:
        v = float(x)
        return v if v == v else None  # NaN -> None
    except (TypeError, ValueError):
        return None


def build_masks(df: pd.DataFrame, a) -> Dict[str, Any]:
    """逐维度构建布尔掩码（数量统计预览 + 最终 AND 合成）。"""
    masks: Dict[str, Any] = {}

    def and_add(name, series):
        masks[name] = series.fillna(False)

    # ---- 场景 ----
    if a.scene:
        scenes = [norm_token(s) for s in a.scene]
        if a.strict:
            m = df["scenes"].map(lambda sc: all(any(s == x for x in as_list(sc)) for s in scenes))
        else:
            m = df["scenes"].map(
                lambda sc: all(any(s in x or x in s for x in as_list(sc)) for s in scenes))
        and_add("scene", m)

    # ---- 时长 / 帧数 ----
    dur = df["duration_s"].map(num)
    if a.min_duration is not None:
        and_add("min_duration", dur >= a.min_duration)
    if a.max_duration is not None:
        and_add("max_duration", dur <= a.max_duration)
    if a.min_frames is not None:
        and_add("min_frames", df["frames"].map(lambda v: num(v) or -1) >= a.min_frames)

    # ---- 机型 ----
    if a.brand:
        and_add("brand", df["device_brand"].map(lambda v: a.brand in str(v or "")))
    if a.model:
        and_add("model", df["device_model"].map(lambda v: a.model.upper() in str(v or "").upper()))

    # ---- 任务 / 动词 / 物体 ----
    if a.task:
        def task_row(tasks):
            for arg in a.task:
                verb, _, obj = norm_token(arg).partition("+")
                if _task_hit(tasks, verb or None, obj or None):
                    return True
            return False
        and_add("task", df["tasks"].map(task_row))
    if a.verb:
        and_add("verb", df["tasks"].map(
            lambda t: any(any(v in p.partition("+")[0] for v in a.verb) for p in as_list(t))))
    if a.object:
        and_add("object", df["tasks"].map(
            lambda t: any(any(norm_token(o) in p.partition("+")[2] for o in a.object)
                          for p in as_list(t))))
    if a.exclude:
        def not_excluded(tasks):
            for arg in a.exclude:
                verb, _, obj = norm_token(arg).partition("+")
                if _task_hit(tasks, verb or None, obj or None):
                    return False
            return True
        and_add("exclude", df["tasks"].map(not_excluded))

    # ---- 手别 ----
    if a.hand:
        and_add("hand", df["hand_counts"].map(
            lambda hc: (as_dict(hc).get(a.hand) or 0) > 0))

    # ---- 置信度 ----
    avg_conf = df["confidence_mean"].map(num)
    if a.min_avg_conf is not None:
        and_add("min_avg_conf", avg_conf >= a.min_avg_conf)
    if a.min_conf is not None:
        and_add("min_conf", df["confidence_min"].map(lambda v: (num(v) or -1) >= a.min_conf))

    # ---- 分辨率 / FOV ----
    if a.resolution:
        want = norm_tokens_res(a.resolution)
        and_add("resolution", df["resolution"].map(
            lambda r: any(w in str(r or "") for w in want)))
    for key, col, bound, cmp_name in [
            ("fov_x_gt", "fov_x_deg", a.fov_x_gt, "gt"), ("fov_x_lt", "fov_x_deg", a.fov_x_lt, "lt"),
            ("fov_y_gt", "fov_y_deg", a.fov_y_gt, "gt"), ("fov_y_lt", "fov_y_deg", a.fov_y_lt, "lt")]:
        if bound is not None:
            series = df[col].map(num)
            and_add(key, (series >= bound) if cmp_name == "gt" else (series <= bound))

    # ---- 分段数 ----
    if a.min_segments is not None:
        and_add("min_segments", df["n_segments"].map(lambda v: (num(v) or 0) >= a.min_segments))

    # ---- 主导动作时长（炒菜时长排名/占比）：依赖索引 verb_durations 列 ----
    if a.verb_rank_le is not None or a.min_verb_ratio is not None:
        dom_verbs = [norm_token(v) for v in (a.dominant_verb or ["stir", "flip", "toss"])]
        if "verb_durations" not in df.columns:
            raise SystemExit(
                "索引缺 verb_durations 列（旧版索引）。请用新版 build_index.py 重建索引"
                "（或 --incremental 增量）后再用 --verb-rank-le/--min-verb-ratio 筛选。")
        and_add("dominant_verb", df.apply(
            lambda r: _dominant_verb_hit(r.get("verb_durations"), r.get("verb_seconds_total"),
                                         dom_verbs, a.verb_rank_le, a.min_verb_ratio), axis=1))

    # ---- L1 质量闸门（复用索引 flag；配合 quality_check.py 的完整规则） ----
    if a.qc_pass:
        m = (df["ts_continuous"] == True) & (df["frame_continuous"] == True) & \
            (df["intrinsics_ok"] == True) & \
            (df["bbox_bad_count"].map(lambda v: (num(v) or 0) == 0)) & \
            (df["hand_bad_count"].map(lambda v: (num(v) or 0) == 0))  # noqa: E712
        and_add("qc_pass", m)
    return masks


def norm_tokens_res(res_str: str) -> List[str]:
    r = norm_token(res_str)
    if "x" in r:
        w, _, h = r.replace("×", "x").partition("x")
        return [r, w, h]
    return [r]


# ---------------------------------------------------------------------------
# 分布摘要（多层筛选线索：细筛前先看输入集/上轮命中的 verbs/objects 分布）
# ---------------------------------------------------------------------------
def summarize_preview(hit: pd.DataFrame, k: int = 10) -> Dict[str, Any]:
    """命中集分布摘要：scenes/verbs/objects/hands/duration（subset.preview 与控制台共用）。"""
    def top_counts(col_series):
        cnt: Dict[str, int] = {}
        for v in col_series:
            for item in as_list(v):
                if item:
                    cnt[item] = cnt.get(item, 0) + 1
        return dict(sorted(cnt.items(), key=lambda kv: -kv[1])[:k])

    def task_top(part: int) -> Dict[str, int]:
        cnt: Dict[str, int] = {}
        for tasks in hit["tasks"].tolist():
            for p in as_list(tasks):
                seg = norm_token(str(p).partition("+")[part])
                if seg:
                    cnt[seg] = cnt.get(seg, 0) + 1
        return dict(sorted(cnt.items(), key=lambda kv: -kv[1])[:k])

    hands = {"left": 0, "right": 0, "both": 0, "none": 0}
    for hc in hit["hand_counts"].tolist():
        d = as_dict(hc)
        for key in hands:
            hands[key] += d.get(key) or 0
    duration = None
    if len(hit):
        duration = {
            "min": round(float(hit["duration_s"].min()), 1),
            "median": round(float(hit["duration_s"].median()), 1),
            "max": round(float(hit["duration_s"].max()), 1),
        }
    return {
        "n": len(hit),
        "scenes": top_counts(hit["scenes"].tolist()),
        "verbs": task_top(0),
        "objects": task_top(2),
        "hands": hands,
        "duration": duration,
    }


def print_distribution(title: str, preview: Dict[str, Any]) -> None:
    """打印分布线索（R2/R3 细筛前先看上一轮命中分布，决定收敛方向与取值）。"""
    print(f"{title}（n={preview.get('n')}）—— 细筛方向线索：")
    print(f"  动词 verbs      {preview.get('verbs')}")
    print(f"  物体 objects    {preview.get('objects')}")
    print(f"  场景 scenes     {preview.get('scenes')}")
    print(f"  时长 duration   {preview.get('duration')}")
    print(f"  手别动作数 hands {preview.get('hands')}")


def load_prev_subset(full_df: pd.DataFrame, path: str):
    """读上轮 subset.json，把索引限制在其返回样本内（多层筛选）。返回 (ok, df, meta)。"""
    if not os.path.isfile(path):
        print(f"错误：上轮 subset 不存在：{path}（先运行 filter.py 生成）", file=sys.stderr)
        return False, full_df, None
    with open(path, "r", encoding="utf-8") as fh:
        prev = json.load(fh)
    prev_ids = [s.get("sample_id") for s in prev.get("samples") or [] if s.get("sample_id")]
    if not prev_ids:
        print(f"错误：上轮 subset 无样本（samples 为空）：{path}", file=sys.stderr)
        return False, full_df, None
    stats = prev.get("stats") or {}
    before_limit = stats.get("matched_before_limit")
    meta: Dict[str, Any] = {
        "path": os.path.abspath(path),
        "previous_filters": prev.get("filters"),
        "n_returned": len(prev_ids),
        "matched_before_limit": before_limit,
    }
    want = set(prev_ids)
    df = full_df[full_df["sample_id"].isin(want)].copy()
    missing = len(want) - len(df)
    if missing:
        print(f"注意：上轮 subset 的 {missing} 个样本不在当前索引中（索引版本变化），已跳过。",
              file=sys.stderr)
    if before_limit and before_limit > len(prev_ids):
        print(f"注意：上轮使用了 --limit/--random（命中 {before_limit}，仅返回 {len(prev_ids)}），"
              "本轮细筛只作用于返回的样本——多层收敛请在上轮不加 --limit，末轮再抽样。",
              file=sys.stderr)
    return True, df, meta


def main(argv=None) -> int:
    a = parse_args(argv)
    if not os.path.isfile(a.index):
        print(f"错误：索引不存在：{a.index}。请先运行 build_index.py。",
              file=sys.stderr)
        return 2
    df = pd.read_parquet(a.index)
    total = len(df)

    # ---- 多层筛选：R1 粗筛 → 看分布 → R2/R3 细筛（--from-subset 输入为上轮命中集） ----
    from_meta: Optional[Dict[str, Any]] = None
    if a.from_subset:
        ok, df, from_meta = load_prev_subset(df, a.from_subset)
        if not ok:
            return 2
        # 细筛前先打印上轮命中分布（本轮收敛方向的线索）
        print_distribution(f"上轮命中分布（来自 {a.from_subset}）", summarize_preview(df))
    elif a.preview_only:
        # R0 概览：全库分布（找粗筛维度与取值）
        print_distribution(f"全量索引分布（{a.index}）", summarize_preview(df))
        return 0
    if a.preview_only:  # --from-subset + --preview-only：分布已打印，直接退出
        return 0

    masks = build_masks(df, a)
    final_mask = None
    for m in masks.values():
        final_mask = m.copy() if final_mask is None else (final_mask & m)
    if final_mask is None:
        final_mask = pd.Series(True, index=df.index)
    hit = df[final_mask.fillna(False)].copy()

    # ---- 抽样 / 排序 ----
    # random：先从命中集随机抽取再限制条数（"先抽例、验收、再全量"流程的抽样位）；
    # 其余顺序：确定性排序后取前 N。--seed 记录于 subset.json 供评估集复现。
    order = a.order
    if order == "random":
        import random as _random
        rng = _random.Random(a.seed)
        if 0 < a.limit < len(hit):
            pick = rng.sample(hit.index.tolist(), a.limit)
            hit = hit.loc[pick].copy()
        elif a.limit is not None and a.limit <= 0:
            hit = hit.iloc[0:0]
        # 无 limit 或 limit≥命中数：返回全量（按 id 稳定序，随机无意义）
        else:
            hit = hit.sort_values("sample_id")
    else:
        if order == "duration_desc":
            hit = hit.sort_values("duration_s", ascending=False, na_position="last")
        elif order == "duration_asc":
            hit = hit.sort_values("duration_s", ascending=True, na_position="first")
        elif order == "segments_desc":
            hit = hit.sort_values("n_segments", ascending=False, na_position="last")
        elif order == "conf_desc":
            hit = hit.sort_values("confidence_mean", ascending=False, na_position="last")
        else:
            hit = hit.sort_values("sample_id")
        if a.limit is not None:
            hit = hit.head(a.limit)

    # ---- 统计预览（空结果时帮助放宽：每个维度单独命中数） ----
    per_dim = {name: int(m.sum()) for name, m in masks.items()}

    # 命中子集自身的分布摘要（verbs/objects 供下一轮细筛参考）
    preview = summarize_preview(hit)

    # ---- 索引血缘 ----
    state_path = a.index + ".state.json"
    origin: Dict[str, Any] = {
        "dataset": "inclusionAI/OpenAoE-2000h",
        "platform": "modelscope",
        "index_path": os.path.abspath(a.index),
    }
    if from_meta:
        origin["from_subset"] = from_meta
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as fh:
                state = json.load(fh)
            origin["index_built_at"] = state.get("built_at")
            origin["index_revision"] = state.get("revision")
        except (OSError, json.JSONDecodeError):
            pass

    subset = {
        "schema": "openaoe-subset/1.0",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "origin": origin,
        "filters": {k: v for k, v in vars(a).items()
                    if k not in ("index", "out") and v is not None and v is not False},
        "stats": {
            "total_indexed": total,
            "input_n": len(df),  # 多层筛选：本轮输入样本数（上轮命中集）
            "matched_before_limit": int(final_mask.fillna(False).sum()),
            "returned": len(hit),
            "per_filter_hits": per_dim,
        },
        "preview": preview,
        "samples": [],
    }
    for _, r in hit.iterrows():
        hc = as_dict(r.get("hand_counts"))
        subset["samples"].append({
            "sample_id": r["sample_id"],
            "status": r.get("status"),
            "scenes": as_list(r.get("scenes")),
            "primary_scene": r.get("primary_scene"),
            "duration_s": r.get("duration_s"),
            "n_segments": r.get("n_segments"),
            "n_actions": r.get("n_actions"),
            "fps": r.get("fps"),
            "frames": r.get("frames"),
            "resolution": r.get("resolution"),
            "fov": {"x_deg": r.get("fov_x_deg"), "y_deg": r.get("fov_y_deg")},
            "device": {"brand": r.get("device_brand"), "model": r.get("device_model")},
            "tasks": as_list(r.get("tasks")),
            "hand_counts": dict(hc),
            "confidence": {"mean": r.get("confidence_mean"), "min": r.get("confidence_min")},
            "raw_video_bytes": r.get("raw_video_bytes"),
        })

    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as fh:
        json.dump(subset, fh, ensure_ascii=False, indent=2)

    # ---- 控制台摘要 ----
    src_desc = f"上轮命中 {len(df)}" if from_meta else f"索引 {total}"
    print(f"筛选完成：{src_desc} → 本轮命中 {subset['stats']['matched_before_limit']}"
          f" → 返回 {len(subset['samples'])}（已写入 {a.out}）")
    if per_dim:
        print("各维度单独命中数（分母为本轮输入集）：")
        for k, v in per_dim.items():
            print(f"  {k:<16} {v}")
    if not subset["samples"]:
        print("空结果：请参照上方各维度命中数放宽条件（常用：去掉 --min-duration 或换 scene 关键词）。")
    else:
        print(f"命中摘要：verbs={preview['verbs']}")
        print(f"          objects={preview['objects']}")
        print(f"          scenes={preview['scenes']}")
        print(f"          duration={preview['duration']} hands={preview['hands']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
