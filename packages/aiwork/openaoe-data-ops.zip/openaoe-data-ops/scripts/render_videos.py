#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 单样本官方级渲染视频（Phase 4 深检渲染，柔性接入工作流）。

桥接 openaoe-data-ops 与 vendored 官方 aoe-visualization（vendor/aoe-vis/）：
把 skill 下载的平铺样本目录自动补齐缺失类别 → 软链接成官方嵌套布局 →
调用官方 GL 渲染管线（纯 NumPy MANO 前向运动学 + pyrender 离屏渲染 +
OpenCV 多面板合成 + ffmpeg H.264），产出与官方 demo 完全一致的每样本
端到端审阅视频：``<out>/<sample_id>/AoE_output_vis.mp4``。

渲染速度旋钮（本机实测 Mac CGL ~76ms/帧 → 90s 样本全参数约 5-7 分钟）：
  --stride 2         隔帧渲染（总时长减半，输出 fps 减半，审阅够用）
  --max-frames 450   只渲染前 N 帧（ffmpeg 流拷贝截断，看动作开头即可判断质量）
  --no-world         关闭世界系 3D 面板（省一整块 GL 渲染）
  --no-mesh/--no-trails/--no-keypoints  再逐项瘦身

MANO 模型（独立 license，不入 git，一次性准备）：
  注册 https://mano.is.tue.mpg.de 下载 pkl 后运行
  python3 scripts/render_videos.py --convert-mano /path/MANO_RIGHT.pkl /path/MANO_LEFT.pkl
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Optional

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_SKILL_DIR = os.path.dirname(_THIS_DIR)
_VENDOR_DIR = os.path.join(_SKILL_DIR, "vendor", "aoe-vis")
_MANO_DIR = os.path.join(_VENDOR_DIR, "assets", "mano")
_DOWNLOAD_CLI = os.path.join(_THIS_DIR, "download_subset.py")

# 渲染必需类别（本地平铺文件名 → 官方嵌套布局），缺哪个自动补下载哪个
STAGING_LAYOUT = {
    "annotation": "ego_annotation/ego_action_annotation.json",
    "video_info": "video_info.json",
    "undistorted_info": "ego_process/ego_undistorted_video/undistorted_video_info.json",
    "undistorted_video": "ego_process/ego_undistorted_video/raw_video_undistorted.mp4",
    "hands": "ego_process/ego_hands_reconstruction/hands.npz",
    "camera_traj": "ego_process/ego_hands_reconstruction/camera_traj.npz",
    "raw_video": "raw_video.mp4",  # 可选兜底底片（undistorted 缺失时用）
}
REQUIRED_CATEGORIES = ("annotation", "video_info", "undistorted_info",
                       "undistorted_video", "hands", "camera_traj")
LOCAL_NAME = {
    "annotation": "ego_action_annotation.json",
    "video_info": "video_info.json",
    "undistorted_info": "undistorted_video_info.json",
    "undistorted_video": "raw_video_undistorted.mp4",
    "hands": "hands.npz",
    "camera_traj": "camera_traj.npz",
    "raw_video": "raw_video.mp4",
}


# ---------------------------------------------------------------------------
# MANO pkl → npz（numpy>=1.24 下 chumpy 兼容 shim 内置，一次性）
# ---------------------------------------------------------------------------
def _numpy_compat_shim() -> None:
    """chumpy 0.70 import 需要已被 numpy>=1.24 移除的顶层别名，打回垫片。"""
    import numpy as np
    for old, new in (("bool", np.bool_), ("int", np.int_), ("float", np.float64),
                     ("complex", np.complex128), ("object", np.object_),
                     ("unicode", str), ("str", np.str_)):
        if not hasattr(np, old):
            setattr(np, old, new)


def convert_mano(right_pkl: str, left_pkl: str) -> int:
    os.makedirs(_MANO_DIR, exist_ok=True)
    conv_cli = os.path.join(_VENDOR_DIR, "scripts", "convert_mano_pkl_to_npz.py")
    for pkl, npz in ((right_pkl, "MANO_RIGHT.npz"), (left_pkl, "MANO_LEFT.npz")):
        if not os.path.isfile(pkl):
            print(f"错误：找不到 {pkl}", file=sys.stderr)
            return 2
        _numpy_compat_shim()
        import chumpy  # noqa: F401  (仅触发旧版 numpy 别名的需求)
        spec = importlib.util.spec_from_file_location("conv", conv_cli)
        conv = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(conv)
        out = os.path.join(_MANO_DIR, npz)
        conv.convert(pkl, out)
        sz = os.path.getsize(out) / 1e6
        print(f"  [ok] {npz} <- {os.path.basename(pkl)}（{sz:.1f}MB）")
    print(f"MANO 就绪：{_MANO_DIR}/（仅本机使用，不要随 skill 再分发）")
    return 0


# ---------------------------------------------------------------------------
# 环境自检
# ---------------------------------------------------------------------------
def check_env() -> List[str]:
    problems: List[str] = []
    if not os.path.isdir(_VENDOR_DIR):
        problems.append(f"vendor 缺失：{_VENDOR_DIR}（skill 包不完整）")
        return problems
    try:
        import cv2  # noqa: F401
    except ImportError:
        problems.append("缺 opencv-python：pip install opencv-python")
    try:
        sys.path.insert(0, _VENDOR_DIR)
        from aoe_vis import gl_render
        if not gl_render.is_available():
            print(f"  [warn] GL 不可用（{gl_render.import_error()}），"
                  f"官方渲染将降级为 NumPy flat-shaded（画质降低）："
                  f"pip install pyrender trimesh PyOpenGL", file=sys.stderr)
    except Exception as e:
        problems.append(f"vendor 渲染模块导入失败：{e}")
    for npz in ("MANO_RIGHT.npz", "MANO_LEFT.npz"):
        if not os.path.isfile(os.path.join(_MANO_DIR, npz)):
            problems.append(
                f"MANO 缺失：{_MANO_DIR}/{npz}。注册 https://mano.is.tue.mpg.de "
                f"下载 pkl 后运行：python3 scripts/render_videos.py "
                f"--convert-mano MANO_RIGHT.pkl MANO_LEFT.pkl")
    if shutil.which("ffmpeg") is None:
        print("  [warn] 无 ffmpeg：输出退回 mp4v 编码，且 --max-frames 不可用",
              file=sys.stderr)
    return problems


# ---------------------------------------------------------------------------
# 样本收集 + 缺失类别盘点
# ---------------------------------------------------------------------------
def collect_samples(a) -> List[str]:
    sids: List[str] = []
    if a.subset:
        with open(a.subset, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        sids = [str(s["sample_id"]) for s in payload.get("samples") or []]
        if not sids:
            sys.exit(f"subset 为空：{a.subset}")
    elif a.samples:
        sids = [s.strip() for s in a.samples.split(",") if s.strip()]
    else:
        sids = sorted(d for d in os.listdir(a.data_root)
                      if os.path.isdir(os.path.join(a.data_root, d))
                      and not d.startswith(("_", ".")))
        if not sids:
            sys.exit(f"data-root 下没有样本目录：{a.data_root}")
    if a.limit:
        sids = sids[: a.limit]
    # 存在性校验
    missing_root = [s for s in sids if not os.path.isdir(os.path.join(a.data_root, s))]
    if missing_root:
        sys.exit(f"样本目录不存在于 {a.data_root}：{', '.join(missing_root[:5])}"
                 f"{'…' if len(missing_root) > 5 else ''}（先跑 download_subset.py？）")
    return sids


def missing_categories(sid: str, data_root: str) -> List[str]:
    d = os.path.join(data_root, sid)
    miss = []
    for cat in REQUIRED_CATEGORIES:
        if not os.path.isfile(os.path.join(d, LOCAL_NAME[cat])):
            miss.append(cat)
    return miss


def autofetch(sids: List[str], data_root: str, token: Optional[str],
              workers: int) -> None:
    """幂等补齐：已下载且校验通过的文件会自动 skip（download_subset 断点续传）。"""
    cache_dir = os.path.join(os.path.dirname(os.path.abspath(data_root)), ".cache")
    os.makedirs(cache_dir, exist_ok=True)
    tmp_subset = os.path.join(cache_dir, "render_fetch_subset.json")
    with open(tmp_subset, "w", encoding="utf-8") as fh:
        json.dump({"schema": "openaoe-subset/1.0",
                   "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                   "samples": [{"sample_id": s} for s in sids]}, fh, indent=1)
    cats = ",".join(REQUIRED_CATEGORIES)
    cmd = [sys.executable, _DOWNLOAD_CLI, "--subset", tmp_subset,
           "--categories", cats, "--out", data_root, "--workers", str(workers)]
    if token:
        cmd += ["--token", token]
    print(f"[补下载] {len(sids)} 样本 × {len(REQUIRED_CATEGORIES)} 类别"
          f"（缺的下载，已有的跳过）", file=sys.stderr)
    rc = subprocess.run(cmd).returncode
    if rc != 0:
        sys.exit(f"补下载失败（exit {rc}）；可手动重跑: {' '.join(cmd)}")


# ---------------------------------------------------------------------------
# 软链接 staging：平铺 → 官方嵌套布局（SamplePaths 约定）
# ---------------------------------------------------------------------------
def build_staging(sid: str, data_root: str, staging_root: str,
                  max_frames: Optional[int]) -> str:
    src_dir = os.path.abspath(os.path.join(data_root, sid))
    dst_dir = os.path.join(staging_root, sid)
    os.makedirs(dst_dir, exist_ok=True)
    for cat, rel in STAGING_LAYOUT.items():
        src = os.path.join(src_dir, LOCAL_NAME[cat])
        if not os.path.isfile(src):
            continue
        dst = os.path.join(dst_dir, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if cat == "undistorted_video" and max_frames:
            # ffmpeg 流拷贝截断（关键帧对齐，审阅粒度足够）
            r = subprocess.run(["ffmpeg", "-y", "-i", src, "-c", "copy",
                                "-frames:v", str(max_frames), dst],
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL).returncode
            if r != 0 and cat == "undistorted_video":
                shutil.copy(src, dst)  # 截断失败退回完整拷贝
        else:
            os.symlink(src, dst)
    return dst_dir


# ---------------------------------------------------------------------------
# 主渲染循环
# ---------------------------------------------------------------------------
def render_all(a, sids: List[str]) -> int:
    sys.path.insert(0, _VENDOR_DIR)
    from aoe_vis import render as aoe_render          # noqa: E402
    from aoe_vis.sample import SamplePaths            # noqa: E402

    out_root = os.path.abspath(a.out)
    os.makedirs(out_root, exist_ok=True)
    staging_root = os.path.join(out_root, "_staging")
    os.makedirs(staging_root, exist_ok=True)

    speed_note = (f"stride={a.stride}"
                  + (f", max_frames={a.max_frames}" if a.max_frames else "")
                  + (", no-world" if a.no_world else ""))
    records: List[Dict] = []
    for i, sid in enumerate(sids, 1):
        print(f"\n=== [{i}/{len(sids)}] {sid} ===", file=sys.stderr)
        staging = build_staging(sid, a.data_root, staging_root, a.max_frames)
        paths = SamplePaths(staging)
        if paths.base_video(prefer_undistorted=True) is None:
            print(f"  [skip] 无底片视频（undistorted/raw 都缺失）", file=sys.stderr)
            continue
        if not paths.has_hands():
            print("  [warn] 无 hands.npz：输出不带 MANO 手部叠加（仅底片+标注面板）",
                  file=sys.stderr)
        t0 = time.time()
        out_dir = os.path.join(out_root, sid)
        out_path = aoe_render.render_end_to_end(
            paths, out_dir,
            target_height=a.target_height,
            stride=a.stride,
            with_world=not a.no_world, with_trails=not a.no_trails,
            with_mesh=not a.no_mesh, with_keypoints=not a.no_keypoints,
            transcode_h264=not a.no_h264,
            fix_left_shapedirs=True)
        dt = time.time() - t0
        if out_path:
            records.append({"sid": sid, "path": out_path, "seconds": round(dt, 1)})
        else:
            print(f"  [skip] 官方渲染器返回 None（前置文件不完整）", file=sys.stderr)

    if not a.keep_staging:
        shutil.rmtree(staging_root, ignore_errors=True)

    # ---- gallery 汇总 ----
    md = ["# OpenAoE 官方级渲染视频集\n",
          f"- 生成时间：{time.strftime('%Y-%m-%dT%H:%M:%S%z')}",
          f"- 速度参数：{speed_note or '默认（官方全参数）'}",
          f"- 样本数：{len(sids)}，成功：{len(records)}", "",
          "| 样本 | 渲染耗时 | 视频 |", "| --- | --- | --- |"]
    for r in records:
        rel = os.path.relpath(r["path"], out_root)
        md.append(f"| {r['sid']} | {r['seconds']}s | [{rel}]({rel}) |")
    with open(os.path.join(out_root, "_gallery.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    total = sum(r["seconds"] for r in records)
    print(f"\n渲染完成：{len(records)}/{len(sids)} 样本 → {out_root}/"
          f"（合计 {total:.0f}s；见 _gallery.md）")
    return 0 if records else 1


# ---------------------------------------------------------------------------
def parse_args(argv=None):
    p = argparse.ArgumentParser(
        description="OpenAoE 官方级单样本渲染视频（vendor aoe-visualization，"
                    "速度可调 + 缺失类别自动补下载）")
    src = p.add_mutually_exclusive_group()
    src.add_argument("--subset", help="subset.json（filter.py 产物）")
    src.add_argument("--samples", help="逗号分隔 sample_id 列表")
    p.add_argument("--data-root", default="data/openaoe_subset",
                   help="skill 下载落盘根目录（平铺结构）")
    p.add_argument("--limit", type=int, help="只处理前 N 个样本")
    p.add_argument("--out", default="figures/videos", help="输出根目录")
    # 速度/画质旋钮（透传官方 render_end_to_end）
    p.add_argument("--stride", type=int, default=1,
                   help="隔帧渲染步长（2=时长减半/fps减半；默认 1=官方全速参数）")
    p.add_argument("--max-frames", type=int,
                   help="只渲染前 N 帧（ffmpeg 流拷贝截断 staging 底片）")
    p.add_argument("--target-height", type=int, default=720,
                   help="输出行高（像素；越小越快）")
    p.add_argument("--no-world", action="store_true", help="关世界系 3D 面板（提速）")
    p.add_argument("--no-trails", action="store_true", help="关未来腕部轨迹")
    p.add_argument("--no-mesh", action="store_true", help="关 MANO mesh（留骨架）")
    p.add_argument("--no-keypoints", action="store_true", help="关 21 关键点骨架")
    p.add_argument("--no-h264", action="store_true", help="不转 H.264（留 mp4v）")
    # 其它
    p.add_argument("--no-download", action="store_true",
                   help="缺失类别不自动补下载（只报错）")
    p.add_argument("--workers", type=int, default=4, help="补下载并发数")
    p.add_argument("--keep-staging", action="store_true",
                   help="保留 _staging/ 软链接目录（调试）")
    p.add_argument("--convert-mano", nargs=2, metavar=("RIGHT.pkl", "LEFT.pkl"),
                   help="一次性把 MANO pkl 转成 vendor assets npz")
    p.add_argument("--check", action="store_true", help="只做环境自检")
    p.add_argument("--token", help="ModelScope token（默认 .env）")
    return p.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(argv)

    if a.convert_mano:
        return convert_mano(a.convert_mano[0], a.convert_mano[1])
    if a.check:
        problems = check_env()
        for p_ in problems:
            print(f"  [fail] {p_}", file=sys.stderr)
        print("环境自检：", "全部通过" if not problems else f"{len(problems)} 项问题",
              file=sys.stderr)
        return 1 if problems else 0

    problems = check_env()
    fatal = [x for x in problems if "MANO" in x or "vendor" in x or "模块" in x]
    if fatal:
        for x in fatal:
            print(f"错误：{x}", file=sys.stderr)
        return 2

    sids = collect_samples(a)

    if not a.no_download:
        need = {s: missing_categories(s, a.data_root) for s in sids}
        to_fetch = [s for s, m in need.items() if m]
        if to_fetch:
            for s in to_fetch[:5]:
                print(f"  缺类别：{s} → {', '.join(need[s])}", file=sys.stderr)
            autofetch(to_fetch, a.data_root, a.token, a.workers)
            # 复核：仍缺则点名
            still = {s: missing_categories(s, a.data_root) for s in to_fetch}
            hard_missing = {s: m for s, m in still.items() if m}
            if hard_missing:
                for s, m in hard_missing.items():
                    print(f"  [warn] 补下载后仍缺（渲染相应降级）：{s} → {', '.join(m)}",
                          file=sys.stderr)

    return render_all(a, sids)


if __name__ == "__main__":
    raise SystemExit(main())
