#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 样本元数据解析与聚合 —— build_index / filter / quality_check 共用的业务层。

三类元数据（字段口径见 references/dataset-schema.md，以官方 README 为准）：
- ego_annotation/ego_action_annotation.json  → 数据源为标注 JSON（段+原子动作）
- video_info.json                             → 设备与原始内参（含畸变）
- ego_process/ego_undistorted_video/undistorted_video_info.json → 去畸变后的内参与 FOV（fps）

注意：
- 标注里的 start_ts/end_ts/start_frame/end_frame 均为字符串，先转数值再使用；
- bbox 为 raw_video.mp4 像素坐标（绝对像素，需对照 video_info.resolution 判定越界）；
- hands.npz 左手=[0]、右手=[1]（L2 深检用）。

索引行 schema（openaoe_index.parquet 一行 = 一个样本）：
    sample_id, status, n_segments, n_actions, duration_s, frames, fps,
    scenes(list), primary_scene, verbs(list), objects(list), tasks(list "verb+object"),
    hand_counts(dict), confidence_mean, confidence_min,
    device_brand, device_model, android_version,
    resolution, res_w, res_h, fov_x_deg, fov_y_deg,
    ts_continuous, frame_continuous, intrinsics_ok, distortion_ok,
    bbox_bad_count, bbox_oof_count, raw_video_bytes, video_info_bytes, anno_bytes,
    region, listed_at, revision_snapshot(dict)
"""
from __future__ import annotations

import json
import math
import re
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------
VALID_HANDS = ("left", "right", "both", "none")


def as_list(v) -> List[Any]:
    """parquet 读回的 list 列（np.ndarray / list / None）→ python list（避免 ndarray 真值歧义）。"""
    if v is None:
        return []
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    try:
        import numpy as _np
        if isinstance(v, _np.ndarray):
            return v.tolist()
    except ImportError:
        pass
    return []


def as_dict(v) -> Dict[str, Any]:
    """parquet 读回的 map 列 → python dict（pyarrow 可能给 list[tuple]）。"""
    if isinstance(v, dict):
        return v
    if isinstance(v, (list, tuple)):
        try:
            return {str(k): val for k, val in v}
        except (TypeError, ValueError):
            return {}
    try:
        if isinstance(v, __import__("numpy").ndarray) and v.dtype == object:
            return {str(k): val for k, val in v.tolist()}
    except Exception:
        pass
    return {}


def to_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    """OpenAoE 的 ts/frame 字段是字符串（'0.00'/'4103'），统一转数值。"""
    if x is None:
        return default
    if isinstance(x, bool):
        return float(x)
    try:
        return float(str(x).strip())
    except (TypeError, ValueError):
        return default


def to_int(x: Any, default: Optional[int] = None) -> Optional[int]:
    v = to_float(x)
    if v is None:
        return default
    try:
        return int(round(v))
    except (TypeError, ValueError, OverflowError):
        return default


def norm_token(s: Any) -> str:
    """场景/动词/物体归一：lower + 压空白。'Living Room' → 'living room'。"""
    if not s:
        return ""
    return re.sub(r"\s+", " ", str(s).strip().lower())


def parse_json_bytes(data: bytes) -> Any:
    if not data:
        raise ValueError("空响应")
    try:
        return json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        # LFS 元数据文件偶发带前导换行/说明文本，做一次包裹剥壳
        text = data.decode("utf-8", errors="replace").strip()
        if not text.startswith(("{", "[")):
            m = re.search(r"([\{\[].*[\}\]])\s*$", text, re.S)
            if m:
                return json.loads(m.group(1))
        raise ValueError(f"JSON 解析失败：{e}")


# ---------------------------------------------------------------------------
# 标注聚合
# ---------------------------------------------------------------------------
def summarize_annotation(segments: List[Dict[str, Any]]) -> Dict[str, Any]:
    """把 ego_action_annotation.json 的段列表聚合成索引/QC 指标（纯函数，不发请求）。

    返回字段（聚合结果；⚠ 其中 verb_counts/object_counts 仅内存态，不写索引 parquet）：
      n_segments, n_actions, duration_s, frames,
      scenes(list 去重), primary_scene(按段时长加权的主场景), verb_counts, object_counts(仅内存),
      tasks(list "verb+object"), hand_counts, confidence_mean/min/max,
      ts_continuous, frame_continuous（时间/帧连续性：首段从 0 起、相邻段首尾相接）,
      bbox_bad_count（负值或倒序）, bbox_oof_count(超出视频画幅),
      hand_bad_count（hand 不在合法枚举中）, seg_desc_blank_count
    """
    out: Dict[str, Any] = {
        "n_segments": len(segments) if segments else 0,
        "n_actions": 0,
        "duration_s": None,
        "frames": None,
        "scenes": [],
        "primary_scene": "",
        "verb_counts": {},
        "object_counts": {},
        "verb_durations": [],  # list<string> "verb:seconds:rank"（按 verb 累计时长降序 Top-N；内存安全）
        "verb_seconds_total": None,  # 各段时长之和（占比分母；主导动作时长占比 = verb秒 / 该值）
        "tasks": [],
        "hand_counts": {h: 0 for h in VALID_HANDS},
        "confidence_mean": None,
        "confidence_min": None,
        "confidence_max": None,
        "ts_continuous": True,
        "frame_continuous": True,
        "bbox_bad_count": 0,
        "bbox_oof_count": 0,
        "hand_bad_count": 0,
        "seg_desc_blank_count": 0,
    }
    scene_seconds: Dict[str, float] = {}
    verb_seconds: Dict[str, float] = {}  # verb -> 累计段时长（段级归因：段时长计入该段出现的每个 verb）
    total_seg_seconds: float = 0.0
    confidences: List[float] = []
    verbs: List[str] = []
    objects: List[str] = []
    task_pairs = set()
    frame_bounds: Tuple[Optional[int], Optional[int]] = (None, None)
    res_w = res_h = None  # 供 bbox 越界判断（由调用方后续传入时再重算一次仅作兜底）

    prev_end_ts: Optional[float] = None
    prev_end_frame: Optional[int] = None

    for i, seg in enumerate(segments or []):
        s_ts = to_float(seg.get("start_ts"))
        e_ts = to_float(seg.get("end_ts"))
        s_fr = to_int(seg.get("start_frame"))
        e_fr = to_int(seg.get("end_frame"))
        scene = norm_token(seg.get("scene"))
        if scene:
            scene_seconds[scene] = scene_seconds.get(scene, 0.0) + max(0.0, (e_ts or 0) - (s_ts or 0))

        # 连续性：首段起点必须为 0；相邻段 end == next.start。
        # 容差说明：早期 aoe_* 批次存在浮点舍入口径噪声（实测 24.0 vs 23.9945，
        # 差 0.005s ≈ 0.16 帧），按"≤ 分钟级空洞才是真 gap"的原则放开到 0.05s（约 1.5 帧）。
        if i == 0:
            if (s_ts or 0) != 0.0:
                out["ts_continuous"] = False
            if (s_fr or 0) != 0:
                out["frame_continuous"] = False
        else:
            if s_ts is None or prev_end_ts is None or abs(s_ts - prev_end_ts) > 0.05:
                out["ts_continuous"] = False
            if s_fr is None or prev_end_frame is None or abs(s_fr - prev_end_frame) > 1:
                out["frame_continuous"] = False
        prev_end_ts, prev_end_frame, frame_bounds = e_ts, e_fr, (s_fr, e_fr)

        actions = seg.get("atomic_action") or []
        if not actions:
            out["seg_desc_blank_count"] += 1
        seg_dur = max(0.0, (e_ts or 0) - (s_ts or 0))
        total_seg_seconds += seg_dur
        seg_verbs: set = set()
        for act in actions:
            out["n_actions"] += 1
            verb = norm_token(act.get("verb"))
            obj = norm_token(act.get("object"))
            hand = norm_token(act.get("hand"))
            if verb:
                verbs.append(verb)
                seg_verbs.add(verb)
                out["verb_counts"][verb] = out["verb_counts"].get(verb, 0) + 1
            if obj:
                objects.append(obj)
                out["object_counts"][obj] = out["object_counts"].get(obj, 0) + 1
            if verb and obj:
                task_pairs.add(f"{verb}+{obj}")
            if hand in VALID_HANDS:
                out["hand_counts"][hand] += 1
            elif hand:
                out["hand_bad_count"] += 1
            conf = to_float(act.get("confidence"))
            if conf is not None:
                confidences.append(conf)
            bbox = act.get("bbox")
            if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
                x1, y1, x2, y2 = (to_float(v) or 0 for v in bbox)
                if x2 <= x1 or y2 <= y1 or x1 < 0 or y1 < 0:
                    out["bbox_bad_count"] += 1
                elif res_w and res_h and (x2 > res_w or y2 > res_h):
                    out["bbox_oof_count"] += 1

        # 段级时长归因：本段时长计入该段出现的每个 verb（一段多 verb 则各计一次段时长）
        for v in seg_verbs:
            verb_seconds[v] = verb_seconds.get(v, 0.0) + seg_dur

    segments = segments or []
    if segments:
        last = segments[-1]
        out["duration_s"] = to_float(last.get("end_ts"))
        out["frames"] = to_int(last.get("end_frame"))
    if scene_seconds:
        out["scenes"] = sorted(scene_seconds.keys())
        out["primary_scene"] = max(scene_seconds.items(), key=lambda kv: kv[1])[0]
    out["verb_counts"] = dict(sorted(out["verb_counts"].items(), key=lambda kv: -kv[1]))
    out["object_counts"] = dict(sorted(out["object_counts"].items(), key=lambda kv: -kv[1])[:200])
    out["tasks"] = sorted(task_pairs)
    # verb 时长排名派生列（内存安全 list<string>："verb:seconds:rank"，按累计时长降序 Top-20）。
    # 主导动作时长占比 = seconds / verb_seconds_total。禁止用 {verb:秒} 变键 dict 入列（爆内存）。
    out["verb_seconds_total"] = round(total_seg_seconds, 3) if total_seg_seconds else 0.0
    ranked = sorted(verb_seconds.items(), key=lambda kv: -kv[1])[:20]
    out["verb_durations"] = [f"{v}:{round(sec, 2)}:{i + 1}" for i, (v, sec) in enumerate(ranked)]
    if confidences:
        out["confidence_mean"] = round(sum(confidences) / len(confidences), 4)
        out["confidence_min"] = min(confidences)
        out["confidence_max"] = max(confidences)
    return out


def _iter_actions(segments: List[Dict[str, Any]]):
    for seg in segments or []:
        for act in seg.get("atomic_action") or []:
            yield seg, act


def bbox_out_of_frame(segments: List[Dict[str, Any]], res_w: int, res_h: int) -> int:
    """bbox 相对视频画幅的越界计数（独立函数，供质检复检调用）。"""
    n = 0
    for _seg, act in _iter_actions(segments):
        bbox = act.get("bbox")
        if isinstance(bbox, (list, tuple)) and len(bbox) == 4:
            x1, y1, x2, y2 = (to_float(v) or 0 for v in bbox)
            if not (x2 <= x1 or y2 <= y1 or x1 < 0 or y1 < 0):
                if x2 > res_w or y2 > res_h:
                    n += 1
    return n


# ---------------------------------------------------------------------------
# video_info / undistorted_video_info 聚合
# ---------------------------------------------------------------------------
def summarize_video_info(vi: Dict[str, Any]) -> Dict[str, Any]:
    """video_info.json → 设备/内参/畸变指标。内参一致性即上游 PR #1 移除样本的问题类型。

    vi01 语义（2026-09-02 修正，见 resolve_intrinsics_ok 文档）：
    - 基础检查（intrinsics_base_ok）：分辨率可解析 / fx,fy>0 / 主点居中
    - 原始 fovH↔fx 自洽：**仅非广角样本参与**（isZoomWideAngle/isWideAngle=True 时 fovH
      报广角镜头原始视场，而 fx 是变焦裁剪后的有效内参，二者必然不自洽——实测全库
      8,685 个 zoomRatio=0.6 样本被误判；该对不代表矛盾）。
    - 真正对齐的一对是 vi.fx ↔ uv.fov_x（去畸变 FOV，实测变焦样本精确吻合），
      由 resolve_intrinsics_ok 在同时拿到 vi/uv 时做交叉覆盖。
    """
    dev = vi.get("deviceInfo") or {}
    cam = vi.get("cameraParams") or {}
    res = str(cam.get("resolution") or "")
    m = re.match(r"\s*(\d+)\s*[xX×]\s*(\d+)\s*", res)
    res_w = int(m.group(1)) if m else None
    res_h = int(m.group(2)) if m else None
    fx, fy = to_float(cam.get("fx_pixels")), to_float(cam.get("fy_pixels"))
    cx, cy = to_float(cam.get("cx_pixels")), to_float(cam.get("cy_pixels"))
    fov_h = to_float(cam.get("fovHorizontal_degrees"))
    fov_v = to_float(cam.get("fovVertical_degrees"))
    fps = to_float(cam.get("fps"))
    zoom_wide = bool(cam.get("isZoomWideAngle") or cam.get("isWideAngle"))

    # --- 基础检查（vi01 的①②③）---
    base_ok = True
    if not (res_w and res_h):
        base_ok = False  # 分辨率字段缺失/不合法
    if fx is not None and fps:
        if not (fx > 0 and fy and fy > 0):
            base_ok = False
    if res_w and res_h and cx is not None and cy is not None:
        if abs(cx - res_w / 2.0) > res_w * 0.25 or abs(cy - res_h / 2.0) > res_h * 0.35:
            base_ok = False  # 主点严重偏离画幅中心

    # --- 原始 fovH↔fx（④，仅非广角样本）---
    ok = base_ok
    if not zoom_wide:
        if res_w and fx and fx > 0 and fov_h and 0 < fov_h < 175:
            fx_from_fov = res_w / (2.0 * math.tan(math.radians(fov_h) / 2.0))
            if abs(fx_from_fov - fx) / fx > 0.08:
                ok = False

    # --- 畸变系数合法性（L1 规则 vi02）---
    dist_ok = True
    dist_raw = cam.get("lensDistortion")
    order = str(cam.get("lensDistortionOrder") or "k1,k2,k3,p1,p2").lower()
    dist_coeffs: List[float] = []
    if dist_raw is not None:
        try:
            dist_coeffs = [float(v) for v in re.findall(r"-?\d+\.?\d*(?:[eE][-+]?\d+)?", str(dist_raw))]
        except ValueError:
            dist_ok = False
        n_expected = order.count("k") + order.count("p")
        if not dist_coeffs or (n_expected and len(dist_coeffs) != n_expected):
            dist_ok = False
    else:
        dist_ok = False

    loc = vi.get("localization") or {}
    # 早期 aoe_* 批次缺 fovHorizontal/Vertical：由 fx + 分辨率反推（fov = 2·atan(w/(2fx))）
    if fov_h is None and res_w and fx and fx > 0:
        fov_h = math.degrees(2.0 * math.atan(res_w / (2.0 * fx)))
    if fov_v is None and res_h and fy and fy > 0:
        fov_v = math.degrees(2.0 * math.atan(res_h / (2.0 * fy)))
    return {
        "device_brand": norm_token(dev.get("brand")),
        "device_model": norm_token(dev.get("model")),
        "android_version": str(dev.get("androidVersion") or ""),
        "fps": fps,
        "resolution": norm_token(res).replace("x", "x"),
        "res_w": res_w,
        "res_h": res_h,
        "fov_h_deg": fov_h,
        "fov_v_deg": fov_v,
        "intrinsics_ok": ok,
        "intrinsics_base_ok": base_ok,   # 内部字段：①②③ 结论（不入索引列）
        "fx": fx,                        # 内部字段：供 resolve_intrinsics_ok 交叉校验
        "zoom_wide": zoom_wide,          # 内部字段：广角/变焦标记（vi01 ④ 跳过依据）
        "distortion_ok": dist_ok,
        "distortion_coeffs_n": len(dist_coeffs),
        "region": str(loc.get("region") or "") or str(loc.get("province") or ""),
        "perspective": norm_token(vi.get("perspective")),
    }


def intrinsics_consistent_fx_fov(res_w, fx, fov_x_deg, tol: float = 0.10) -> Optional[bool]:
    """vi.fx ↔ 去畸变 fov_x 的自洽校验（真正对齐的物理量；对变焦广角样本同样成立）。

    依据：undistorted_video_info.fov_x 是去畸变后与 fx 配套的实测视场（实测变焦样本
    raw_102864_seg_7：fx=855 ↔ fov_x=73.59°，反推值 855.0 精确吻合）；而原始 fovH 在
    广角样本上指镜头物理视场，与 fx 必然不自洽。返回 None 表示字段不足无法判。
    """
    if not (res_w and fx and fx > 0 and fov_x_deg and 0 < fov_x_deg < 175):
        return None
    fx_from_fov = res_w / (2.0 * math.tan(math.radians(fov_x_deg) / 2.0))
    return abs(fx_from_fov - fx) / fx <= tol


def resolve_intrinsics_ok(vi: Optional[Dict[str, Any]],
                          uv: Optional[Dict[str, Any]]) -> Optional[bool]:
    """vi01 的最终一致裁决（build_index_row 与 quality_check 在线模式共用）。

    优先级：
    1. vi 缺失 → None（无法判）
    2. 同时有 vi.fx 与 uv.fov_x → base_ok AND fx↔fov_x 自洽（真对齐对，覆盖 ④ 的结论）
    3. 否则 → vi.intrinsics_ok（summarize_video_info 已按 zoom_wide 跳过 ④ 的结果）
    """
    if not vi:
        return None
    base = vi.get("intrinsics_base_ok")
    cross = intrinsics_consistent_fx_fov(vi.get("res_w"), vi.get("fx"),
                                         (uv or {}).get("fov_x_deg"))
    if cross is not None:
        # 真对齐对可得 → 基础检查 AND fx↔去畸变fov 自洽（覆盖原始 fovH 结论）
        if base is None:
            return bool(cross)
        return bool(base) and bool(cross)
    return vi.get("intrinsics_ok")


def summarize_undistorted(uv: Dict[str, Any]) -> Dict[str, Any]:
    """undistorted_video_info.json → 去畸变 FOV（filter 的 FOV 维度口径）。

    批次差异：早期 aoe_* 批次 fps 在顶层（uv["fps"]），主批次在 cameraParams.fps —— 双兜底。
    """
    cam = uv.get("cameraParams") or {}
    dev = uv.get("deviceInfo") or {}
    res = str(cam.get("resolution") or "")
    m = re.match(r"\s*(\d+)\s*[xX×]\s*(\d+)\s*", res)
    return {
        "fov_x_deg": to_float(cam.get("fov_x_degrees")),
        "fov_y_deg": to_float(cam.get("fov_y_degrees")),
        "fps": to_float(uv.get("fps")) or to_float(cam.get("fps")),
        "resolution": norm_token(res),
        "res_w": int(m.group(1)) if m else None,
        "res_h": int(m.group(2)) if m else None,
        "fx": to_float(cam.get("fx_pixels")),
        "fy": to_float(cam.get("fy_pixels")),
        "device_brand": norm_token(dev.get("brand")),
    }


# ---------------------------------------------------------------------------
# 样本级远程文件路径（下载/质检类别映射）
# ---------------------------------------------------------------------------
PATHS = {
    "video_info": "{s}/video_info.json",
    "annotation": "{s}/ego_annotation/ego_action_annotation.json",
    "undistorted_info": "{s}/ego_process/ego_undistorted_video/undistorted_video_info.json",
    "undistorted_video": "{s}/ego_process/ego_undistorted_video/raw_video_undistorted.mp4",
    "hands": "{s}/ego_process/ego_hands_reconstruction/hands.npz",
    "camera_traj": "{s}/ego_process/ego_hands_reconstruction/camera_traj.npz",
    "overview": "{s}/ego_process/ego_hands_reconstruction/visualization/overview.png",
    "hands_video": "{s}/ego_process/ego_hands_reconstruction/visualization/hands_combined.mp4",
    "raw_video": "{s}/raw_video.mp4",
}
CATEGORY_LABELS = {  # 面向用户/报告展示；L2 深检用 hands+camera_traj
    "video_info": "相机参数 JSON video_info.json",
    "annotation": "原子动作标注 ego_action_annotation.json",
    "undistorted_info": "去畸变相机参数 JSON",
    "undistorted_video": "去畸变视频 raw_video_undistorted.mp4",
    "hands": "MANO 双手重建 hands.npz（受 MANO license 约束）",
    "camera_traj": "SLAM 相机轨迹 camera_traj.npz（受 MANO license 约束）",
    "overview": "轨迹总览图 overview.png",
    "hands_video": "手部网格可视化视频 hands_combined.mp4",
    "raw_video": "原始视频 raw_video.mp4（50–90MB LFS）",
}
SAMPLE_DIR_RE = re.compile(r"^(aoe_\d{8}_\d{6}_p\d+|raw_\d+_seg_\d+|aoe_.+)$")


def remote_path(sample_id: str, category: str) -> str:
    try:
        return PATHS[category].format(s=sample_id)
    except KeyError:
        raise KeyError(f"未知数据类别 {category}，可选：{', '.join(PATHS)}")


def is_sample_dir(name: str) -> bool:
    """根目录下合法样本目录的判定：排除 README/LICENSE 等根文件与隐藏目录。

    宽松策略（数据集仍在上传，命名可能引入新前缀）：以 tree 类型 + 非黑名单为样本候选，
    索引阶段对不合法样本会记录 status=misnamed（不默默丢弃）。
    """
    if not name or name.startswith("."):
        return False
    if name in {"LICENSE", "README.md", "scripts", "code", "docs"}:
        return False
    return True


# ---------------------------------------------------------------------------
# 索引行构建
# ---------------------------------------------------------------------------
def build_index_row(sample_id: str,
                    anno: Optional[Dict[str, Any]],
                    vi: Optional[Dict[str, Any]],
                    uv: Optional[Dict[str, Any]],
                    video_size: Optional[int],
                    anno_bytes: Optional[int],
                    sizes: Optional[Dict[str, int]] = None) -> Dict[str, Any]:
    """合并三类元数据的聚合结果 → 一行索引记录（含 status 与失败原因标记）。"""
    row: Dict[str, Any] = {
        "sample_id": sample_id,
        "status": "ok",
        "status_detail": "",
        "n_segments": None, "n_actions": None, "duration_s": None, "frames": None,
        "scenes": [], "primary_scene": None,
        "tasks": [],
        "verb_durations": [], "verb_seconds_total": None,
        "hand_counts": {}, "confidence_mean": None, "confidence_min": None,
        "device_brand": None, "device_model": None, "android_version": None,
        "resolution": None, "res_w": None, "res_h": None, "fps": None,
        "fov_x_deg": None, "fov_y_deg": None, "fov_h_deg": None, "fov_v_deg": None,
        "ts_continuous": None, "frame_continuous": None,
        "intrinsics_ok": None, "distortion_ok": None,
        "bbox_bad_count": None, "bbox_oof_count": None, "hand_bad_count": None,
        "n_confident_actions": None,
        "raw_video_bytes": video_size, "anno_bytes": anno_bytes,
        "hands_bytes": (sizes or {}).get("hands"),
        "region": None,
    }

    def _fill(target, source, keys):
        for k in keys:
            if source is not None and source.get(k) is not None:
                target[k] = source.get(k)

    missing: List[str] = []
    if anno:
        _fill(row, anno, [
            "n_segments", "n_actions", "duration_s", "frames", "scenes", "primary_scene",
            "tasks", "hand_counts",
            "verb_durations", "verb_seconds_total",
            "confidence_mean", "confidence_min",
            "ts_continuous", "frame_continuous",
            "bbox_bad_count", "bbox_oof_count", "hand_bad_count",
        ])
        # 注：verb_counts/object_counts 不入索引行 —— 变键 dict 列在 pandas→parquet
        # 会被推断为"struct 联合集"，读回时每行物化全库键集合（实测 1.5 万行 = 39GB），
        # 动词/物体统计一律由 tasks 列（list<string>）现算派生。
    else:
        missing.append("annotation")
    if vi:
        _fill(row, vi, [
            "device_brand", "device_model", "android_version", "fps",
            "resolution", "res_w", "res_h", "fov_h_deg", "fov_v_deg",
            "intrinsics_ok", "distortion_ok", "region",
        ])
    else:
        missing.append("video_info")
    if uv:
        _fill(row, uv, ["fov_x_deg", "fov_y_deg"])
        # vi01 覆盖：去畸变 fov_x 可得 → 用"真对齐对"(vi.fx↔uv.fov_x)重裁决内参一致性
        resolved = resolve_intrinsics_ok(vi, uv)
        if resolved is not None:
            row["intrinsics_ok"] = resolved
        # fps/分辨率批次兜底：早期 aoe_* 批次的 video_info 无 fps，用 undistorted 的
        if row.get("fps") is None:
            _fill(row, uv, ["fps"])
        if row.get("resolution") is None and uv.get("resolution"):
            row["resolution"] = uv["resolution"]
    else:
        missing.append("undistorted_info")

    if missing:
        row["status"] = "partial" if bool(anno or vi or uv) else "missing"
        row["status_detail"] = ",".join(missing)
    return row


# parquet 列序固定。⚠ 变键 dict 禁止入列（见 build_index_row 注释）；
# hand_counts 为固定 4 键 struct、scenes/tasks 为 list<string>，均为内存安全类型。
# verb/object 统计由 tasks 派生（filter --verb/--object、visualize verb 维度）。
INDEX_COLUMNS = [
    "sample_id", "status", "status_detail",
    "n_segments", "n_actions", "duration_s", "frames", "fps",
    "scenes", "primary_scene", "tasks",
    "verb_durations", "verb_seconds_total",
    "hand_counts", "confidence_mean", "confidence_min",
    "device_brand", "device_model", "android_version",
    "resolution", "res_w", "res_h", "fov_x_deg", "fov_y_deg",
    "fov_h_deg", "fov_v_deg",
    "ts_continuous", "frame_continuous", "intrinsics_ok", "distortion_ok",
    "bbox_bad_count", "bbox_oof_count", "hand_bad_count",
    "raw_video_bytes", "anno_bytes", "hands_bytes", "region",
]
