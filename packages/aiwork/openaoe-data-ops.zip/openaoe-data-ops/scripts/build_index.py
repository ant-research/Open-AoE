#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 索引构建主脚本（内存有界的流式版本）。

内存设计（针对"本地内存有限"的关键约束，2026-09 实测重构）：
- 每个样本仅在内存里流转 3 个小 JSON（~9KB），解析完即弃，只保留聚合后的 1 行（~1KB）；
- 行按批（默认 500 行）写入独立分片 parquet（<out>.parts/batch_XXXXX.parquet），
  **从不整文件读回**（旧版"读回+concat+重写"会随文件增长引爆内存，已废弃）；
- 结束时用 ParquetWriter 逐分片压缩合并（一次只持有一个分片的 Table）；
- 旧索引自动迁移：**列投影读取**（跳过历史遗留的变键 dict 列），转换为新 schema 分片。
- 汇总统计用 parquet 元数据（null_count）与单列读取，不整表物化。

⚠ 数据契约：索引列固定为 aoe_parsing.INDEX_COLUMNS（不含 verb_counts/object_counts——
变键 dict 列在 parquet 会变成"struct 联合集"，读回时每行物化全库键集合，
实测 1.5 万行即 39GB；动词/物体维度由 tasks 列实时派生）。

索引策略：
- 全量：并发拉取全部样本的 3 个元数据 JSON（video_info / undistorted_video_info /
  ego_action_annotation）+ tree 体积探测；一次构建多次复用。
- 版本水位：state 记 revision 快照（dataset_id/gmt_modified/root_total），供下游判过期。
- 断点/增量：state 记 done 列表；中断重跑同一命令自动续；--incremental 对比根目录差集。

用法示例：
    python3 build_index.py --out .cache/index.parquet
    python3 build_index.py --incremental --out .cache/index.parquet
    python3 build_index.py --limit 20 --out /tmp/index_smoke.parquet   # 冒烟
    python3 build_index.py --workers 16
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from aoe_parsing import (  # noqa: E402
    INDEX_COLUMNS, VALID_HANDS, build_index_row, is_sample_dir, parse_json_bytes,
    resolve_intrinsics_ok, summarize_annotation, summarize_undistorted,
    summarize_video_info, bbox_out_of_frame, remote_path)
from openaoe_client import ApiError, OpenAoEClient  # noqa: E402

_print_lock = threading.Lock()


def log(msg: str) -> None:
    with _print_lock:
        print(msg, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# 目标 arrow schema（确定性类型，避免批次间类型漂移 / 全 None 列塌缩为 null type）
# ---------------------------------------------------------------------------
_INT_COLS = {"n_segments", "n_actions", "frames", "res_w", "res_h",
             "bbox_bad_count", "bbox_oof_count", "hand_bad_count",
             "raw_video_bytes", "anno_bytes", "hands_bytes", "n_confident_actions"}
_FLOAT_COLS = {"duration_s", "fps", "fov_x_deg", "fov_y_deg", "fov_h_deg", "fov_v_deg",
               "confidence_mean", "confidence_min", "verb_seconds_total"}
_BOOL_COLS = {"ts_continuous", "frame_continuous", "intrinsics_ok", "distortion_ok"}
_LIST_COLS = {"scenes", "tasks", "verb_durations"}  # verb_durations: list<string> "verb:secs:rank"（内存安全）
_STRUCT_COLS = {"hand_counts"}  # 固定 4 键（left/right/both/none）——安全；变键 dict 禁入


def target_schema() -> pa.Schema:
    fields = []
    for col in INDEX_COLUMNS:
        if col in _STRUCT_COLS:
            ty = pa.struct([pa.field(k, pa.int64(), nullable=True) for k in VALID_HANDS])
        elif col in _LIST_COLS:
            ty = pa.list_(pa.string())
        elif col in _INT_COLS:
            ty = pa.int64()
        elif col in _FLOAT_COLS:
            ty = pa.float64()
        elif col in _BOOL_COLS:
            ty = pa.bool_()
        else:
            ty = pa.string()
        fields.append(pa.field(col, ty, nullable=True))
    return pa.schema(fields)


def _align_to_target(tbl: pa.Table, schema: pa.Schema) -> pa.Table:
    """把任意历史批次的表对齐到目标 schema（列序 + 类型 coercion）。

    兼容点：hand_counts 旧文件可能是 map<string,int>（pandas dict 推断），
    需逐行转 4 键 struct；其余列按位置 cast。
    """
    # hand_counts: map/struct → 固定 4 键 struct（行数 ≤ 单分片/旧全表 23k，安全）
    if "hand_counts" in tbl.schema.names:
        idx = tbl.schema.get_field_index("hand_counts")
        want = schema.field(schema.get_field_index("hand_counts")).type
        if tbl.schema.field(idx).type != want:
            vals = []
            for v in tbl.column(idx).to_pylist():
                if v is None:
                    vals.append(None)
                elif isinstance(v, dict):
                    vals.append({k: v.get(k) for k in VALID_HANDS})
                else:  # map → list[(k,v)]
                    vals.append({k: dict(v).get(k) for k in VALID_HANDS})
            arr = pa.array(vals, type=want)
            tbl = tbl.set_column(idx, tbl.schema.field(idx).name, arr)
    # 列序对齐（schema 子集到全集：本契约下列集相同）
    present = [n for n in schema.names if n in tbl.schema.names]
    tbl = tbl.select(present)
    if tbl.schema.names != schema.names:
        # 补齐缺失列（全部 null）
        for name in schema.names:
            if name not in tbl.schema.names:
                field_type = schema.field(schema.get_field_index(name)).type
                tbl = tbl.append_column(
                    pa.field(name, field_type, nullable=True),
                    pa.nulls(tbl.num_rows, type=field_type))
        # 补齐的列 append 到末尾，需按目标 schema 列序重排后再 cast（cast 要求列序一致）
        tbl = tbl.select(list(schema.names))
    return tbl.cast(schema)


# ---------------------------------------------------------------------------
# 单个样本的元数据抓取任务【运行期不变：每样本 ~9KB 流转，样本级容错】
# ---------------------------------------------------------------------------
def fetch_sample_row(client: OpenAoEClient, sample_id: str,
                     fetch_sizes: bool = True) -> Dict[str, Any]:
    """下载一个样本的 3 个元数据 JSON + 顶层体积 → 索引行（失败记录于 status，不抛出）。"""
    sizes: Dict[str, int] = {}
    raw_video_size: Optional[int] = None
    if fetch_sizes:
        try:
            for e in client.list_dir(sample_id, page_size=100):
                if e.get("Type") == "blob":
                    name = os.path.basename(e.get("Path", ""))
                    if name == "raw_video.mp4":
                        raw_video_size = e.get("Size")
                    elif name == "video_info.json":
                        sizes["video_info"] = e.get("Size")
        except ApiError:
            pass  # tree 拉取失败：让 3 个 JSON 的下载再兜底

    anno = vi = uv = None
    anno_segments: Optional[List[Dict[str, Any]]] = None
    anno_bytes: Optional[int] = None
    errors: List[str] = []
    # 串行 3 个请求（样本内天然顺序），样本级并发由外层线程池承载
    try:
        data = client.download_bytes(remote_path(sample_id, "annotation"))
        anno_segments = parse_json_bytes(data)
        anno = summarize_annotation(anno_segments)
        anno_bytes = len(data)
    except (ApiError, ValueError) as e:
        errors.append(f"annotation:{type(e).__name__}")
    try:
        data = client.download_bytes(remote_path(sample_id, "video_info"))
        vi = summarize_video_info(parse_json_bytes(data))
    except (ApiError, ValueError):
        errors.append("vi")
    try:
        data = client.download_bytes(remote_path(sample_id, "undistorted_info"))
        uv = summarize_undistorted(parse_json_bytes(data))
    except (ApiError, ValueError):
        errors.append("uv")

    row = build_index_row(sample_id, anno, vi, uv, raw_video_size, anno_bytes, sizes)

    # bbox 出画幅判定需要分辨率（聚合阶段无上下文，此处用原始 segments + video_info 复算）
    if anno_segments is not None and vi and vi.get("res_w") and vi.get("res_h") \
            and row.get("bbox_bad_count") is not None:
        try:
            row["bbox_oof_count"] = bbox_out_of_frame(
                anno_segments, vi["res_w"], vi["res_h"])
        except Exception:
            pass

    if errors:
        detail = row.get("status_detail") or ""
        row["status_detail"] = (detail + ";" + ",".join(errors)).strip(";")
        if row["status"] == "ok":
            row["status"] = "partial"
    return row


# ---------------------------------------------------------------------------
# 流式分片存储（核心内存保证：任意时刻只持有一个批次的行）
# ---------------------------------------------------------------------------
class PartStore:
    """分片 parquet 存储：批次落独立小文件，结束一次合并。

    - write_batch：DataFrame(≤flush 行) → arrow cast(target_schema) → 独立分片
    - migrate_legacy：旧主文件 → **列投影读取** → cast → 转为分片 0
      （投影是关键：旧文件中的变键 dict struct 列若整表物化会爆内存）
    - compact：逐分片 write_table（每次只持有一个分片），生成最终 parquet
    """

    def __init__(self, out_path: str):
        self.out = out_path
        self.parts_dir = out_path + ".parts"
        os.makedirs(self.parts_dir, exist_ok=True)
        self.schema = target_schema()

    # ---- 分片枚举 ----
    def iter_parts(self) -> List[str]:
        if os.path.isdir(self.parts_dir):
            return sorted(os.path.join(self.parts_dir, n)
                          for n in os.listdir(self.parts_dir) if n.endswith(".parquet"))
        return []

    # ---- 旧主文件迁移（列投影，内存有界） ----
    def migrate_legacy(self) -> Optional[str]:
        if not os.path.isfile(self.out) or self.iter_parts():
            return None
        # 只读新 schema 需要的列 → 跳过历史变键 dict 列（object_counts 等）的物化。
        # 旧索引可能缺少后续新增的列（如 verb_durations）：只投影旧文件里实际存在的列，
        # 缺失列由 _align_to_target 统一补 null（否则 pyarrow 会因请求不存在的列报错）。
        legacy_names = set(pq.ParquetFile(self.out).schema_arrow.names)
        read_cols = [c for c in INDEX_COLUMNS if c in legacy_names]
        tbl = pq.read_table(self.out, columns=read_cols)
        tbl = _align_to_target(tbl, self.schema)
        part0 = os.path.join(self.parts_dir, "batch_00000_legacy.parquet")
        pq.write_table(tbl, part0)
        os.remove(self.out)  # 主文件由 compact 重建
        for stray in (self.out + ".tmp",):
            if os.path.isfile(stray):
                os.remove(stray)
        return part0

    # ---- 断点：已持久化样本集合（列投影读 sample_id，内存 ~MB 级） ----
    def done_ids(self) -> set:
        ids: set = set()
        for p in self.iter_parts():
            try:
                tbl = pq.read_table(p, columns=["sample_id"])
                ids.update(t for t in tbl.column(0).to_pylist() if t)
            except Exception:
                continue
        return ids

    # ---- 批次写入 ----
    def write_batch(self, rows: List[Dict[str, Any]]) -> int:
        if not rows:
            return 0
        df = pd.DataFrame.from_records(rows, columns=INDEX_COLUMNS)
        # dict/list 归一（ndarray/None 兜底已在 aoe_parsing.as_*；此处保证 dict→struct 安全）
        tbl = pa.Table.from_pandas(df, schema=self.schema, preserve_index=False)
        seq = len(self.iter_parts())
        path = os.path.join(self.parts_dir, f"batch_{seq:05d}.parquet")
        pq.write_table(tbl, path)
        return tbl.num_rows

    # ---- 终态合并：流式逐分片 ----
    def compact(self) -> Dict[str, Any]:
        parts = self.iter_parts()
        if not parts:
            return {"n_files": 0, "n_rows": 0}
        tmp = self.out + ".tmp"
        n_rows = 0
        with pq.ParquetWriter(tmp, self.schema) as writer:
            for p in parts:  # 一次只在内存持有一个分片
                tbl = pq.read_table(p, memory_map=True, columns=INDEX_COLUMNS)
                tbl = _align_to_target(tbl, self.schema)
                writer.write_table(tbl)
                n_rows += tbl.num_rows
                del tbl
        os.replace(tmp, self.out)
        shutil.rmtree(self.parts_dir, ignore_errors=True)
        return {"n_files": len(parts), "n_rows": n_rows}


# ---------------------------------------------------------------------------
# 状态文件（revision 水位 + done 名单；纯 JSON 小文件，增量重写可接受）
# ---------------------------------------------------------------------------
def save_state(state_path: str, revision: Dict[str, Any], done: List[str],
               failed: List[str], finished: bool, built_at: str,
               extra: Optional[Dict[str, Any]] = None) -> None:
    payload = {"dataset_id": revision.get("dataset_id"), "revision": revision,
               "built_at": built_at, "done": done, "failed": failed,
               "finished": finished, "n_done": len(done)}
    if extra:
        payload.update(extra)  # 维护模式追加字段（如 intrinsics_refreshed_at）
    tmp = state_path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False)
    os.replace(tmp, state_path)


def load_state(state_path: str) -> Dict[str, Any]:
    if os.path.isfile(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, json.JSONDecodeError):
            pass
    return {}


# ---------------------------------------------------------------------------
# 汇总统计（parquet 元数据驱动，不整表物化 pandas）
# ---------------------------------------------------------------------------
def summarize_output(parquet_path: str) -> Dict[str, Any]:
    if not os.path.isfile(parquet_path):
        return {}
    pf = pq.ParquetFile(parquet_path)
    n_rows = pf.metadata.num_rows
    schema = pf.schema_arrow

    # status 计数（单列读取，23k 小字符串）
    # ⚠ 必须用 Counter 累加：dict.update(mapping) 是按 key 覆盖，会只剩最后一个 row group
    status_counter: Counter = Counter()
    for i in range(pf.num_row_groups):
        col = pf.read_row_group(i, columns=["status"])["status"].to_pylist()
        status_counter.update(Counter(s or "None" for s in col))

    # 字段完整率：row-group 列统计的 null_count 求和（无 Python 物化）
    completeness: Dict[str, float] = {}
    focus = ["primary_scene", "duration_s", "device_brand", "resolution",
             "fov_x_deg", "tasks", "confidence_mean"]
    for name in focus:
        if name not in schema.names:
            continue
        nulls = 0
        have_stats = False
        for i in range(pf.num_row_groups):
            idx_col = schema.get_field_index(name)
            st = pf.metadata.row_group(i).column(idx_col).statistics
            if st is None:
                have_stats = False
                break
            have_stats = True
            nulls += (st.null_count or 0)
        if have_stats and n_rows:
            completeness[name] = round((n_rows - nulls) / n_rows * 100, 1)
    return {"n_rows": n_rows, "status_counts": dict(status_counter),
            "completeness": completeness, "row_groups": pf.num_row_groups}


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def parse_args(argv=None):
    p = argparse.ArgumentParser(description="构建/更新 OpenAoE-2000h 元数据索引（流式，内存有界）")
    p.add_argument("--out", default=".cache/index.parquet", help="索引 parquet 输出路径")
    p.add_argument("--token", help="ModelScope token（默认 .env / OPENAOE_MS_TOKEN）")
    p.add_argument("--workers", type=int, default=12, help="并发样本数（自适应限流会自动降速）")
    p.add_argument("--limit", type=int, default=None, help="只处理前 N 个样本（冒烟/抽样）")
    p.add_argument("--incremental", action="store_true",
                   help="增量模式：仅拉取数据集中新出现的样本目录")
    p.add_argument("--no-sizes", action="store_true", help="跳过 tree 体积探测（省 1 请求/样本）")
    p.add_argument("--flush-interval", type=int, default=500, help="每 N 行写一个分片（内存上界）")
    p.add_argument("--only", metavar="ID[,ID...]", help="只构建指定样本（调试用）")
    p.add_argument("--refresh-intrinsics", action="store_true",
                   help="维护模式：重判全库 intrinsics_ok（vi01 规则修正后无需全量重建；"
                        "只拉每样本 vi+uv 两个 JSON，逐 row-group 内存安全 patch）")
    return p.parse_args(argv)


# ---------------------------------------------------------------------------
# 维护模式：--refresh-intrinsics
#  背景：vi01 旧语义把广角/变焦样本（isZoomWideAngle=true，全库 36.7%）的
#  "原始fovH(镜头物理视场) ↔ fx(变焦裁剪后内参)" 不自洽误判为坏样本。
#  新语义 = resolve_intrinsics_ok（vi.fx ↔ uv.fov_x 真对齐对交叉校验）。
# ---------------------------------------------------------------------------
def _refetch_intrinsics(client: OpenAoEClient, sample_id: str) -> Optional[bool]:
    """拉取一个样本的 vi+uv 两个 JSON → resolve_intrinsics_ok 新结论（失败返回 None）。"""
    try:
        vi = summarize_video_info(parse_json_bytes(
            client.download_bytes(remote_path(sample_id, "video_info"))))
        uv = summarize_undistorted(parse_json_bytes(
            client.download_bytes(remote_path(sample_id, "undistorted_info"))))
        return resolve_intrinsics_ok(vi, uv)
    except (ApiError, ValueError):
        return None


def refresh_intrinsics(out_path: str, client: OpenAoEClient,
                       workers: int, state_path: str) -> int:
    pf = pq.ParquetFile(out_path)
    n_rows = pf.metadata.num_rows
    # 候选 = 候选集（旧 false ∨ 广角疑似 fov_h 与 fov_x 偏差>2°∨缺失标志）：
    # True 且 fov_h≈fov_x 的行不会翻转结果（cross 与原始fov一致）
    candid: Dict[str, None] = {}
    for i in range(pf.num_row_groups):
        tbl = pf.read_row_group(i, columns=["sample_id", "intrinsics_ok",
                                            "fov_h_deg", "fov_x_deg"])
        ids = tbl["sample_id"].to_pylist()
        ok = tbl["intrinsics_ok"].to_pylist()
        fh = tbl["fov_h_deg"].to_pylist()
        fx = tbl["fov_x_deg"].to_pylist()
        for sid, o, h, x in zip(ids, ok, fh, fx):
            suspect = (o is False) or (h is None or x is None or abs(h - x) > 2.0)
            if suspect:
                candid.setdefault(sid, None)
    log(f"    刷新候选：{len(candid)} 行（intrinsics_ok=False 或 广角疑似）")

    verdicts: Dict[str, Optional[bool]] = {}
    done = 0
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futs = {pool.submit(_refetch_intrinsics, client, sid): sid for sid in candid}
        for fut in as_completed(futs):
            verdicts[futs[fut]] = fut.result()
            done += 1
            if done % 500 == 0:
                rate = done / max(1e-6, time.time() - t0)
                log(f"    重判进度 {done}/{len(candid)} ({rate:.1f}/s)")
    if not verdicts:
        log("    无需刷新")
        return 0

    # 逐 row-group patch（每次只持有一个 row group 的表，内存有界）
    tmp = out_path + ".refresh.tmp"
    schema = target_schema()
    patched = 0
    with pq.ParquetWriter(tmp, schema) as writer:
        for i in range(pf.num_row_groups):
            tbl = pf.read_row_group(i)
            tbl = _align_to_target(tbl, schema)
            ids = tbl["sample_id"].to_pylist()
            col_idx = schema.get_field_index("intrinsics_ok")
            old = tbl.column(col_idx).to_pylist()
            # 新值 = 重判结论；无法判（拉取失败 None）→ 维持原值
            new = [(verdicts[sid] if (sid in verdicts and verdicts[sid] is not None) else v)
                   for sid, v in zip(ids, old)]
            patched += sum(1 for a, b in zip(old, new) if a != b)
            arr = pa.array(new, type=pa.bool_())
            tbl = tbl.set_column(col_idx, schema.field(col_idx).name, arr)
            writer.write_table(tbl)
            del tbl
    os.replace(tmp, out_path)
    log(f"    已改写 {patched} 行（拉取失败的候选维持原判）")

    # state：追加刷新记录（不动 done 名单与 revision 水位语义）
    st = load_state(state_path)
    extra = {"intrinsics_refreshed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
             "intrinsics_rule": "vi1.1：fx↔去畸变fov_x 交叉；zoom-wide 跳过原始fovH"}
    save_state(state_path, st.get("revision") or {}, st.get("done") or [],
               st.get("failed") or [], True, st.get("built_at") or "", extra=extra)

    # 刷新后 intrinsics_ok 统计（单列读取）
    n_false = 0
    pf2 = pq.ParquetFile(out_path)
    for i in range(pf2.num_row_groups):
        vals = pf2.read_row_group(i, columns=["intrinsics_ok"])["intrinsics_ok"].to_pylist()
        n_false += sum(1 for v in vals if v is False)
    log(f"[refresh-intrinsics] 完成：rows={n_rows}，刷新后 intrinsics_ok=False "
        f"{n_false}（用时 {time.time()-t0:.0f}s）")
    return 0


def main(argv=None) -> int:
    args = parse_args(argv)
    out_path = os.path.abspath(args.out)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    state_path = out_path + ".state.json"
    client = OpenAoEClient(token=args.token, quiet=False)

    if args.refresh_intrinsics:
        if not os.path.isfile(out_path):
            log(f"错误：索引不存在 {out_path}，先全量构建")
            return 2
        log("[refresh-intrinsics] 按 vi1.1 语义重判 intrinsics_ok …")
        return refresh_intrinsics(out_path, client, args.workers, state_path)

    log("[1/5] 读取数据集 revision 快照…")
    revision = client.revision_snapshot()
    log(f"    dataset_id={revision['dataset_id']} root_total={revision['root_total']} "
        f"gmt_modified={revision['dataset_gmt_modified']} captured_at={revision['captured_at']}")

    log("[2/5] 准备存储（迁移旧索引 / 断点恢复）…")
    store = PartStore(out_path)
    migrated = store.migrate_legacy()
    if migrated:
        log(f"    旧主文件已列投影迁移为分片：{os.path.basename(migrated)}")
    durable_ids = store.done_ids()
    state = load_state(state_path)
    # 持久化真值 = 分片里的行；state.done 仅作对账报告
    existing_ids = set(durable_ids)
    dropped_unflushed = len(set(state.get("done") or [])) - len(durable_ids)
    if existing_ids:
        log(f"    已有持久化样本：{len(existing_ids)} 个（断点续跑/增量模式）")
    if dropped_unflushed > 0:
        log(f"    注：上次中断有 {dropped_unflushed} 个样本已完成但未落盘，将重取")

    log("[3/5] 枚举根目录样本列表（分页遍历）…")
    sample_ids: List[str] = []
    for entry in client.iter_tree("", page_size=500):
        if entry.get("Type") != "tree":
            continue
        name = os.path.basename(entry.get("Path", ""))
        if is_sample_dir(name):
            sample_ids.append(name)
    log(f"    当前根目录共 {len(sample_ids)} 个样本目录（root_total={revision['root_total']} 含根文件）")

    if args.only:
        todo_ids = [s.strip() for s in args.only.split(",") if s.strip()]
    else:
        todo_ids = [s for s in sample_ids if s not in existing_ids]
    if args.limit is not None:
        todo_ids = todo_ids[: args.limit]
    log(f"[4/5] 待抓取样本：{len(todo_ids)} 个（workers={args.workers}，"
        f"每 {args.flush_interval} 行落一个分片）")

    built_at = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    t0 = time.time()
    n_done = 0
    n_failed_new: List[str] = []
    buffer_rows: List[Dict[str, Any]] = []
    done_list = list(existing_ids)

    def _persist_if_due(force: bool = False) -> None:
        nonlocal buffer_rows
        if buffer_rows and (force or len(buffer_rows) >= args.flush_interval):
            store.write_batch(buffer_rows)
            buffer_rows = []
            # done 名单与分片同步落盘（每 flush 一次）
            save_state(state_path, revision, done_list,
                       (state.get("failed") or []) + n_failed_new, False, built_at)

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {pool.submit(fetch_sample_row, client, sid, not args.no_sizes): sid
                   for sid in todo_ids}
        for fut in as_completed(futures):
            sid = futures[fut]
            try:
                row = fut.result()
            except Exception as e:  # 意外强错误（网络层已自兜底重试）
                row = build_index_row(sid, None, None, None, None, None)
                row["status"] = "error"
                row["status_detail"] = f"{type(e).__name__}:{e}"[:200]
                n_failed_new.append(sid)
            buffer_rows.append(row)
            done_list.append(sid)
            n_done += 1
            if n_done % 200 == 0:
                rate = n_done / max(1e-6, time.time() - t0)
                eta = (len(todo_ids) - n_done) / max(1e-6, rate)
                log(f"    进度 {n_done}/{len(todo_ids)}  "
                    f"({rate:.1f} 样本/s, ETA {eta / 60:.0f}min, throttle={client.throttle.delay:.2f}s)")
            _persist_if_due()

    _persist_if_due(force=True)

    log("[5/5] 压缩合并分片 → 主索引 parquet…")
    comp = store.compact()
    stats = summarize_output(out_path)
    save_state(state_path, revision, done_list,
               (state.get("failed") or []) + n_failed_new, True, built_at)

    # ---- 控制台汇总（元数据驱动，无 pandas 整表加载） ----
    log("")
    log("=" * 62)
    log(f"索引完成：{out_path}")
    log(f"  样本总数：{stats.get('n_rows', 0)}（合并 {comp.get('n_files', 0)} 个分片，"
        f"row_groups={stats.get('row_groups', 0)}）")
    log(f"  状态分布：{stats.get('status_counts')}")
    log(f"  关键字段完整率：{stats.get('completeness')}")
    log(f"  revision 快照：gmt_modified={revision['dataset_gmt_modified']} "
        f"root_total={revision['root_total']}（state 已记录，供增量/过期判断）")
    log(f"  用时 {time.time() - t0:.1f}s，被限流 {client.throttle.rate_limited_count} 次")
    log("=" * 62)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
