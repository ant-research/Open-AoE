#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 索引可视化 → 维度分布图 + 交叉热力图 + 抽样样本卡片（工作流 Phase 4）。

产出（均保存到 --out 目录）：
- dist_<dim>.png      单维分布：类别列 bar（top-N）/ 数值列直方图
- cross_<a>__<b>.png   交叉热力图（--cross scene,hand 等，两维计数热力）
- sample_cards.png     抽样样本卡片（在线下载 overview.png 拼网格，--sample-cards N>0 时）
- _gallery.md          图集索引（SkILL 交付物中引用）

维度支持：scene, duration, verb, task, resolution, hand, fps, fov_x, fov_y,
confidence, device, brand, segments, android, region

用法示例：
    python3 visualize.py --index .cache/index.parquet --dims scene,duration,verb,resolution
    python3 visualize.py --index .cache/index.parquet --cross scene,hand
    python3 visualize.py --index .cache/index.parquet --sample-cards 12  # 抽样卡片
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from aoe_parsing import as_dict, as_list, remote_path  # noqa: E402
from openaoe_client import OpenAoEClient  # noqa: E402

CATEGORICAL_DIMS = {"scene", "verb", "task", "resolution", "hand", "device", "brand",
                    "android", "region", "primary_scene", "status"}
NUMERIC_DIMS = {"duration", "fps", "fov_x", "fov_y", "confidence", "segments", "frames"}
COLUMN_OF = {
    "scene": ("scenes", "list"), "verb": ("tasks", "verb"), "task": ("tasks", "list"),
    "resolution": ("resolution", "scalar"), "hand": ("hand_counts", "dict3"),
    "device": ("device_model", "scalar"), "brand": ("device_brand", "scalar"),
    "android": ("android_version", "scalar"), "region": ("region", "scalar"),
    "primary_scene": ("primary_scene", "scalar"), "status": ("status", "scalar"),
    "duration": ("duration_s", "scalar"), "fps": ("fps", "scalar"),
    "fov_x": ("fov_x_deg", "scalar"), "fov_y": ("fov_y_deg", "scalar"),
    "confidence": ("confidence_mean", "scalar"), "segments": ("n_segments", "scalar"),
    "frames": ("frames", "scalar"),
}


def iter_dim_values(df: pd.DataFrame, dim: str):
    """把一个维度展开成多行 (value)；scalar 列直接数值/字符串化。"""
    col, kind = COLUMN_OF[dim]
    series = df[col] if col in df.columns else None
    if series is None:
        return
    idx_values = df["sample_id"].tolist()
    for sid, v in zip(idx_values, series.tolist()):
        if kind == "list":
            for item in as_list(v):
                yield sid, item
        elif kind == "verb":
            for pair in as_list(v):
                yield sid, str(pair).partition("+")[0]
        elif kind == "dict3":
            for k, n in as_dict(v).items():
                for _ in range(int(n or 0)):
                    yield sid, k
        else:
            if v is not None and v == v:  # NaN 过滤
                yield sid, v


def top_value_counts(df: pd.DataFrame, dim: str, top_n: int = 20) -> Dict[str, int]:
    cnt: Dict = {}
    for _sid, v in iter_dim_values(df, dim):
        key = str(v)
        cnt[key] = cnt.get(key, 0) + 1
    items = sorted(cnt.items(), key=lambda kv: -kv[1])[:top_n]
    return dict(items)


def hist_values(df: pd.DataFrame, dim: str) -> List[float]:
    vals: List[float] = []
    for _sid, v in iter_dim_values(df, dim):
        try:
            vals.append(float(v))
        except (TypeError, ValueError):
            continue
    return vals


def plot_categorical(df, dim, out_dir, top_n=20, dpi=140, as_pie=False):
    counts = top_value_counts(df, dim, top_n)
    if not counts:
        print(f"  [skip] {dim}：无数值可画", file=sys.stderr)
        return None
    if as_pie:
        return _plot_pie(counts, dim, out_dir, dpi)
    fig, ax = plt.subplots(figsize=(max(6, 0.45 * len(counts)), 4.2))
    labels = list(counts.keys())
    vals = list(counts.values())
    ax.bar(range(len(vals)), vals, color="#3b7dd8")
    ax.set_xticks(range(len(vals)))
    ax.set_xticklabels([l[:18] + ("…" if len(l) > 18 else "") for l in labels],
                       rotation=45, ha="right", fontsize=8)
    ax.set_title(f"{dim} distribution (top {len(labels)})")
    for i, v in enumerate(vals):
        ax.text(i, v, f"{v}", ha="center", va="bottom", fontsize=7)
    ax.set_ylabel("samples")
    out_path = os.path.join(out_dir, f"dist_{dim}.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi)
    plt.close(fig)
    return out_path


def _plot_pie(counts: Dict[str, int], dim: str, out_dir: str, dpi: int,
              n_slices: int = 6) -> Optional[str]:
    """占比饼图：top-N 扇区 + 其余合并"others"。

    设计依据：饼图只在类别少时可读（角度感知精度低、扇区>6 标签难摆）；
    长尾类别合并为 others 保证视角"部分占整体"。占比 <2% 的小扇区不标百分比防重叠。
    """
    total_all = sum(counts.values())
    if not total_all:
        return None
    items = list(counts.items())
    top = items[:n_slices]
    rest = items[n_slices:]
    labels = [f"{k} ({v})" for k, v in top]
    vals = [v for _k, v in top]
    if rest:
        rest_sum = sum(v for _k, v in rest)
        labels.append(f"others×{len(rest)} ({rest_sum})")
        vals.append(rest_sum)

    def _autopct(pct: float) -> str:
        return f"{pct:.1f}%" if pct >= 2.0 else ""

    fig, ax = plt.subplots(figsize=(7.5, 5.5))
    wedges, _texts, _autotexts = ax.pie(
        vals, labels=labels, autopct=_autopct, startangle=90,
        colors=plt.cm.tab20.colors[:len(vals)],
        textprops={"fontsize": 8}, pctdistance=0.78,
        wedgeprops={"edgecolor": "white", "linewidth": 1})
    n_total = len(counts)
    ax.set_title(f"{dim} proportion (top {min(n_slices, len(top))} of {n_total}, n={total_all})")
    out_path = os.path.join(out_dir, f"pie_{dim}.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi)
    plt.close(fig)
    return out_path


def plot_numeric(df, dim, out_dir, bins=40, dpi=140):
    vals = hist_values(df, dim)
    if not vals:
        print(f"  [skip] {dim}：无数值可画", file=sys.stderr)
        return None
    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.hist(vals, bins=bins, color="#3b7dd8", edgecolor="white")
    ax.set_title(f"{dim} distribution (n={len(vals)})")
    out_path = os.path.join(out_dir, f"dist_{dim}.png")
    if dim in ("duration", "segments", "frames"):
        ax.set_xlabel(f"{dim} (median={sorted(vals)[len(vals)//2]:.1f})")
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi)
    plt.close(fig)
    return out_path


def plot_cross(df, cross: str, out_dir, dpi=140):
    """两维交叉计数热力图（如 scene × hand）。"""
    a_dim, b_dim = [s.strip() for s in cross.split(",")][:2]
    rows = []
    for dim in (a_dim, b_dim):
        if dim not in COLUMN_OF:
            print(f"  [skip] unknown dim: {dim}", file=sys.stderr)
            return None
    a_counts = top_value_counts(df, a_dim, top_n=15)
    b_counts = top_value_counts(df, b_dim, top_n=8)

    def expand(dim) -> Dict[str, set]:
        mapping: Dict[str, set] = {}
        for sid, v in iter_dim_values(df, dim):
            mapping.setdefault(sid, set()).add(str(v))
        return mapping

    a_map, b_map = expand(a_dim), expand(b_dim)
    mat = [[0] * len(b_counts) for _ in range(len(a_counts))]
    a_keys, b_keys = list(a_counts.keys()), list(b_counts.keys())
    for sid, avals in a_map.items():
        bvals = b_map.get(sid) or set()
        for av in avals:
            if av in a_counts:
                i = a_keys.index(av)
                for bv in bvals:
                    if bv in b_counts:
                        j = b_keys.index(bv)
                        mat[i][j] += 1
    fig, ax = plt.subplots(
        figsize=(max(6, 0.8 * len(b_keys)), max(3.5, 0.42 * len(a_keys))))
    im = ax.imshow(mat, cmap="YlGnBu", aspect="auto")
    ax.set_xticks(range(len(b_keys)))
    ax.set_xticklabels([k[:14] for k in b_keys], rotation=30, ha="right", fontsize=8)
    ax.set_yticks(range(len(a_keys)))
    ax.set_yticklabels([k[:16] for k in a_keys], fontsize=8)
    for i in range(len(a_keys)):
        for j in range(len(b_keys)):
            if mat[i][j]:
                ax.text(j, i, str(mat[i][j]), ha="center", va="center",
                        fontsize=7, color="#333333" if mat[i][j] > 0 else "white")
    ax.set_title(f"{a_dim} × {b_dim} (sample counts)")
    fig.colorbar(im, ax=ax, shrink=0.8)
    out_path = os.path.join(out_dir, f"cross_{a_dim}__{b_dim}.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=dpi)
    plt.close(fig)
    return out_path


# ---------------------------------------------------------------------------
# 样本卡片（下载 overview.png 拼网格）
# ---------------------------------------------------------------------------
def _fetch_overview(client: OpenAoEClient, sid: str, cache_dir: str) -> Optional[str]:
    entry = client.stat_file(remote_path(sid, "overview"))
    dst = os.path.join(cache_dir, f"{sid}_overview.png")
    res = client.download_file(remote_path(sid, "overview"), dst,
                               expected_size=(entry or {}).get("Size"),
                               expected_sha256=(entry or {}).get("Sha256"))
    return dst if res["status"] in ("downloaded", "skipped") else None


def plot_sample_cards(client: OpenAoEClient, df: pd.DataFrame, n: int,
                      out_dir: str, cols: int = 4, dpi=150) -> Optional[str]:
    from PIL import Image, ImageDraw, ImageFont

    rng = random.Random(20260901)
    n = min(n, len(df))
    picks = rng.sample(df.to_dict("records"), n)
    os.makedirs(os.path.join(out_dir, "cards_cache"), exist_ok=True)

    img_paths: List = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futs = {pool.submit(_fetch_overview, client, r["sample_id"],
                            os.path.join(out_dir, "cards_cache")): r for r in picks}
        for fut in as_completed(futs):
            p = fut.result()
            if p:
                img_paths.append((futs[fut], p))
    if not img_paths:
        print("  [skip] 样本卡片：无 overview.png 可下载", file=sys.stderr)
        return None

    card_w, caption_h = 320, 54
    thumb_h = 240
    rows = (len(img_paths) + cols - 1) // cols
    canvas = Image.new("RGB", (cols * card_w, rows * (thumb_h + caption_h)), "white")
    draw = ImageDraw.Draw(canvas)
    try:
        font = ImageFont.load_default()
    except Exception:
        font = None
    for i, (meta, path) in enumerate(img_paths):
        try:
            im = Image.open(path).convert("RGB")
        except Exception:
            continue
        im.thumbnail((card_w, thumb_h))
        x = (i % cols) * card_w
        y = (i // cols) * (thumb_h + caption_h)
        canvas.paste(im, (x + (card_w - im.width) // 2, y))
        sid = str(meta["sample_id"])
        caption = f"{sid[:26]}\n{meta.get('primary_scene') or '?'}  {round(float(meta.get('duration_s') or 0))}s"
        draw.multiline_text((x + 6, y + thumb_h + 4), caption, fill="#222222", font=font)
    out_path = os.path.join(out_dir, "sample_cards.png")
    canvas.save(out_path, quality=95)
    return out_path


# ---------------------------------------------------------------------------
def parse_args(argv=None):
    p = argparse.ArgumentParser(description="OpenAoE 索引可视化（分布/交叉/样本卡片）")
    p.add_argument("--index", default=".cache/openaoe_index.parquet")
    p.add_argument("--dims", default="scene,duration,verb,resolution,hand,confidence",
                   help="逗号分隔维度；单维分布图")
    p.add_argument("--cross", help="如 scene,hand 两维交叉热力图")
    p.add_argument("--sample-cards", type=int, default=0, help="抽样样本卡片数（>0 时在线下载 overview.png）")
    p.add_argument("--top-n", type=int, default=20, help="类别维度 top-N")
    p.add_argument("--pie", action="store_true",
                   help="类别维度额外输出占比饼图（pie_<dim>.png：top-6 扇区 + others 合并；"
                        "适用于'看部分占整体'；数值维度仍为直方图）")
    p.add_argument("--pie-only", action="store_true",
                   help="类别维度只出饼图不出条形图（--pie 的纯饼模式）")
    p.add_argument("--out", default="figures", help="输出目录")
    p.add_argument("--token", help="ModelScope token（默认 .env）")
    return p.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(argv)
    if not os.path.isfile(a.index):
        print(f"错误：索引不存在 {a.index}，请先 build_index.py", file=sys.stderr)
        return 2
    df = pd.read_parquet(a.index)
    os.makedirs(a.out, exist_ok=True)

    gallery: List[Dict[str, str]] = []
    dims = [d.strip() for d in a.dims.split(",") if d.strip()]
    for dim in dims:
        if dim not in COLUMN_OF:
            print(f"  [skip] 未知维度：{dim}", file=sys.stderr)
            continue
        if dim in CATEGORICAL_DIMS:
            print(f"[dim] {dim} …", file=sys.stderr)
            # 条形图（精确比较绝对量；感知精度：长度 > 角度）
            if not a.pie_only:
                out = plot_categorical(df, dim, a.out, a.top_n)
                if out:
                    gallery.append({"title": f"{dim} 分布（条形，对比绝对量）", "path": out})
            # 占比饼图（部分占整体视角；top-6 + others 防长尾挤成一坨）
            if a.pie or a.pie_only:
                out = plot_categorical(df, dim, a.out, a.top_n, as_pie=True)
                if out:
                    gallery.append({"title": f"{dim} 占比（饼图）", "path": out})
        else:
            print(f"[dim] {dim} …", file=sys.stderr)
            out = plot_numeric(df, dim, a.out)
            if out:
                gallery.append({"title": f"{dim} 分布（直方图）", "path": out})

    if a.cross:
        print(f"[cross] {a.cross} …", file=sys.stderr)
        out = plot_cross(df, a.cross, a.out)
        if out:
            gallery.append({"title": f"{a.cross} 交叉", "path": out})

    if a.sample_cards > 0:
        client = OpenAoEClient(token=a.token)
        print(f"[cards] 抽样 {a.sample_cards} 个样本卡片 …", file=sys.stderr)
        out = plot_sample_cards(client, df, a.sample_cards, a.out)
        if out:
            gallery.append({"title": "抽样样本卡片（overview.png）", "path": out})

    md = ["# OpenAoE 索引可视化图集\n",
          f"- 索引：{os.path.abspath(a.index)}（{len(df)} 样本）",
          f"- 生成时间：{time.strftime('%Y-%m-%dT%H:%M:%S%z')}", "",
          "| 图 | 路径 |", "| --- | --- |"]
    for g in gallery:
        rel = os.path.relpath(g["path"], a.out)
        md.append(f"| {g['title']} | ![]({rel}) |")
    with open(os.path.join(a.out, "_gallery.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(md) + "\n")
    print(f"可视化完成：{len(gallery)} 张图 → {a.out}/（见 _gallery.md）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
