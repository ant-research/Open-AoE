#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE ModelScope API 客户端 —— openaoe-data-ops skill 的共享网络层。

职责边界（本模块不含筛选/质检等业务逻辑）：
1. token 加载：显式参数 > 环境变量(OPENAOE_MS_TOKEN / MODELSCOPE_TOKEN) > 项目 .env（从 CWD 向上逐级查找 ``token=...``）
   ⚠ token 可选：公开数据集支持匿名访问（2026-09 实测 meta/tree/文件下载含 LFS 均放行），
   无 token 时自动匿名直连，开箱即用；仅 401/403 时提示配置 token
2. 指数退避重试 + 限流自适应（429/5xx 时降速，成功后缓慢恢复）
3. repo tree 分页：兼容 ModelScope 翻页怪癖（PageNumber=0/1 均返回第一页，翻页实际从 2 开始），
   以"路径指纹判重 + 连续重复页熔断"防止重复与死循环（数据集在上传中，列表会漂移）。
4. 文件下载：302 重定向跟随、流式写入、Range 断点续传、sha256 校验、.part 临时文件。
5. revision 快照（dataset Id / GmtModified / 根目录 TotalCount）用于索引版本水位与下载血缘。

数据集：inclusionAI/OpenAoE-2000h（ModelScope 公开仓库，匿名可访问；token 可选加速/防限流）。

CLI 快速调试用法：
    python3 openaoe_client.py --meta
    python3 openaoe_client.py --ls raw_242946_seg_10
    python3 openaoe_client.py --ls-root --pages 3
    python3 openaoe_client.py --download "raw_242946_seg_10/video_info.json" -o /tmp/vi.json
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
import threading
import time
from typing import Any, Dict, Iterator, List, Optional

import requests

# ---------------------------------------------------------------------------
# 兼容：脚本既可被 import，也可被直接执行；同目录模块互相导入
# ---------------------------------------------------------------------------
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

DEFAULT_BASE_URL = "https://www.modelscope.cn"
DEFAULT_DATASET = "inclusionAI/OpenAoE-2000h"
DEFAULT_REVISION = "master"
USER_AGENT = "openaoe-data-ops/1.0 (+AiWork skill)"

_RETRY_STATUS = {429, 500, 502, 503, 504}
_FATAL_AUTH_STATUS = (401, 403)


class ApiError(RuntimeError):
    """ModelScope API 返回异常（非 200 / 非法响应）。"""


class TokenError(ApiError):
    """token 失效，或匿名访问公开数据集被拒（401/403）。"""


# ---------------------------------------------------------------------------
# token 加载
# ---------------------------------------------------------------------------
def load_token(explicit: Optional[str] = None, max_ancestors: int = 6) -> Optional[str]:
    """token 优先级：显式传参 > 环境变量 > .env 文件（向上查找）。绝不在日志中打印 token 值。"""
    if explicit:
        return explicit.strip()
    for env in ("OPENAOE_MS_TOKEN", "MODELSCOPE_TOKEN"):
        if os.environ.get(env):
            return os.environ[env].strip()
    cur = os.getcwd()
    for _ in range(max_ancestors):
        env_path = os.path.join(cur, ".env")
        if os.path.isfile(env_path):
            try:
                with open(env_path, "r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if line.startswith("#") or "=" not in line:
                            continue
                        key, _, val = line.partition("=")
                        if key.strip() in ("token", "OPENAOE_MS_TOKEN", "MODELSCOPE_TOKEN"):
                            val = val.strip().strip('"').strip("'")
                            if val:
                                import os as _os  # noqa: F401
                                return val
            except OSError:
                pass
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


# ---------------------------------------------------------------------------
# 限流自适应
# ---------------------------------------------------------------------------
class AdaptiveThrottle:
    """线程间共享的自适应节流器：限流信号到来时延迟指数放大，成功请求后缓慢恢复。

    用法：worker 在每次远端请求前后调用 wait() / on_success()；
    client 收到 429 或 5xx 时调用 on_rate_limited()。
    """

    def __init__(self, initial_delay: float = 0.02, max_delay: float = 8.0,
                 grow: float = 1.8, recover: float = 0.97, floor: float = 0.0):
        self._delay = max(floor, initial_delay)
        self._max = max_delay
        self._grow = grow
        self._recover = recover
        self._floor = floor
        self._lock = threading.Lock()
        self._n_rate_limited = 0

    def wait(self) -> None:
        with self._lock:
            d = self._delay
        if d > 0:
            time.sleep(d * (0.5 + random.random()))  # 抖动，避免线程同步蜂拥

    def on_rate_limited(self) -> None:
        with self._lock:
            self._n_rate_limited += 1
            self._delay = min(self._max, max(self._delay, 0.05) * self._grow)

    def on_success(self) -> None:
        with self._lock:
            self._delay = max(self._floor, self._delay * self._recover)

    @property
    def delay(self) -> float:
        with self._lock:
            return self._delay

    @property
    def rate_limited_count(self) -> int:
        with self._lock:
            return self._n_rate_limited


# ---------------------------------------------------------------------------
# 客户端
# ---------------------------------------------------------------------------
class OpenAoEClient:
    """ModelScope 数据集 REST API 封装（tree / 下载 / 元信息），线程安全。"""

    def __init__(self,
                 token: Optional[str] = None,
                 dataset: str = DEFAULT_DATASET,
                 revision: str = DEFAULT_REVISION,
                 base_url: str = DEFAULT_BASE_URL,
                 timeout: float = 60.0,
                 download_timeout: float = 180.0,
                 max_retries: int = 6,
                 backoff_base: float = 0.6,
                 throttle: Optional[AdaptiveThrottle] = None,
                 quiet: bool = False):
        self.dataset = dataset
        self.revision = revision
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.download_timeout = download_timeout
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.throttle = throttle or AdaptiveThrottle()
        self.quiet = quiet
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": "",  # 占位，见下
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
        })
        tok = load_token(token)
        # token 可选（2026-09 实测）：OpenAoE-2000h 为公开仓库，匿名可访问
        # meta / tree / 文件下载（含 LFS Range）；无 token 时降级为匿名直连，开箱即用。
        self.anonymous = not tok
        if tok:
            self._session.headers["Authorization"] = "Bearer " + tok
            # token 绝不写入日志；仅存放前 4 位用于错误提示定位
            self._token_hint = tok[:4] + "***"
        else:
            self._token_hint = "匿名"
            self.log("未找到 ModelScope token：匿名模式访问公开数据集（开箱即用）。"
                     "如遇 401/403 或高频限流，可在执行目录或其上级 .env 写 token=…"
                     "（或设 OPENAOE_MS_TOKEN / MODELSCOPE_TOKEN）后重试。")

    # ------------------------------------------------------------------ util
    def log(self, msg: str) -> None:
        if not self.quiet:
            print(msg, file=sys.stderr)

    @property
    def api_meta_url(self) -> str:
        return f"{self.base_url}/api/v1/datasets/{self.dataset}"

    @property
    def api_repo_url(self) -> str:
        return f"{self.base_url}/api/v1/datasets/{self.dataset}/repo"

    def _api_tree_url(self) -> str:
        return f"{self.api_repo_url}/tree"

    # --------------------------------------------------------------- request
    def _request(self, url: str, params: Optional[Dict[str, Any]] = None,
                 stream: bool = False, timeout: Optional[float] = None) -> requests.Response:
        """GET with 重试/退避/限流自适应。429/5xx 可重试；401/403 直接抛 TokenError。"""
        last_err: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            self.throttle.wait()
            try:
                resp = self._session.get(
                    url, params=params, stream=stream,
                    timeout=timeout or self.timeout, allow_redirects=True)
                if resp.status_code in _RETRY_STATUS:
                    self.throttle.on_rate_limited()
                    retry_after = resp.headers.get("Retry-After")
                    try:
                        ra = float(retry_after) if retry_after else None
                    except ValueError:
                        ra = None
                    if ra is None and resp.status_code == 429:
                        ra = 1.0
                    last_err = ApiError(f"HTTP {resp.status_code} {url}")
                    if attempt < self.max_retries:
                        self._backoff_sleep(attempt, extra=ra)
                        continue
                    raise ApiError(f"重试 {self.max_retries} 次后仍失败：HTTP {resp.status_code} ({url})")
                if resp.status_code in _FATAL_AUTH_STATUS:
                    if getattr(self, "anonymous", False):
                        raise TokenError(
                            f"匿名访问被拒（HTTP {resp.status_code}）：公开数据集策略可能已变更，"
                            "请在执行目录或其上级 .env 写 token=…（或环境变量 "
                            "OPENAOE_MS_TOKEN / MODELSCOPE_TOKEN，或 --token 传入）后重试。")
                    raise TokenError(
                        f"token 鉴权失败（HTTP {resp.status_code}，token {self._token_hint}）。"
                        "请检查 .env / OPENAOE_MS_TOKEN 中的 token 是否有效。")
                self.throttle.on_success()
                return resp
            except (requests.ConnectionError, requests.Timeout) as e:
                self.throttle.on_rate_limited()
                last_err = e
                if attempt < self.max_retries:
                    self._backoff_sleep(attempt)
                    continue
                raise ApiError(f"网络错误（重试 {self.max_retries} 次后仍失败）：{e}")
        raise ApiError(f"请求失败：{last_err}")

    def _backoff_sleep(self, attempt: int, extra: Optional[float] = None) -> float:
        delay = min(60.0, self.backoff_base * (2 ** attempt)) * (0.5 + random.random())
        if extra:
            delay += extra
        self.log(f"  [retry] 第 {attempt + 1} 次退避 {delay:.1f}s（throttle={self.throttle.delay:.2f}s）")
        time.sleep(delay)
        return delay

    def get_json(self, path: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = self.base_url.rstrip("/") + path
        resp = self._request(url, params=params)
        try:
            payload = resp.json()
        except ValueError:
            raise ApiError(f"非 JSON 响应（HTTP {resp.status_code}）：{path}")
        code = payload.get("Code")
        if code not in (200, "200", None):
            msg = payload.get("Message") or ""
            raise ApiError(f"API 错误 code={code} msg={msg} path={path}")
        return payload

    # ------------------------------------------------------------------ meta
    def get_dataset_meta(self) -> Dict[str, Any]:
        payload = self.get_json(f"/api/v1/datasets/{self.dataset}")
        return payload.get("Data") or {}

    def revision_snapshot(self, root_total: Optional[int] = None) -> Dict[str, Any]:
        """版本水位快照：数据集持续上传（README 称 2000h 目标），索引/manifest 必须留血缘。"""
        meta = self.get_dataset_meta()
        if root_total is None:
            data = self._get_tree_page("", page_number=1, page_size=1)
            root_total = data.get("TotalCount")
        return {
            "dataset": self.dataset,
            "platform": "modelscope",
            "revision": self.revision,
            "dataset_id": meta.get("Id"),
            "dataset_gmt_modified": meta.get("GmtModified"),
            "dataset_last_updated": meta.get("LastUpdatedTime"),
            "root_total": root_total,
            "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }

    # ------------------------------------------------------------------ tree
    def _get_tree_page(self, root: str, page_number: int, page_size: int) -> Dict[str, Any]:
        params = {"Revision": self.revision, "Root": root,
                  "PageSize": page_size, "PageNumber": page_number}
        payload = self.get_json(f"/api/v1/datasets/{self.dataset}/repo/tree", params)
        data = payload.get("Data") or {}
        if not isinstance(data.get("Files"), list):
            data["Files"] = []
        return data

    def iter_tree(self, root: str = "", page_size: int = 200,
                  max_pages: Optional[int] = None) -> Iterator[Dict[str, Any]]:
        """遍历某目录下全部条目（tree + blob）。

        ModelScope 分页怪癖兼容：
        - PageNumber=0 与 1 均返回第一页 → 统一从 1 开始请求；
        - 服务器可能忽略 PageNumber（历史行为）→ 以"该页全部 Path 均已见过"作指纹判重，
          连续 ``_duplicate_page_budget`` 个全重复页即认为翻页失效，主动熔断；
        - 数据集在上传中造成列表漂移 → 按 Path 去重，同时以 TotalCount 作为弱终止条件。
        """
        seen: set = set()
        first_page_fingerprint: Optional[tuple] = None
        consecutive_dup_pages = 0
        page = 1
        _DUPLICATE_PAGE_BUDGET = 3
        while True:
            if max_pages is not None and page > max_pages:
                self.log(f"  [tree] 达到 max_pages={max_pages} 提前停止")
                break
            data = self._get_tree_page(root, page, page_size)
            files: List[Dict[str, Any]] = data["Files"]
            total = data.get("TotalCount")
            if page == 1:
                first_page_fingerprint = tuple(f.get("Path") for f in files)
            if not files:
                break
            fresh = [f for f in files if f.get("Path") not in seen]
            if files and not fresh:
                # 该页全部条目都出现过：要么翻页失效（指纹判重），要么分页回绕
                is_page1_alike = tuple(f.get("Path") for f in files) == first_page_fingerprint
                consecutive_dup_pages += 1
                if is_page1_alike or consecutive_dup_pages >= _DUPLICATE_PAGE_BUDGET:
                    self.log(f"  [tree] 检测到重复页（page={page}），判定翻页边界，停止。")
                    break
                seen.update(f.get("Path") for f in files)
                page += 1
                continue
            consecutive_dup_pages = 0
            seen.update(f.get("Path") for f in files)
            for f in fresh:
                yield f
            if total is not None and len(seen) >= int(total):
                break
            page += 1
        return  # noqa: B012 显式结束生成器

    def list_dir(self, root: str = "", page_size: int = 200) -> List[Dict[str, Any]]:
        return list(self.iter_tree(root, page_size=page_size))

    def stat_file(self, remote_path: str) -> Optional[Dict[str, Any]]:
        """查询单文件的 Size/Sha256/IsLFS（通过父目录一次 tree 请求）。找不到返回 None。"""
        parent = os.path.dirname(remote_path) if "/" in remote_path else ""
        name = os.path.basename(remote_path)
        for entry in self.iter_tree(parent, page_size=500):
            if entry.get("Type") == "blob" and os.path.basename(entry.get("Path", "")) == name:
                return entry
        return None

    # -------------------------------------------------------------- download
    def download_bytes(self, remote_path: str, max_bytes: int = 64 * 1024 * 1024) -> bytes:
        """小文件（元数据 JSON）整块下载。"""
        params = {"Revision": self.revision, "FilePath": remote_path}
        resp = self._request(self.api_repo_url, params=params, stream=True)
        buf = bytearray()
        for chunk in resp.iter_content(chunk_size=256 * 1024):
            if chunk:
                buf.extend(chunk)
                if len(buf) > max_bytes:
                    raise ApiError(f"文件超过 max_bytes={max_bytes}: {remote_path}")
        return bytes(buf)

    def download_file(self,
                      remote_path: str,
                      local_path: str,
                      expected_size: Optional[int] = None,
                      expected_sha256: Optional[str] = None,
                      resume: bool = True,
                      verify_sha: bool = True) -> Dict[str, Any]:
        """下载一个文件到 local_path（.part 临时 + 原子 rename + Range 断点续传 + sha256 校验）。

        返回 {"status": "downloaded|skipped|failed", "path", "bytes", "sha256", "seconds", "error"}
        """
        os.makedirs(os.path.dirname(os.path.abspath(local_path)), exist_ok=True)
        t0 = time.time()

        # 已完整存在的文件 → 校验后跳过
        if os.path.isfile(local_path):
            ok, sha = self._verify_local(local_path, expected_size, expected_sha256, verify_sha)
            if ok:
                return {"status": "skipped", "path": local_path,
                        "bytes": os.path.getsize(local_path), "sha256": sha,
                        "seconds": 0.0, "error": None}
            if not resume:
                os.remove(local_path)

        part_path = local_path + ".part"
        existing = 0
        if resume and os.path.isfile(part_path):
            existing = os.path.getsize(part_path)
            if expected_size and existing > expected_size:
                os.remove(part_path)  # 损坏的部分文件
                existing = 0
        if existing and expected_size and existing == expected_size:
            # .part 已下满：补校验后直接转正
            ok, sha = self._verify_local(part_path, expected_size, expected_sha256, verify_sha)
            if ok:
                os.replace(part_path, local_path)
                return {"status": "downloaded", "path": local_path, "bytes": expected_size,
                        "sha256": sha, "seconds": time.time() - t0, "error": None}
            os.remove(part_path)
            existing = 0

        params = {"Revision": self.revision, "FilePath": remote_path}
        headers: Dict[str, str] = {}
        if existing > 0:
            headers["Range"] = f"bytes={existing}-"
        try:
            resp = self._request(self.api_repo_url, params=params, stream=True,
                                 timeout=self.download_timeout)
        except ApiError as e:
            return {"status": "failed", "path": local_path, "bytes": 0, "sha256": None,
                    "seconds": time.time() - t0, "error": str(e)}

        append = (existing > 0 and resp.status_code == 206)
        if existing and not append:
            # 服务器不支持 Range 或返回全量：丢弃本地部分重新写
            existing = 0

        hasher = hashlib.sha256()
        mode = "ab" if append else "wb"
        if append:
            with open(part_path, "rb") as fh:  # 先喂已存在部分
                while True:
                    tail = fh.read(4 * 1024 * 1024)
                    if not tail:
                        break
                    hasher.update(tail)
        written = 0
        try:
            with open(part_path, mode) as fh:
                it = resp.iter_content(chunk_size=1024 * 1024)
                for chunk in it:
                    if not chunk:
                        continue
                    fh.write(chunk)
                    hasher.update(chunk)
                    written += len(chunk)
        except (requests.ConnectionError, requests.Timeout, OSError) as e:
            return {"status": "failed", "path": local_path, "bytes": existing + written,
                    "sha256": None, "seconds": time.time() - t0, "error": f"传输中断：{e}"}

        total_size = existing + written
        if expected_size is not None and total_size != expected_size:
            return {"status": "failed", "path": local_path, "bytes": total_size,
                    "sha256": None, "seconds": time.time() - t0,
                    "error": f"大小不匹配：期望 {expected_size}，实际 {total_size}"}
        sha = hasher.hexdigest()
        if verify_sha and expected_sha256 and sha != expected_sha256.lower():
            os.remove(part_path)
            return {"status": "failed", "path": local_path, "bytes": total_size,
                    "sha256": sha, "seconds": time.time() - t0,
                    "error": f"sha256 不匹配：期望 {expected_sha256[:16]}…，实际 {sha[:16]}…"}
        os.replace(part_path, local_path)
        return {"status": "downloaded", "path": local_path, "bytes": total_size,
                "sha256": sha, "seconds": time.time() - t0, "error": None}

    @staticmethod
    def _verify_local(path: str, expected_size: Optional[int],
                      expected_sha256: Optional[str], verify_sha: bool) -> (bool, Optional[str]):
        if expected_size is not None and os.path.getsize(path) != expected_size:
            return False, None
        if not verify_sha or not expected_sha256:
            return True, None
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            while True:
                b = fh.read(4 * 1024 * 1024)
                if not b:
                    break
                h.update(b)
        digest = h.hexdigest()
        return digest == expected_sha256.lower(), digest


# ---------------------------------------------------------------------------
# CLI：调试入口
# ---------------------------------------------------------------------------
def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="OpenAoE ModelScope API 调试 CLI")
    parser.add_argument("--token", help="ModelScope token（默认从 .env/环境变量读取）")
    parser.add_argument("--dataset", default=DEFAULT_DATASET)
    parser.add_argument("--quiet", action="store_true")
    g = parser.add_mutually_exclusive_group(required=True)
    g.add_argument("--meta", action="store_true", help="数据集元信息 + revision 快照")
    g.add_argument("--ls", metavar="ROOT", help="列出某目录（含分页），打印条目")
    g.add_argument("--ls-root", action="store_true", help="列出根目录前若干条目（验证翻页）")
    g.add_argument("--download", metavar="REMOTE_PATH", help="下载单个文件")
    parser.add_argument("--pages", type=int, default=3, help="--ls-root 时的页数")
    parser.add_argument("--page-size", type=int, default=50)
    parser.add_argument("-o", "--out", help="--download 输出路径")
    args = parser.parse_args(argv)

    client = OpenAoEClient(token=args.token, dataset=args.dataset, quiet=args.quiet)

    if args.meta:
        meta = client.get_dataset_meta()
        snap = client.revision_snapshot()
        print(json.dumps({
            "id": meta.get("Id"),
            "name": f"{meta.get('Namespace')}/{meta.get('Name')}",
            "chinese_name": meta.get("ChineseName"),
            "license": meta.get("License"),
            "downloads": meta.get("Downloads"),
            "storage_size": meta.get("StorageSize"),
            "revision_snapshot": snap,
        }, ensure_ascii=False, indent=2))
        return 0

    if args.ls_root:
        entries = list(client.iter_tree("", page_size=args.page_size, max_pages=args.pages))
        print(f"收集 {len(entries)} 条（PageNumber 从 1 开始、PageNumber=2 起翻第二页）")
        for e in entries[:40]:
            print(f"  {e.get('Type')}\t{e.get('Path')}\tSize={e.get('Size')}\tLFS={e.get('IsLFS')}")
        return 0

    if args.ls:
        for e in client.iter_tree(args.ls, page_size=args.page_size):
            print(f"  {e.get('Type')}\t{e.get('Path')}\tSize={e.get('Size')}\t"
                  f"Sha={str(e.get('Sha256') or '')[:12]}\tLFS={e.get('IsLFS')}")
        return 0

    if args.download:
        out = args.out or os.path.basename(args.download)
        entry = client.stat_file(args.download)
        result = client.download_file(
            args.download, out,
            expected_size=(entry or {}).get("Size"),
            expected_sha256=(entry or {}).get("Sha256"))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] in ("downloaded", "skipped") else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
