#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 子集按类别下载 + 血缘 manifest（工作流 Phase 5）。

- 按类别选择性下载（视频类为 LFS 大文件，按需勾选）：
    annotation | video_info | undistorted_info | undistorted_video | hands | camera_traj |
    overview | hands_video | raw_video
  另有聚合别名：all（全部）、meta（3 个 JSON）、recon（hands+camera_traj+overview）、minimal（annotation+video_info）
- 每文件：tree 查 Size/Sha256 → 下载（Range 断点续传 + .part 临时）→ sha256 校验 → 大小校验。
- 血缘 manifest：_openaoe_manifest.json（对齐 templates/subset-manifest.json），
  记录 revision 快照（dataset_id/gmt_modified/root_total）、subset 来源、每文件
  category/remote_path/size/sha256/local_path/状态，保证下游可复现。
- 附带生成 ATTRIBUTION.md（Open-AoE 署名 + MANO 衍生文件许可隔离声明，见 references/license-notes.md）。

用法示例：
    python3 download_subset.py --subset subset.json --categories annotation,hands --out data/
    python3 download_subset.py --subset subset.json --categories minimal --out data/ --workers 4
    # 断点续传：直接重跑同一命令（已完成文件经 sha256 校验跳过）
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from aoe_parsing import CATEGORY_LABELS, remote_path  # noqa: E402
from openaoe_client import OpenAoEClient  # noqa: E402

ALIASES = {
    "minimal": ["annotation", "video_info", "undistorted_info"],
    "meta": ["annotation", "video_info", "undistorted_info"],
    "recon": ["hands", "camera_traj", "overview"],
    "all": list(CATEGORY_LABELS.keys()),
}
MANIFEST_NAME = "_openaoe_manifest.json"
ATTRIBUTION_MD = """# 数据来源与署名（Usage Attribution）

## 数据来源
- 数据集：Open-AoE Egocentric Hand Manipulation Dataset
- ModelScope 仓库：`inclusionAI/OpenAoE-2000h`
- 论文：arXiv:2607.14183
- 下载时间与 revision 快照：见 `_openaoe_manifest.json`（血缘）

## 使用条款摘要（完整声明见官方 LICENSE）
1. 数据本体（`raw_video.mp4`、`video_info.json`、`ego_annotation/`）可用于**研究与商用**，
   前提是**署名 Open-AoE**（引用数据集与论文如上）。
2. **MANO 衍生文件**（`hands.npz`、`camera_traj.npz`、`hands_combined.mp4`、`overview.png`；本目录中
   category ∈ {hands, camera_traj, overview, hands_video}）额外受
   [MANO License](https://mano.is.tue.mpg.de/license.html) 约束 —— 商用需单独取得 MANO 授权。
   可只用视频与动作标注、不加载 MANO 衍生文件。
3. 上游代码（ant-research/Open-AoE）为 Apache 2.0（代码本身，不含本数据）。

> 本声明由 openaoe-data-ops skill 生成，分发该子集时请随附本文件与 manifest。
"""


def expand_categories(specs: List[str]) -> List[str]:
    cats: List[str] = []
    for spec in specs:
        for s in spec.split(","):
            s = s.strip().lower()
            if not s:
                continue
            if s in ALIASES:
                for c in ALIASES[s]:
                    if c not in cats:
                        cats.append(c)
            elif s in CATEGORY_LABELS:
                if s not in cats:
                    cats.append(s)
            else:
                raise SystemExit(f"未知类别：{s}（可选：{', '.join(CATEGORY_LABELS)}；"
                                 f"别名：{', '.join(ALIASES)}）")
    return cats


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="OpenAoE 子集按类别下载（sha256 校验+断点续传+manifest）")
    p.add_argument("--subset", default="subset.json", help="subset.json 路径")
    p.add_argument("--categories", default="minimal",
                   help="逗号分隔类别或别名 minimal/recon/all；例如 annotation,hands,raw_video")
    p.add_argument("--out", default="data/openaoe_subset", help="本地输出根目录")
    p.add_argument("--workers", type=int, default=4, help="并发下载数（LFS 大文件建议 ≤8）")
    p.add_argument("--no-verify", action="store_true", help="跳过 sha256 校验（体积校验保留）")
    p.add_argument("--subset-limit", type=int, help="只下载 subset 前 N 个样本（调试）")
    p.add_argument("--token", help="ModelScope token（默认 .env）")
    return p.parse_args(argv)


def read_subset(path: str) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as fh:
        subset = json.load(fh)
    samples = subset.get("samples") or []
    if not samples:
        raise SystemExit(f"subset 为空：{path}（先运行 filter.py）")
    # 继承血缘字段
    for s in samples:
        s["_filters"] = subset.get("filters")
    return samples


def build_tasks(samples: List[Dict[str, Any]], categories: List[str], out_root: str):
    """(sample_id, remote_path, local_path, category) 列表，本地保留样本目录结构。"""
    tasks = []
    for s in samples:
        sid = s["sample_id"]
        for c in categories:
            tasks.append({
                "sample_id": sid,
                "category": c,
                "remote_path": remote_path(sid, c),
                "local_path": os.path.join(out_root, sid, os.path.basename(remote_path(sid, c))),
            })
    return tasks


def download_task(client: OpenAoEClient, task: Dict[str, str],
                  verify: bool) -> Dict[str, Any]:
    stat = client.stat_file(task["remote_path"])
    result = client.download_file(
        task["remote_path"], task["local_path"],
        expected_size=(stat or {}).get("Size"),
        expected_sha256=(stat or {}).get("Sha256"),
        resume=True, verify_sha=verify)
    result.update(category=task["category"], sample_id=task["sample_id"],
                  remote_path=task["remote_path"])
    if result["sha256"] is None and stat:
        result["remote_sha256"] = stat.get("Sha256")
    return result


def fmt_size(n: Optional[int]) -> str:
    if not n:
        return "—"
    step = 1000.0
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < step:
            return f"{n:.0f}{unit}" if unit == "B" else f"{n:.1f}{unit}"
        n /= step
    return f"{n:.1f}PB"


def main(argv=None) -> int:
    a = parse_args(argv)
    categories = expand_categories(a.categories.split(",") if "," in a.categories else [a.categories])
    samples = read_subset(a.subset)
    if a.subset_limit:
        samples = samples[: a.subset_limit]
    out_root = os.path.abspath(a.out)
    client = OpenAoEClient(token=a.token)

    print(f"[1/3] revision 快照 + 任务编排：{len(samples)} 样本 × {len(categories)} 类别", file=sys.stderr)
    revision = client.revision_snapshot()
    tasks = build_tasks(samples, categories, out_root)
    print(f"      共 {len(tasks)} 个文件待下载（断点续传已开启，重跑同一命令即可续传）", file=sys.stderr)

    manifest_path = os.path.join(out_root, MANIFEST_NAME)
    results: List[Dict[str, Any]] = []
    t0 = time.time()

    def _stat_then_download(task: Dict[str, str]) -> Dict[str, Any]:
        return download_task(client, task, verify=not a.no_verify)

    print(f"[2/3] 并发下载（workers={a.workers}）…", file=sys.stderr)
    done = 0
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futs = {pool.submit(_stat_then_download, t): t for t in tasks}
        for fut in as_completed(futs):
            try:
                res = fut.result()
            except Exception as e:
                t = futs[fut]
                res = {"status": "failed", "error": f"{type(e).__name__}: {e}",
                       "path": t["local_path"], "bytes": 0, "sha256": None,
                       "seconds": 0.0, "category": t["category"],
                       "sample_id": t["sample_id"], "remote_path": t["remote_path"]}
            results.append(res)
            done += 1
            if done % 20 == 0 or done == len(tasks):
                rate = sum(r["bytes"] for r in results if r["status"] == "downloaded") \
                    / max(0.001, time.time() - t0)
                print(f"      进度 {done}/{len(tasks)}  "                       
                      f"({rate/1e6:.1f} MB/s, throttle={client.throttle.delay:.2f}s)",
                      file=sys.stderr)

    # ---- manifest（对齐 templates/subset-manifest.json） ----
    def cat_stat(cat):
        sub = [r for r in results if r["category"] == cat]
        ok = [r for r in sub if r["status"] in ("downloaded", "skipped")]
        size = sum(r["bytes"] or 0 for r in ok)
        return {"n_files": len(sub), "n_ok": len(ok), "n_failed": len(sub) - len(ok),
                "bytes": size, "label": CATEGORY_LABELS[cat]}

    n_ok = sum(1 for r in results if r["status"] in ("downloaded", "skipped"))
    n_failed = len(results) - n_ok
    total_bytes = sum(r["bytes"] or 0 for r in results if r["status"] in ("downloaded", "skipped"))

    subset_payload: Dict[str, Any] = {}
    try:
        with open(a.subset, "r", encoding="utf-8") as fh:
            subset_payload = json.load(fh)
    except OSError:
        pass

    manifest = {
        "schema": "openaoe-subset-manifest/1.0",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "origin": {
            "dataset": "inclusionAI/OpenAoE-2000h",
            "platform": "modelscope",
            "revision_snapshot": revision,
            "subset_path": os.path.abspath(a.subset),
            "filters": subset_payload.get("filters"),
            "subset_stats": subset_payload.get("stats"),
        },
        "download": {
            "categories": categories,
            "verify_sha256": not a.no_verify,
            "resume": True,
            "n_files": len(results),
            "n_ok": n_ok,
            "n_failed": n_failed,
            "total_bytes": total_bytes,
            "duration_s": round(time.time() - t0, 1),
            "per_category": {c: cat_stat(c) for c in categories},
        },
        "samples": [
            {
                "sample_id": s["sample_id"],
                "categories": categories,
                "files": [
                    {
                        "category": r["category"],
                        "remote_path": r["remote_path"],
                        "local_path": os.path.relpath(r["path"], out_root),
                        "bytes": r["bytes"],
                        "sha256": r["sha256"] or r.get("remote_sha256"),
                        "status": r["status"],
                        "error": r.get("error"),
                    }
                    for r in results if r["sample_id"] == s["sample_id"]
                ],
            }
            for s in samples
        ],
    }
    os.makedirs(out_root, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
    with open(os.path.join(out_root, "ATTRIBUTION.md"), "w", encoding="utf-8") as fh:
        fh.write(ATTRIBUTION_MD)

    print(f"[3/3] 完成：{n_ok}/{len(results)} 文件成功，共 {fmt_size(total_bytes)}"
          f"（失败 {n_failed}，重跑同一命令可续传）")
    print(f"      manifest：{manifest_path}")
    if n_failed:
        fails = [r for r in results if r["status"] == "failed"][:5]
        for r in fails:
            print(f"      - {r['remote_path']}: {r.get('error')}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
