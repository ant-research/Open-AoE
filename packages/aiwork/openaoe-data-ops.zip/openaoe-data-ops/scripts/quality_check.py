#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenAoE 分层质检 → qc_report.md + qc.parquet（工作流 Phase 3）。

分层设计（关键架构决策）：
- L1（全量、纯元数据）：标注时间/帧连续性、首段从 0 起、bbox 合法性与出画幅、
  hand 枚举合法、置信度分布、内参-分辨率一致性（即上游 PR #1 移除样本的问题类型）、
  畸变系数合法性、字段完整性。仅需 3 个小 JSON，全量可行。
- L2（抽样、重数据）：下载 hands.npz / camera_traj.npz（全量 ≈70GB+，不可行），
  按比例抽样深检：npz 可载入、pred_valid 有效帧比例（(2,T)，[0]=左/[1]=右）、
  帧数对齐（T vs 末段 end_frame±2）、focal 与去畸变内参自洽、轨迹矩阵形状。

输入选择（三选一）：--subset subset.json | --samples ID,ID | 默认 --index 全量_oqc模式
报告：人类可读 md（对齐 templates/qc-report.md），机器可读 parquet（一行 = 一样本 × 一规则）。

用法示例：
    python3 quality_check.py --subset subset.json --level l1
    python3 quality_check.py --subset subset.json --level l2 --sample-ratio 0.05
    python3 quality_check.py --samples raw_242946_seg_10,aoe_20260131_193028_p000 --level l2
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

from aoe_parsing import (  # noqa: E402
    INDEX_COLUMNS, parse_json_bytes, remote_path, resolve_intrinsics_ok,
    summarize_annotation, summarize_undistorted, summarize_video_info,
    to_float, to_int, bbox_out_of_frame)
from openaoe_client import ApiError, OpenAoEClient  # noqa: E402

# ---------------------------------------------------------------------------
# 规则登记表（声明式；报告与 parquet 按此渲染）
# RULE: {id, level, severity, title, check 说明}
# ---------------------------------------------------------------------------
L1_RULES = [
    ("ann01", "error", "标注时间连续性", "首段 start_ts=0 且 segments[i].end_ts==segments[i+1].start_ts"),
    ("ann02", "error", "帧序连续性", "首段 start_frame=0 且 end_frame 逐段相接"),
    ("ann03", "warn",  "时长-帧数自洽", "|duration_s - frames/fps| ≤ 2%（fps=30）"),
    ("ann04", "error", "bbox 合法性", "x2>x1、y2>y1、无负值"),
    ("ann05", "warn",  "bbox 画幅越界", "所有 bbox 位于 resolution 画幅内"),
    ("ann06", "warn",  "置信度下限",   "全部原子动作 confidence ≥ 阈值(默认 0.3)"),
    ("ann07", "error", "hand 枚举合法", "hand ∈ {left,right,both,none}"),
    ("vi01",  "error", "内参-分辨率一致", "fx↔去畸变fov_x 自洽+主点居中+分辨率合法（PR #1 问题类型；zoom-wide 跳过原始fovH）"),
    ("vi02",  "warn",  "畸变系数合法",   "lensDistortion 5 数值且顺序 k1,k2,k3,p1,p2"),
    ("vi03",  "warn",  "去畸变对齐",     "undistorted.resolution==video_info.resolution，fov 偏差<10%"),
    ("fld01", "error", "元数据完整性",   "3 个元数据 JSON 存在且可解析"),
]
L2_RULES = [
    ("hnd01", "error", "hands.npz 可载入", "npz 文件可 numpy.load"),
    ("hnd02", "warn",  "手部有效帧比例",   "pred_valid(2,T) 每只手 ≥ 阈值(默认 0.5)"),
    ("hnd03", "warn",  "帧数对齐",         "|T - 末段 end_frame| ≤ 2"),
    ("hnd04", "warn",  "focal 自洽",       "hands.npz.focal ≈ 去畸变 fx ±10%"),
    ("traj01", "error", "camera_traj.npz 可载入", "cam_c2w (T,4,4)、intrinsic (3,3) 形状正确"),
    ("traj02", "warn",  "轨迹与手帧一致",  "camera_traj.T == hands.T"),
]


# ---------------------------------------------------------------------------
# L1：单样本检查（拉取 3 个 JSON，产出逐规则结果行）
# ---------------------------------------------------------------------------
def check_sample_l1(client: Optional[OpenAoEClient], sample_id: str,
                    index_row: Optional[Dict[str, Any]] = None,
                    min_conf: float = 0.3) -> List[Dict[str, Any]]:
    """跑一个样本的 L1 规则。client=None 且 index_row 提供时走缓存路径（--use-index）。"""
    results: List[Dict[str, Any]] = []

    def add(rule_id, severity, title, passed, detail=""):
        results.append({"sample_id": sample_id, "rule_id": rule_id, "level": "l1",
                        "severity": severity, "title": title,
                        "passed": bool(passed), "detail": str(detail)[:300]})

    anno = vi = uv = None
    segments: Optional[List[Any]] = None
    if client is not None:  # 在线模式：拉原始三件套（比索引聚合更可信）
        try:
            segments = parse_json_bytes(client.download_bytes(remote_path(sample_id, "annotation")))
            anno = summarize_annotation(segments)
        except (ApiError, ValueError) as e:
            pass  # fld01 记录失败
        try:
            vi = summarize_video_info(parse_json_bytes(
                client.download_bytes(remote_path(sample_id, "video_info"))))
        except (ApiError, ValueError):
            pass
        try:
            uv = summarize_undistorted(parse_json_bytes(
                client.download_bytes(remote_path(sample_id, "undistorted_info"))))
        except (ApiError, ValueError):
            pass
    elif index_row is not None:  # 离线索引模式（快、但规则粒度受限）
        anno = {"ts_continuous": index_row.get("ts_continuous"),
                "frame_continuous": index_row.get("frame_continuous"),
                "confidence_min": index_row.get("confidence_min"),
                "bbox_bad_count": index_row.get("bbox_bad_count"),
                "hand_bad_count": index_row.get("hand_bad_count"),
                "n_segments": index_row.get("n_segments"),
                "duration_s": index_row.get("duration_s"),
                "frames": index_row.get("frames"),
                "bbox_oof_count": index_row.get("bbox_oof_count")}
        vi = {"intrinsics_ok": index_row.get("intrinsics_ok"),
              "distortion_ok": index_row.get("distortion_ok"),
              "resolution": index_row.get("resolution"),
              "res_w": index_row.get("res_w"), "res_h": index_row.get("res_h"),
              "fps": index_row.get("fps")}
        uv = {"resolution": index_row.get("resolution")}

    # fld01 元数据完整性
    present = [x is not None for x in (anno, vi, uv)]
    add("fld01", "error", "元数据完整性", all(present),
        f"annotation={present[0]},video_info={present[1]},undistorted={present[2]}" + (
            "" if all(present) else f"（缺失项见下载阶段；index 状态: "
            f"{index_row.get('status') if index_row else 'online'}）"))

    if anno:
        add("ann01", "error", "标注时间连续性", anno.get("ts_continuous"),
            f"n_segments={anno.get('n_segments')}")
        add("ann02", "error", "帧序连续性", anno.get("frame_continuous"),
            f"frames={anno.get('frames')}")
        dur, frames, fps = anno.get("duration_s"), anno.get("frames"), (vi or {}).get("fps") or 30.0
        ok = None
        note = ""
        if dur is not None and frames is not None:
            tol = max(0.02 * dur, 0.5)
            err_declared = abs(dur - to_float(frames) / to_float(fps or 30.0))
            if err_declared <= tol:
                ok = True
            else:
                # 双口径兜底（2026-09-02 全库实测裁定）：fps=60 的 3723 个样本
                # eff_fps = frames/duration 中位数恰为 30.0（5%–95% ∈ [29.99, 30.07]），
                # 即帧号实际按 30FPS 口径递增，声报 fps=60 仅为设备录制参数。
                # 其余 fps（25/27/28/29/30…）按声报口径全通过，无需兜底。
                ok = abs(dur - to_float(frames) / to_float(30.0)) <= tol
                if ok:
                    note = f"；帧号按 30FPS 口径自洽（声报 fps={fps} 为设备录制参数）"
        add("ann03", "warn", "时长-帧数自洽", ok is not False and ok is not None,
            f"duration_s={dur},frames={frames},fps={fps}{note}" if ok is not None else "字段缺失")
        bad = to_int(anno.get("bbox_bad_count")) or 0
        add("ann04", "error", "bbox 合法性", bad == 0, f"bad={bad}")
        oof = to_int(anno.get("bbox_oof_count"))
        if oof is None and segments is not None and vi and vi.get("res_w") and vi.get("res_h"):
            oof = bbox_out_of_frame(segments, vi["res_w"], vi["res_h"])
        add("ann05", "warn", "bbox 画幅越界", (oof or 0) == 0, f"out_of_frame={oof}")
        cmin = to_float(anno.get("confidence_min"))
        add("ann06", "warn", "置信度下限", (cmin is not None and cmin >= min_conf),
            f"min={cmin}（阈值 {min_conf}）" if cmin is not None else "无置信度字段")
        badhand = to_int(anno.get("hand_bad_count")) or 0
        add("ann07", "error", "hand 枚举合法", badhand == 0, f"bad={badhand}")
    else:
        for rid, sev, title, _ in L1_RULES:
            if rid.startswith("ann"):
                add(rid, sev, title, None, "annotation 缺失，无法检查")

    if vi:
        # vi01 裁决分两条路径：
        # - 在线模式（client 提供）：vi 含 fx/base_ok/zoom_wide、uv 含 fov_x_deg，
        #   用 vi.fx↔uv.fov_x 真对齐对现算（与 build_index_row 同源；广角/变焦样本的原始
        #   fovH 指镜头物理视场，与变焦后 fx 必然不自洽，不作为矛盾证据）。
        # - 离线 --use-index 模式（client=None）：vi 只是从索引拼的伪字典，无 fx/fov_x
        #   现算所需字段，intrinsics_ok 已是建索引/--refresh-intrinsics 时算好的最终结论 →
        #   直接采信，不再走 resolve_intrinsics_ok（否则拿不到 fx/fov_x 会误判）。
        if client is None:
            vi01_result = vi.get("intrinsics_ok")
        else:
            vi01_result = resolve_intrinsics_ok(vi, uv if isinstance(uv, dict) else None)
            if vi01_result is None:
                vi01_result = vi.get("intrinsics_ok")
        zoom_note = "" if not vi.get("zoom_wide") else "（zoom-wide：原始fovH检查已跳过）"
        src_note = "（索引预计算 intrinsics_ok）" if client is None else "（fx↔去畸变fov_x 交叉校验）"
        add("vi01", "error", "内参-分辨率一致", vi01_result,
            f"res={vi.get('resolution')}{zoom_note}（PR #1 问题类型；{src_note}")
        add("vi02", "warn", "畸变系数合法", vi.get("distortion_ok"),
            f"order=k1,k2,k3,p1,p2")
    else:
        for rid, sev, title, _ in L1_RULES:
            if rid.startswith("vi"):
                add(rid, sev, title, None, "video_info 缺失，无法检查")
    if uv and vi:
        res_match = str(uv.get("resolution") or "") == str(vi.get("resolution") or "")
        add("vi03", "warn", "去畸变对齐", res_match,
            f"raw={vi.get('resolution')} vs undist={uv.get('resolution')}")
    return results


# ---------------------------------------------------------------------------
# L2：npz 深检
# ---------------------------------------------------------------------------
def check_sample_l2(client: OpenAoEClient, sample_id: str,
                    cache_dir: str, frames: Optional[int],
                    uv_fx: Optional[float]) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []

    def add(rule_id, severity, title, passed, detail=""):
        results.append({"sample_id": sample_id, "rule_id": rule_id, "level": "l2",
                        "severity": severity, "title": title,
                        "passed": bool(passed) if passed is not None else None,
                        "detail": str(detail)[:300]})

    os.makedirs(cache_dir, exist_ok=True)
    hands_path = os.path.join(cache_dir, "hands.npz")
    traj_path = os.path.join(cache_dir, "camera_traj.npz")
    entry = client.stat_file(remote_path(sample_id, "hands"))
    hands_res = client.download_file(remote_path(sample_id, "hands"), hands_path,
                                     expected_size=(entry or {}).get("Size"),
                                     expected_sha256=(entry or {}).get("Sha256"))
    z = None
    if hands_res["status"] in ("downloaded", "skipped"):
        try:
            z = np.load(hands_path, allow_pickle=True)
            add("hnd01", "error", "hands.npz 可载入", True, f"{hands_res['bytes']}B")
        except Exception as e:
            add("hnd01", "error", "hands.npz 可载入", False, f"{type(e).__name__}: {e}")
    else:
        add("hnd01", "error", "hands.npz 可载入", False, hands_res.get("error"))

    if z is not None:
        T = int(z["pred_valid"].shape[1]) if "pred_valid" in z else None
        if "pred_valid" in z and T:
            pv = np.asarray(z["pred_valid"], dtype=np.float32)
            ratios = {("left" if i == 0 else "right"): float(pv[i].mean())
                      for i in range(min(2, pv.shape[0]))}
            worst = min(ratios.values())
            add("hnd02", "warn", "手部有效帧比例", worst >= 0.5,
                f"T={T} ratios={ {k: round(v, 3) for k, v in ratios.items()} }")
            if frames is not None and T:
                add("hnd03", "warn", "帧数对齐", abs(T - int(frames)) <= 2,
                    f"T={T} vs end_frame={frames}")
            else:
                add("hnd03", "warn", "帧数对齐", None, "frames 元数据缺失")
            focal = to_float(z["focal"]) if "focal" in z else None
            if focal is not None and uv_fx:
                add("hnd04", "warn", "focal 自洽",
                    abs(focal - uv_fx) / uv_fx <= 0.10,
                    f"focal={focal:.1f} vs undist_fx={uv_fx:.1f}")
            else:
                add("hnd04", "warn", "focal 自洽", None, "focal/fx 字段缺失")
        else:
            for rid in ("hnd02", "hnd03", "hnd04"):
                add(rid, "warn", dict((r[0], r[2]) for r in L2_RULES)[rid], None, "pred_valid 缺失")

    entry = client.stat_file(remote_path(sample_id, "camera_traj"))
    traj_res = client.download_file(remote_path(sample_id, "camera_traj"), traj_path,
                                    expected_size=(entry or {}).get("Size"),
                                    expected_sha256=(entry or {}).get("Sha256"))
    tz = None
    if traj_res["status"] in ("downloaded", "skipped"):
        try:
            tz = np.load(traj_path, allow_pickle=True)
            c2w = np.asarray(tz["cam_c2w"]) if "cam_c2w" in tz else None
            intr = np.asarray(tz["intrinsic"]) if "intrinsic" in tz else None
            ok_shape = (c2w is not None and ((c2w.ndim == 3 and c2w.shape[1:] == (4, 4))
                                             or (c2w.ndim == 2 and c2w.shape == (4, 4))))
            intr_ok = intr is not None and intr.shape == (3, 3) and intr[0, 0] > 0
            add("traj01", "error", "camera_traj.npz 可载入",
                bool(ok_shape and intr_ok),
                f"cam_c2w={None if c2w is None else c2w.shape}, "
                f"intrinsic={None if intr is None else intr.shape}")
            if tz is not None and z is not None and "pred_valid" in z and "cam_c2w" in tz:
                t_traj = int(np.asarray(tz["cam_c2w"]).shape[0])
                add("traj02", "warn", "轨迹与手帧一致", t_traj == T,
                    f"traj_T={t_traj} vs hands_T={T}")
            else:
                add("traj02", "warn", "轨迹与手帧一致", None, "字段缺失")
        except Exception as e:
            add("traj01", "error", "camera_traj.npz 可载入", False, f"{type(e).__name__}: {e}")
            add("traj02", "warn", "轨迹与手帧一致", None, "npz 加载失败")
    else:
        add("traj01", "error", "camera_traj.npz 可载入", False, traj_res.get("error"))
        add("traj02", "warn", "轨迹与手帧一致", None, "下载失败")
    return results


# ---------------------------------------------------------------------------
# 报告渲染
# ---------------------------------------------------------------------------
def render_report(results: List[Dict[str, Any]], meta: Dict[str, Any],
                  rules_l1, rules_l2, out_path: str, l2_note: str) -> str:
    df = pd.DataFrame(results)
    n_samples = df["sample_id"].nunique() if len(df) else 0

    def block(rules):
        lines = []
        for rid, sev, title, desc in rules:
            sub = df[df["rule_id"] == rid] if len(df) else pd.DataFrame()
            n = len(sub)
            n_pass = int((sub["passed"] == True).sum())  # noqa: E712
            n_fail = int((sub["passed"] == False).sum())  # noqa: E712
            fail_samples = sub[sub["passed"] == False]["sample_id"].tolist()[:5]  # noqa: E712
            lines.append(
                f"| {rid} | {title} | {sev} | {n_pass}/{n} | "
                f"{'; '.join(fail_samples) if fail_samples else '—'} |")
        return "\n".join(lines)

    if len(df):
        fail_by_sample = df.groupby("sample_id")["passed"].apply(
            lambda s: bool((s == False).any()))  # noqa: E712
        n_all_pass = int((~fail_by_sample).sum())
    else:
        n_all_pass = 0

    md = []
    md.append("# OpenAoE 数据质检报告（qc_report）\n")
    md.append(f"- 生成时间：{meta.get('generated_at')}")
    md.append(f"- 数据集：{meta.get('dataset')}（revision gmt_modified={meta.get('gmt_modified')}）")
    md.append(f"- 输入来源：{meta.get('source')}")
    md.append(f"- 检查样本数：{n_samples}；整体全绿样本：{n_all_pass}"
              f"（{100.0 * n_all_pass / max(1, n_samples):.1f}%）")
    md.append(f"- 检查级别：L1 元数据{' + L2 抽样深检' if rules_l2 else ''}")
    if l2_note:
        md.append(f"- L2 抽样说明：{l2_note}")
    md.append("\n## 规则通过率\n")
    md.append("| 规则 | 名称 | 级别(severity) | 通过 | 失败样本示例 |")
    md.append("| --- | --- | --- | --- | --- |")
    md.append(block(rules_l1))
    if rules_l2:
        md.append(block(rules_l2))
    md.append("\n## 结论与建议\n")
    # 自动结论
    fails = df[df["passed"] == False]  # noqa: E712
    if len(fails) == 0:
        md.append("- 未发现 failed 规则触发；子集在已启用的规则下质量合格。")
    else:
        top = fails.groupby(["rule_id", "title"]).size().sort_values(ascending=False).head(5)
        md.append("- 触发失败 Top 规则：")
        for (rid, title), cnt in top.items():
            sev = dict((r[0], r[1]) for r in list(rules_l1) + list(rules_l2))[rid]
            md.append(f"  - [{rid}] {title}（{sev}）：{cnt} 个样本")
        if "vi01" in set(top.index.get_level_values(0)):
            md.append("  - 建议：内参-分辨率不一致是上游 PR #1 移除样本的问题类型，"
                      "建议直接从子集中剔除（filter.py --qc-pass 可在筛选阶段即规避）。")
        if "ann01" in set(top.index.get_level_values(0)) or "ann02" in set(top.index.get_level_values(0)):
            md.append("  - 建议：时间/帧不连续样本通常需按段裁剪使用或剔除。")
    md.append("\n> 机器可读明细见 qc.parquet（列：sample_id, rule_id, level, severity, passed, detail）。")
    text = "\n".join(md) + "\n"
    if out_path:
        os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(text)
    return text


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def parse_args(argv=None):
    p = argparse.ArgumentParser(description="OpenAoE 分层质检（L1 元数据 / L2 抽样深检）")
    src = p.add_mutually_exclusive_group()
    src.add_argument("--subset", help="subset.json（filter.py 的输出）")
    src.add_argument("--samples", help="逗号分隔 sample_id 列表")
    src.add_argument("--index", default=".cache/openaoe_index.parquet",
                     help="索引 parquet（未指定 subset/samples 时全量检查）")
    p.add_argument("--level", default="l1", choices=["l1", "l2", "both"], help="质检层级")
    p.add_argument("--use-index", action="store_true",
                   help="L1 直接使用索引聚合字段（不发请求，规则粒度受限，适合大子集快查）")
    p.add_argument("--verify-fail", action="store_true",
                   help="仅配合 --use-index：对 intrinsics_ok 为空或 False 的样本回源拉原始 JSON "
                        "现算复核（现算结果以其为准，覆盖索引值）；True 的样本仍走离线不发请求。"
                        "用于快查基础上对可疑样本做保险复算（会产生少量网络请求）")
    p.add_argument("--sample-ratio", type=float, default=0.05, help="L2 抽样比例")
    p.add_argument("--l2-limit", type=int, default=50, help="L2 抽样绝对上限")
    p.add_argument("--min-conf", type=float, default=0.3, help="ann06 阈值")
    p.add_argument("--limit", type=int, help="输入样本上限（调试）")
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--l2-cache", default=".cache/l2", help="L2 npz 缓存目录（可复用）")
    p.add_argument("--out-md", default="qc_report.md", help="报告输出路径")
    p.add_argument("--out-parquet", default="qc.parquet", help="明细 parquet 输出路径")
    p.add_argument("--token", help="ModelScope token（默认 .env）")
    return p.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(argv)
    # ---- 收集样本与元数据 ----
    frames_map: Dict[str, Any] = {}
    fx_map: Dict[str, Any] = {}
    index_rows: Dict[str, Dict[str, Any]] = {}

    if a.samples:
        sample_ids = [s.strip() for s in a.samples.split(",") if s.strip()]
        source_desc = f"--samples（{len(sample_ids)} 个）"
    elif a.subset:
        with open(a.subset, "r", encoding="utf-8") as fh:
            subset = json.load(fh)
        sample_ids = [s["sample_id"] for s in subset.get("samples", [])]
        for s in subset.get("samples", []):
            frames_map[s["sample_id"]] = s.get("frames")
        source_desc = f"{a.subset}（{len(sample_ids)} 个）"
    else:
        if not os.path.isfile(a.index):
            print(f"错误：索引不存在 {a.index}，请先 build_index.py", file=sys.stderr)
            return 2
        idx = pd.read_parquet(a.index)
        sample_ids = idx["sample_id"].tolist()
        for _, r in idx.iterrows():
            index_rows[r["sample_id"]] = r.to_dict()
        source_desc = f"{a.index} 全量（{len(sample_ids)} 个）"

    if not sample_ids:
        print("错误：未找到待检样本（subset/samples/输入为空）", file=sys.stderr)
        return 2

    # 补充元数据：索引里取 frames/分辨（离线可用）；fx 在线时再补。
    # ⚠ --subset/--samples + --use-index 时也必须在此装载 index_rows，否则离线路径
    #   拿到空 index_row → vi/anno 字段全 None → bool(None)=False 把规则全误判失败
    #   （2026-09-03 修复 C-3：此前 index_rows 仅在全量模式填充，subset 快查恒误报）。
    if os.path.isfile(a.index) and (not frames_map or not fx_map or (a.use_index and not index_rows)):
        try:
            idx = pd.read_parquet(a.index).set_index("sample_id")
            for s in sample_ids:
                if s in idx.index:
                    row = idx.loc[s]
                    if isinstance(row, pd.DataFrame):
                        row = row.iloc[-1]
                    frames_map.setdefault(s, row.get("frames"))
                    if a.use_index and s not in index_rows:
                        index_rows[s] = row.to_dict()
        except Exception:
            pass
    if a.limit:
        sample_ids = sample_ids[: a.limit]

    run_l2 = a.level in ("l2", "both")
    do_index_only = a.use_index and not run_l2
    # --verify-fail：use-index 快查基础上，对 intrinsics_ok 为空/False 的样本回源复算。
    # 先算出需复算的样本集；仅当确有可疑样本时才建 client（无可疑则保持 0 请求）。
    verify_ids: set = set()
    if do_index_only and a.verify_fail:
        for sid in sample_ids:
            iok = (index_rows.get(sid) or {}).get("intrinsics_ok")
            if iok is None or iok is False:
                verify_ids.add(sid)
    client: Optional[OpenAoEClient] = None
    if (not do_index_only) or verify_ids:
        client = OpenAoEClient(token=a.token)

    gmt_modified = None
    if client is not None:
        try:
            snap = client.revision_snapshot()
            gmt_modified = snap.get("dataset_gmt_modified")
        except ApiError:
            gmt_modified = None
    if gmt_modified is None:
        state_path = a.index + ".state.json"
        if os.path.isfile(state_path):
            try:
                gmt_modified = json.load(open(state_path)).get("revision", {}).get("dataset_gmt_modified")
            except (OSError, json.JSONDecodeError):
                pass

    results: List[Dict[str, Any]] = []
    mode_desc = ("在线拉取元数据" if not do_index_only
                 else (f"索引离线模式（{len(verify_ids)} 个可疑样本 --verify-fail 回源复算）"
                       if verify_ids else "索引离线模式（0 请求）"))
    print(f"[L1] 检查 {len(sample_ids)} 个样本（{mode_desc}，workers={a.workers}）",
          file=sys.stderr)
    with ThreadPoolExecutor(max_workers=max(1, a.workers)) as pool:
        futs = {}
        for sid in sample_ids:
            if do_index_only and sid not in verify_ids:
                # 离线快查：直接用索引聚合字段（0 请求）
                futs[pool.submit(check_sample_l1, None, sid,
                                 {"status": "ok", **(index_rows.get(sid) or {})},
                                 a.min_conf)] = sid
            elif do_index_only and sid in verify_ids:
                # --verify-fail：intrinsics_ok 空/False 的可疑样本 → 回源拉 JSON 现算复核
                # （client 非 None；在线路径直接从原始 JSON 现算 vi01，结果即覆盖索引旧值）
                futs[pool.submit(check_sample_l1, client, sid,
                                 index_rows.get(sid), a.min_conf)] = sid
            else:
                futs[pool.submit(check_sample_l1, client, sid,
                                 index_rows.get(sid), a.min_conf)] = sid
        done = 0
        for fut in as_completed(futs):
            row_res = fut.result()
            results.extend(row_res)
            done += 1
            if done % 200 == 0:
                print(f"    L1 进度 {done}/{len(sample_ids)}", file=sys.stderr)

    l2_note = ""
    l2_ids: List[str] = []
    if run_l2:
        # 分层抽样：优先在"候选子集"里抽，而不是全库
        rng = random.Random(20260901)
        if len(sample_ids) > a.l2_limit or len(sample_ids) > round(len(sample_ids) * float(a.sample_ratio or 0)):
            n_pick = max(1, min(a.l2_limit, round(len(sample_ids) * a.sample_ratio)))
            l2_ids = rng.sample(sample_ids, n_pick)
        else:
            l2_ids = list(sample_ids)
        l2_note = (f"样本比例 {a.sample_ratio}，实际抽取 {len(l2_ids)} 个"
                   f"（缓存目录 {a.l2_cache}，下载约 {len(l2_ids) * 3.7:.0f}MB npz）")
        print(f"[L2] 抽样深检 {len(l2_ids)} 个样本", file=sys.stderr)
        # 补充 fx：去 undistorted json（在线时才有）
        if client is not None:
            for sid in l2_ids:
                try:
                    uv = parse_json_bytes(client.download_bytes(remote_path(sid, "undistorted_info")))
                    cam = uv.get("cameraParams") or {}
                    fx_map[sid] = to_float(cam.get("fx_pixels"))
                except (ApiError, ValueError):
                    fx_map[sid] = None
        with ThreadPoolExecutor(max_workers=max(1, min(a.workers, 4))) as pool:
            futs = {pool.submit(check_sample_l2, client, sid,
                                os.path.join(a.l2_cache, sid),
                                frames_map.get(sid), fx_map.get(sid)): sid
                    for sid in l2_ids}
            for fut in as_completed(futs):
                results.extend(fut.result())

    # ---- 输出 ----
    pdf = pd.DataFrame(results)
    os.makedirs(os.path.dirname(os.path.abspath(a.out_parquet)) or ".", exist_ok=True)
    pdf.to_parquet(a.out_parquet, index=False)

    rules_l2 = L2_RULES if run_l2 else []
    text = render_report(results, {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "dataset": "inclusionAI/OpenAoE-2000h",
        "gmt_modified": gmt_modified,
        "source": source_desc,
    }, L1_RULES, rules_l2, a.out_md, l2_note)
    print(text)
    print(f"质检完成：{a.out_md} / {a.out_parquet}")
    fails = int((pdf["passed"] == False).sum())  # noqa: E712
    print(f"规则明细 {len(pdf)} 条；failed {fails} 条")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
