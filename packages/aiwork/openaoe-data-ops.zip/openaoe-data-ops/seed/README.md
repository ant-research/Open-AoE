# openaoe-data-ops 预置索引（skill 内置 seed）

> 用途：把"全库 25,456 个样本的元数据索引"随 skill 一起分发，**新用户免全量构建**
> （全量重建约 75 分钟 / 95k 次 API 请求）。本目录（`seed/`）**随 skill 包内置分发**，
> 安装即得；数据集持续上传，用前做一次增量即可。

## 内容（两件套，必须一起转送）

| 文件 | 作用 |
| --- | --- |
| `openaoe_index.parquet` | 索引数据本体：一行一样本，37 列（schema 见 `../references/dataset-schema.md` §8） |
| `openaoe_index.parquet.state.json` | 版本水位 + 断点名单（增量更新与过期判断的依据；离了它 index 只能读不能续） |

## 本快照信息

| 项 | 值 |
| --- | --- |
| 样本数 | 25,456（ok 25,442 / partial 13 / error 1） |
| 构建时间 | 2026-09-03T15:26:39+0800 |
| vi1.1 内参规则刷新 | 2026-09-02（`intrinsics_ok=False` 从 8,685 误报修正为 136 真异常：全库 8.8k 变焦广角样本曾因"原始fovH=镜头视场 ↔ fx=变焦内参"被误判，详见 `../references/dataset-schema.md` §4.1） |
| 水位 | root_total=25,459；dataset_gmt_modified=1788420169（dataset_id=205584） |
| 保质期 | 数据集持续上传（2000h 目标），建议使用前做一次增量 |

## 转移到其他 agent 框架 / 给其他人用（3 步）

```bash
# 1. 把整个 skill 目录拷走（seed 已内置，无需另带资产包）
openaoe-data-ops/            # skill 本体（SKILL.md + scripts/ + seed/）

# 2. 在新工作区把两件套放进默认缓存位置（scripts 的默认 --index 即 .cache/）
mkdir -p .cache
cp openaoe-data-ops/seed/openaoe_index.parquet* .cache/

# 3. 首次使用前做一次增量更新（分钟级，只拉 seed 水位之后的新样本；
#    不加 --incremental 也安全：断点机制识别已完成样本同样跳过）
python3 openaoe-data-ops/scripts/build_index.py \
    --out .cache/openaoe_index.parquet --incremental
```

之后所有命令按 `SKILL.md` 正常使用（filter / quality_check / visualize / download_subset
默认读 `.cache/openaoe_index.parquet`，也可显式 `--index <任意路径>`——
注意增量写回不要直接指向 skill 包内的 `seed/` 目录（安装目录保持只读），先复制到工作区）。

也可以不放 `.cache/`：任何位置 `--index /path/to/openaoe_index.parquet` 都可读，
但需要 state 文件与 parquet 同名相邻（`.state.json` 后缀）。

## 许可说明

本索引是对数据集公开元数据（video_info / 标注 JSON / 去畸变参数）的聚合派生物：

- 内容均为元数据统计（场景/时长/任务对/机型/FOV/连续性 flag 等），**不含 MANO 衍生数值**（hands.npz 仅记录体积字节数），不受 MANO license 附加约束。
- 依 Open-AoE 数据集许可：再分发请保留署名（Open-AoE，ModelScope `inclusionAI/OpenAoE-2000h`，arXiv:2607.14183）。
- 完整许可要点：`../references/license-notes.md`。

## 校验

```bash
python3 - <<'EOF'
import pyarrow.parquet as pq
pf = pq.ParquetFile('openaoe_index.parquet')
print('rows =', pf.metadata.num_rows)   # 预期 25456（随增量更新增长）
print('cols =', len(pf.schema_arrow.names))  # 预期 37
EOF
```
