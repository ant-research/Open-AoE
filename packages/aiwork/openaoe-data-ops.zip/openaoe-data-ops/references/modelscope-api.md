# ModelScope 数据集 API 约定与实测坑位记录

> `openaoe_client.py` 的设计依据；全部结论来自 2026-09-01 带 token 实测。
> 若 ModelScope 行为变化（无文档 API 可能漂移），先复测本文所列行为再改 client。

## 0. 鉴权

| 项 | 结论 |
| --- | --- |
| token 获取 | ModelScope 账号中心（访问令牌）；放项目根 `.env`：`token=ms-xxxx`，或环境变量 `OPENAOE_MS_TOKEN` |
| 请求头 | `Authorization: Bearer <token>`（每个请求） |
| 失效表现 | HTTP 401/403 → client 抛 `TokenError`，提示检查 .env |
| 兜底 | 同库 HuggingFace 版数据（`huggingface_hub`）可用于交叉验证 |

## 1. 三个核心端点

| 用途 | 端点 | 备注 |
| --- | --- | --- |
| 元信息+README | `GET /api/v1/datasets/inclusionAI/OpenAoE-2000h` | 返回 `Data`（Id/Name/License/GmtModified/ReadmeContent…） |
| 文件树 | `GET /api/v1/datasets/{ns}/{name}/repo/tree?Revision=master&Root=<path>&PageSize=<n>&PageNumber=<k>` | `Data.Files[]`、`Data.TotalCount`；文件含 `Size/Sha256/IsLFS/Type(blob|tree)` |
| 下载 | `GET /api/v1/datasets/{ns}/{name}/repo?Revision=master&FilePath=<path>` | **302 重定向到 CDN**，必须跟随（`-L`/requests 默认）；LFS 大文件实测良好 |

## 2. 实测坑位清单（按踩坑概率排序）

### 坑 1：翻页语义（⚠ 最重要）
- **PageNumber=0 与 PageNumber=1 都返回第一页**；真正的第二页从 `PageNumber=2` 开始。
- 防御策略（client 内置）：从 1 开始请求 + 以"该页条目 Path 是否全部已见"作指纹判重；连续 3 个全重复页（或指回第一页）即判定翻页边界熔断，避免死循环。数据集仍在持续上传，列表存在漂移，按 Path 去重。
- `TotalCount` 是**弱终止条件**（返回的是根目录全部条目数，含 README/LICENSE 等根文件 —— 实测 23,643 = 3 根文件 + 23,640 样本目录）。

### 坑 2：tree 返回的 Sha256 可信且可用于校验
- `blob` 条目 `Sha256`（LFS 文件为例）与实际下载文件 sha256 **完全一致**（实测 `camera_traj.npz`）。
- 小 JSON（部分非 LFS）可能为空字符串 → 下载校验降级为"仅体积 + 可解析性"。

### 坑 3：下载必须跟随重定向
- `/repo?FilePath=...` 返回 302 → CDN 签名 URL。requests `allow_redirects=True` 默认即可；
  原始 URL 二次复用一般也有效，但以每次跟随为准。
- CDN 支持 Range 断点续传（实测截断 100,000B 后 `bytes=100000-` 返回 206 正常续传）。

### 坑 4：限流
- 高并发下会出现 429/5xx（无公开文档 quota）。实测 16 workers + 0.02s 初始节流全量 2.4 万样本×4 请求基本无 429。
- client 策略：`AdaptiveThrottle`（429/5xx 时 per-request 延迟 ×1.8 最长 8s；成功缓慢 ×0.97 恢复）+ 请求级指数退避重试（默认 6 次，遵循 `Retry-After`）。
- 重试只针对 429/500/502/503/504 + 连接错误/超时；401/403 直接失败（token 问题）。

### 坑 5：翻页过程中的数据漂移
- 数据库持续上传 → 深翻页时列表会漂移。索引构建使用"Path 去重 + 版本水位快照"，增量模式按样本名比对。

### 坑 6：响应结构细节
- 成功响应 `Code=200` 且 `Data` 存在；错误用 `Code` + `Message`。
- tree `Type`: `blob`（文件）/`tree`（目录）；目录条目 `Size=0`。
- `IsLFS=True` 的文件（含部分小 JSON）与 False 的处理一致（跟随重定向后内容一样）；真正的大视频 50–90MB。

## 3. 版本水位（revision 快照）

数据集 ~694h/2000h 仍在持续上传，任何"快照"必须带血缘。可用的水位信号（`OpenAoEClient.revision_snapshot()`）：

```
dataset: "inclusionAI/OpenAoE-2000h"
dataset_id: 205584                      # 恒定
dataset_gmt_modified: <unix_ts>         # 数据集元信息变更时间（增长=有新上传）
root_total: 23643                       # 当前根目录条目数（增长=新样本）
captured_at: <ISO 时间>
```

判断索引是否过期：重建一个快照，比对 `root_total` / `gmt_modified` 与索引 state 中记录值；变大即建议 `--incremental` 增量更新。manifest（下载）同样记录快照保证复现性。

## 4. 频次与配额经验

| 操作 | 请求数 | 实测耗时（16 workers） |
| --- | --- | --- |
| meta + revision 快照 | 2 | ~1s |
| 枚举根目录全量（PageSize=500） | ~48 页 | 2–3 min |
| 单样本元数据（3 JSON + tree） | 4 | ~0.7s |
| 全量索引（23,640 样本） | ~95k | 约 30–60 min |
| 单文件 stat + 下载 | 2 | 视大小 |

> 若遇到系统性 429：`--workers` 降 8/4，`AdaptiveThrottle` 会自动放大间隔；`build_index.py` 可断点续跑（state 文件），中断后重跑同一命令即续。

## 5. 直链与 SDK 替代路径（兜底）

- ModelScope SDK：`from modelscope.msdatasets import MsDataset`（git 克隆式全量拉取，不适合筛选场景）。
- HuggingFace 同库数据集可作交叉源（不同 host 的限额与 CDN）。
- 本 skill v0 采取"纯 REST + 精准筛选"策略：不做任何全量克隆。
