# OpenAoE 许可与署名要点（分发/商用前必读）

> 依据官方 README 与 LICENSE（ModelScope `inclusionAI/OpenAoE-2000h`，2026-09 版本）。
> 本 skill 的下载器（download_subset.py）会自动在子集目录生成 `ATTRIBUTION.md` 随附同样的声明。

## 1. 三层许可结构

| 层 | 覆盖范围 | 许可 | 关键义务 |
| --- | --- | --- | --- |
| 数据本体 | `raw_video.mp4`、`video_info.json`、`ego_annotation/**`（scene/动作标注） | Open-AoE Dataset License | **研究 + 商用双许可**，但必须**署名 Open-AoE** |
| MANO 衍生 | `hands.npz`、`camera_traj.npz`、`hands_combined.mp4`、`overview.png` | Open-AoE Dataset License **叠加 MANO License** | 商用前须从 MANO 获得单独授权 |
| 代码 | 上游仓库 `ant-research/Open-AoE` | Apache 2.0 | 仅覆盖代码，**不含数据** |

## 2. 署名（Attribution）最低要求

分发/展示/派生作品时声明：

- 数据集：Open-AoE Egocentric Hand Manipulation Dataset，ModelScope `inclusionAI/OpenAoE-2000h`
- 论文：arXiv:2607.14183
- （建议附）下载 revision 快照（本 skill 的 manifest 已自动记录，保证可追溯具体版本）

## 3. MANO 附加条款与工程隔离策略

- `hands.npz`（含 `pred_hand_pose`/`pred_betas` 等 MANO 参数）、`camera_traj.npz` 及可视化产物属于 MANO 模型衍生数据，受 [mano.is.tue.mpg.de/license.html](https://mano.is.tue.mpg.de/license.html) 约束。
- 官方明示替代方案：**只用视频与原子动作标注、不加载 MANO 衍生文件**是允许的路径（`download_subset.py --categories minimal` 即实现该隔离）。
- 类别名对照（download_subset.py 的 categories）：
  - 无 MANO 顾虑：`annotation`、`video_info`、`undistorted_info`、`undistorted_video`、`raw_video`
  - **含 MANO 限制**：`hands`、`camera_traj`、`overview`、`hands_video`（manifest 与 ATTRIBUTION.md 均已标注）
- **渲染视频产物（`render_videos.py` → `AoE_output_vis.mp4`）同属 MANO 衍生**
  （由本地 MANO 模型前向渲染得到的手部 mesh 叠加）：对内审查/质检使用无碍，
  对外再分发前与 `hands.npz` 同桶处理（研究用途署名即可、商用先获 MANO 授权）。
- **vendored 渲染器与 MANO 模型资产分离**：`vendor/aoe-vis/`（Apache-2.0 代码）随 skill
  分发合规；`vendor/aoe-vis/assets/mano/`（MANO pkl/npz 模型本体）**不入 git、不随包
  分发**，每台机器注册下载后本地转换（`.gitignore` 已隔离，详见
  `vendor/aoe-vis/NOTICE-vendor.md`）。

## 4. 操作建议（写进交付报告的话术）

1. 内部/研究使用：常规署名即可。
2. 对外分发子集：随附 `ATTRIBUTION.md` + `_openaoe_manifest.json`（含 revision 血缘）。
3. 商用计划：先确认（a）署名链路（b）MANO 衍生文件是否需要 —— 若需要且用途商用，先取得 MANO 授权或改用 minimal 类别。
4. 本工具不上传/不转存：只读下载，许可合规责任在使用方。

## 5. 相关上游链接

- 数据集主页：https://www.modelscope.cn/datasets/inclusionAI/OpenAoE-2000h
- 上游代码：https://github.com/ant-research/Open-AoE（Apache 2.0）
- MANO License：https://mano.is.tue.mpg.de/license.html
- 论文：arXiv:2607.14183
