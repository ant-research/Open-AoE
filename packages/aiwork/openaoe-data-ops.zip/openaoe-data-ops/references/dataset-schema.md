# OpenAoE-2000h 数据集 Schema（字段表 + 数据合同要点）

> 提炼自官方 README（ModelScope `inclusionAI/OpenAoE-2000h`，2026-09 实测核对）。
> 本文是 `openaoe-data-ops` 所有脚本（索引/筛选/质检/可视化/下载）的字段口径依据。

## 1. 数据集概览

| 项 | 值 |
| --- | --- |
| 全称 | Open-AoE — Egocentric Hand Manipulation Dataset（蚂蚁集团第一人称数据集） |
| 平台 | ModelScope `inclusionAI/OpenAoE-2000h`（HF 镜像兜底） |
| 规模 | 根目录 23,643 条目 ≈ 23,640 样本目录（持续上传：~694h / 目标 2000h） |
| 内容 | 3D 手部重建（MANO）+ SLAM 相机轨迹（米制）+ 细粒度原子动作标注 |
| 规格 | 30 FPS；1280×720（多数）/1920×1080；MANO 15 关节位姿 + 10 维形状 |
| 论文 | arXiv:2607.14183 |

## 2. 样本目录结构（两类命名：`aoe_*` 早期批次 / `raw_*_seg_*` 主批次）

```
<sample>/
├── raw_video.mp4                          # 30FPS 原始视频（LFS，50–90MB）
├── video_info.json                        # 设备信息 + 原始内参（含畸变）
├── ego_annotation/
│   └── ego_action_annotation.json         # 分段原子动作标注（7~39 段/样本）
└── ego_process/
    ├── ego_hands_reconstruction/
    │   ├── hands.npz                      # MANO 双手参数 + 相机位姿（~3.1MB/2.8min）
    │   ├── camera_traj.npz                # SLAM 相机轨迹 + 内参（~640KB）
    │   └── visualization/
    │       ├── hands_combined.mp4         # 手部网格叠加可视化视频（左紫右蓝）
    │       └── overview.png               # 相机轨迹+手运动轨迹总览图
    └── ego_undistorted_video/
        ├── raw_video_undistorted.mp4      # 去畸变视频（手部/轨迹数据配它用）
        └── undistorted_video_info.json    # 去畸变内参 + FOV + fps
```

**⚠ 两类批次结构差异（2026-09 实测，affects 解析兜底）**：

| 字段 | `raw_*_seg_*` 主批次 | `aoe_202601*_*` 早期批次 | 解析兜底策略 |
| --- | --- | --- | --- |
| `cameraParams.fps` | ✅ 30 | ❌ 缺失 | 由 `undistorted_video_info.json` 顶层 `fps` 补 |
| `cameraParams.fovH/V_degrees` | ✅ | ❌ 缺失 | 由 `fx/res_w` 反推：fov=2·atan(w/(2fx)) |
| `cameraParams.lensDistortionOrder` | ✅ "k1,k2,t/p..." | ❌ 缺失 | 按缺省约定 k1,k2,k3,p1,p2 |
| `lensDistortion` | 字符串 `"[...]"` | 原生数组 `[...]` | 双格式解析 |
| 顶层 `imu/localization/perspective` | ✅ | ❌ | 缺失即空，非错误 |

## 3. 标注文件 `ego_annotation/ego_action_annotation.json`

JSON 数组，每元素 = 一个时间段：

| 字段 | 类型 | 说明 |
| --- | --- | --- |
| `id` | int | 段序号（从 1 递增） |
| `start_ts` / `end_ts` | **string** | 起止秒（⚠ 需转数值；早期批次有 ~0.005s 舍入噪声） |
| `start_frame` / `end_frame` | **string** | 帧号（≈ round(ts×30)；⚠ 参数为字符串） |
| `scene` | string | 场景英文（`kitchen` / `living room` / `bedroom`…，自由文本） |
| `atomic_action[]` | array | 原子动作列表（通常 1 段 1 动作） |
| `atomic_action[].verb` | string | 细粒度动作动词（`grasp`/`twist`/`slide`…） |
| `atomic_action[].object` | string | 交互物体（英文短语） |
| `atomic_action[].hand` | string | `left`/`right`/`both`/`none` |
| `atomic_action[].description` | string | 一句话动作描述 |
| `atomic_action[].bbox` | int[4] | `[x1,y1,x2,y2]`，**raw_video 像素坐标**（对齐需看 video_info 分辨率） |
| `atomic_action[].confidence` | float | 0~1 |

标注约定（可机器校验，= L1 质检规则依据）：全覆盖无空洞、`clip[i].end_ts == clip[i+1].start_ts`、首段从 0 起、一段一动作、动词避免模糊词。

## 4. `video_info.json` / `undistorted_video_info.json` 关键字段

| 字段 | 用途 | 脚本口径 |
| --- | --- | --- |
| `deviceInfo.brand/model/androidVersion` | 机型筛选维度 | filter `--brand/--model` |
| `cameraParams.resolution`（"1280x720"） | 分辨率维度 | filter `--resolution` |
| `cameraParams.fps` | 时长↔帧帧换算 | 30；兜底见第 2 节 |
| `cameraParams.fx/fy/cx/cy_pixels` | 内参一致性（PR #1 问题） | L1 规则 vi01（见 §4.1） |
| `cameraParams.fovHorizontal/Vertical_degrees` | 原始 FOV | 缺失反推 |
| `cameraParams.lensDistortion(+Order)` | 畸变合法性 | L1 规则 vi02 |
| `fov_x_degrees/fov_y_degrees`（undistorted） | **FOV 筛选维度口径** | filter `--fov-x-gt` 等 |
| `localization.region` | 地域 | 索引 `region` 列 |

### 4.1 vi01 内参一致性的裁决语义（2026-09-02 修正，重要）

变焦广角样本（`isZoomWideAngle/isWideAngle=true`，实测全库 ~36.7%）的字段语义分层：

- `fovHorizontal_degrees` 报**广角镜头物理视场**（如 94.8°）；`fx_pixels` 是**变焦裁剪后
  的有效内参** → 这一对**必然不自洽，不代表坏样本**（旧规则把 8,685 个此类样本误判 error）
- **真正对齐的一对**是 `vi.fx ↔ uv.fov_x_degrees`（去畸变 FOV；实测 zoomRatio=0.6 样本
  fx=855 ↔ fov_x=73.59°，反推精确吻合）

vi1.1 判定式（`resolve_intrinsics_ok`，build 在线质检同源）：
`intrinsics_ok = 分辨率可解析 AND fx/fy>0 AND 主点居中(±25%/35%) AND |w/(2·tan(fov_x/2)) − fx|/fx ≤ 10%`
（无 uv 时退回原始 fovH 检查，仅非广角样本参与）


## 5. `hands.npz`（MANO 衍生，⚠ engine license 见 license-notes.md）

| 键 | shape | 说明 |
| --- | --- | --- |
| `pred_valid` | (2, T) | float32 0/1 有效帧掩码；[0]=左、[1]=右；**必须过滤无效帧** |
| `pred_trans/pred_rot` | (2, T, 3/…) | 世界系 MANO 全局平移/旋转（axis-angle） |
| `pred_trans_cam/pred_rot_cam` | (2, T, 3/…) | 相机系 |
| `pred_hand_pose` | (2, T, 45) | 15 关节×3（axis-angle） |
| `pred_betas` | (2, T, 10) | 形状参数 |
| `R_w2c/t_w2c`、`R_c2w/t_c2w` | (T, 3, 3)/(T, 3) | 相机位姿（1×3 旋转+平移） |
| `focal` | scalar | = fx（去畸变后偶有差异，投影优先用 undistorted fx/fy） |

实测对齐关系：`T == 末段 end_frame`（如 4103）、与 `camera_traj.npz.cam_c2w` 数一致。
左手索引 0、右手索引 1。旋转是 axis-angle，使用前须转旋转矩阵。3D 坐标单位米。

## 6. `camera_traj.npz`

| 键 | shape | 说明 |
| --- | --- | --- |
| `cam_c2w` | (T, 4, 4) | 相机→世界齐次变换（SLAM，米制；世界系参考首帧相机位姿） |
| `intrinsic` | (3, 3) | 内参矩阵（内参全帧固定） |

## 7. 坐标系（投影速查）

- 相机系：OpenCV 约定（x 右、y 下、z 前）。
- 世界系：SLAM 定义，参考首帧，单位米。
- `p_world = R_c2w @ p_cam + t_c2w`（3×3+3×1 在 hands.npz）；`cam_c2w @ [p;1]`（4×4 在 camera_traj.npz）。
- 投影 `u = fx·px/pz + cx`（fx/fy/cx/cy 取 undistorted_video_info.json 或 intrinsic）。

## 8. 索引行 schema（`.cache/openaoe_index.parquet`，一行一样本）

| 列 | 类型 | 说明 |
| --- | --- | --- |
| `sample_id` | string | 样本目录名 |
| `status` / `status_detail` | string | ok / partial / missing（partial 说明缺哪个 JSON） |
| `n_segments` `n_actions` `frames` | int | 标注分段数 / 原子动作数 / 末段 end_frame |
| `duration_s` | float | 时长（末段 end_ts） |
| `scenes` `primary_scene` | list/str | 去重场景 / 按时长加权主场景 |
| `tasks` | list<string> | `["verb+object",…]` 任务对列表（**verb/object 统计由此列实时派生**；变键 dict 频次表禁止入 parquet，见 §8.1） |
| `verb_durations` | list<string> | 按 verb 累计时长降序 Top-20，每项 `"verb:seconds:rank"`（段级归因：段时长计入该段出现的每个 verb）。**用于按"主导动作时长占比/排名"筛选**（如"炒菜时长排进前三"）；`list<string>` 定长上界，内存安全（同 §8.1 红线：禁用 `{verb:秒}` 变键 dict） |
| `verb_seconds_total` | float | 各段时长之和（`verb_durations` 占比的分母：主导动作时长占比 = 某 verb seconds / 该值） |
| `hand_counts` | struct(4 键 int) | left/right/both/none 各自原子动作计数（固定 4 键，安全） |
| `confidence_mean` `confidence_min` | float | 置信度聚合 |
| `device_brand` `device_model` `android_version` | string | 机型 |
| `resolution` `res_w/h` `fps` | — | 分辨率（含 aoe 批次兜底） |
| `fov_x_deg` `fov_y_deg` `fov_h_deg` `fov_v_deg` | float | 去畸变 FOV（`fov_x/y` 筛选口径）；`fov_h/v` 为原始镜头物理视场（广角/变焦辨析见 §4.1） |
| `ts_continuous` `frame_continuous` | bool | L1 ann01/ann02 预计算（容差 0.05s/1 帧） |
| `intrinsics_ok` `distortion_ok` | bool | L1 vi01/vi02 预计算（vi01 为 §4.1 vi1.1 语义） |
| `bbox_bad_count` `bbox_oof_count` `hand_bad_count` | int | ann04/ann05/ann07 预计算 |
| `raw_video_bytes` `anno_bytes` `hands_bytes` | int | 体量（tree 一次探测，不下载） |
| `region` | string | 地域（无 GPS 具体值，多为地区名） |

### §8.1 列设计红线（内存安全契约，2026-09 实测教训）

- **变键 dict 禁止入 parquet**：pandas 把 dict 列交给 pyarrow 时会按"全库出现过的键并集"推断
  struct —— 1.5 万行的 `object_counts` 物化成 4 万键 struct，读回即 ~39GB 内存。动词/物体
  统计一律存 `tasks`（list<string>）实时派生；固定键计数用固定 struct（如 hand_counts 4 键）。
- **流式构建**：build_index 以 500 行分片落盘（`.parts/`），compact 逐分片合并，全程不把
  整表读回内存；旧版本"读回+concat+重写"模式已废弃。
- **汇总统计走 parquet 元数据**（row group null_count / 单列读取），不整表物化 pandas。
- 其余列均可空（nullable）；`n_confident_actions` 等派生列由下游工具按需计算。

## 9. 数据合同要点（下游使用必读）

1. **视频本体对齐**：bbox/帧号在 `raw_video.mp4` 像素空间；hands/trajectory 配 `raw_video_undistorted.mp4` 按帧号对齐（帧序一致）。
2. **字符串数字陷阱**：标注 ts/frame 全为字符串，必须转换。
3. **工程量守恒**：`T(hands) ≈ end_frame(标注)`，可做一致性闸门。
4. **有效帧纪律**：`pred_valid` 过滤是硬要求，无效帧数据不可信。
5. **投影内参选择**：优先 undistorted 内参 / intrinsic 矩阵，`hands.npz.focal` 仅作交叉校验。
6. **全帧固定内参**：去畸变后内参不随帧变化。
