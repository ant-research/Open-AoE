---
name: hand-body-reconstruction
description: 从人类视频重建手、手臂、全身与相机的 3D 关系。覆盖 MANO 手部、SMPL-X 上半身/全身、单目/多目相机轨迹恢复、物体 6-DoF 估计的方法要点与输入体检 checklist。人类数据转换专家在输入检查阶段用其中的输入体检部分，在重建阶段用重建部分。
version: 0.1.0
activation: auto
tags:
  - reconstruction
  - mano
  - smplx
  - camera-trajectory
requires:
  bins:
    - python3
  tools:
    - shell
---

# Hand & Body Reconstruction

## 输入体检 checklist（输入检查阶段用）

对每一批输入视频，逐项过：

1. **文件与容器**：容器格式（mp4/mov/webm）、编码（h264/h265）、是否可 seek。
2. **分辨率与帧率**：短边 ≥ 480 建议、fps ≥ 24 建议；小于该阈值降级为 C。
3. **手部可见性**：抽样 5 帧，用简单手部检测器（例如 MediaPipe Hands）测手部出现率；< 60% 记为遮挡严重。
4. **相机标定**：是否有 intrinsics（fx, fy, cx, cy）+ distortion；无标定则相机轨迹置信度降低。
5. **时序**：帧间时间戳单调递增，间隔 CV < 0.1。
6. **多路同步**：若含多路（RGB + IMU），时间戳同源，最大偏差 < 1 帧。
7. **许可**：明确训练许可与敏感内容。

## 手部重建（MANO / 关键点）

- **MANO 参数**：45 维 pose + 10 维 shape，能给出完整手形与姿态。适合灵巧手 retarget。
- **21 关键点**：MediaPipe / HaMeR，快、稳，但没有形状；适合平行夹爪或粗糙 retarget。
- **选择原则**：目标是灵巧手 → MANO；目标是平行夹爪 → 关键点即可。
- **常见坑**：左右手混淆、单帧抖动、握持时被物体遮挡。抖动用一维时序滤波，遮挡段用"最近可信帧插值 + 标记为不可训练"。

## 手臂 / 全身重建（SMPL-X）

- **上半身简化**：胸-肩-肘-腕 9 自由度，通常已足够。
- **全身 SMPL-X**：如任务涉及底盘移动或蹲下等姿态才需要。
- **常见坑**：Ego 相机看不到自己的躯干，全身参数不可靠；此时只解算上臂/前臂即可。

## 相机轨迹

- **有 IMU**：直接融合。
- **无 IMU 但有多帧**：ORB-SLAM / DROID-SLAM / VGG-SFM。
- **单目短片段**：置信度低，用相对轨迹即可，不要输出绝对尺度。

## 物体 6-DoF（可选）

- **有 CAD 或 3D 模型**：BundleSDF / FoundationPose。
- **无模型**：只输出物体 2D 包围盒 + 抓取点估计。

## References

- `references/mano-basics.md` — MANO 参数含义与常见后处理
- `references/smplx-upper-body.md` — 上半身简化的关节定义
- `references/camera-trajectory.md` — 各种相机轨迹方案对比
