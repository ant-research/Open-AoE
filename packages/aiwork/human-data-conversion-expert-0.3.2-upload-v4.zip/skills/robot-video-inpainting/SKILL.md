---
name: robot-video-inpainting
description: 视频层机器人化的三步方法：人手/人臂分割（SAM2 或关键点几何走廊近似）、背景 Inpainting（E2FGVI / ProPainter / Telea）、目标机器人 in-sim ego 相机渲染合成（MuJoCo）。人类数据转换专家在视觉机器人化阶段使用；产物默认仅用于人类复核，作为训练视觉数据需 QA 验证。
version: 0.2.0
activation: auto
tags:
  - segmentation
  - inpainting
  - rendering
  - robotized-video
---

# Robot Video Inpainting

## 已实现路径（openaoe_e2e ≥ 0.2.0，自包含、无 GPU 依赖）

`openaoe-robotize --episode <ep_dir> --actions <actions.npz> --profile g1_dex3 --out <dir>`
一条命令跑完下面三步（内部实现对齐 OpenAoE phantom `_run_stage3`）：

1. **分割**：MANO-FK 21 关键点凸包（膨胀）∪ 小臂几何走廊（方向 = wrist − mean(MCP5/9/17)，
   宽度 = 腕宽的 0.62→0.85 倍渐宽，ego 先验保证朝画面下缘）。
   覆盖"整条小臂 + 手"，与官方 SAM2 HandArmSegmenter 语义一致。
   ⚠️ 不要用纯 HSV 肤色连通域替代——厨房深色木纹台面与肤色不可分，会把整个台面并入 mask。
2. **Inpainting**：`cv2.inpaint(Telea, radius=7)`。大面积区域会有涂抹感，
   但走廊多覆盖的背景会被机器人手臂遮回。
3. **渲染合成**：G1 整机站立（qpos[2]=G1_STANDING_HEIGHT），in-sim ego 相机
   置于双肩中点 +[0.12, 0, 0.12]、fovy 由真实内参计算、朝向双腕中点；
   隐藏头部 geoms；segmentation 通道取机器人 mask；compose 走
   bleed 外延 → defringe → LAB 色彩调和（SceneStatsEMA 防闪烁）→ 羽化 alpha。

产物：`robotized.mp4`（合成）+ `sixgrid.mp4`（六联对比）+ 两张静态帧 + `robotize_summary.json`。

## 三步方法（重量级首选，效果上限更高）

### 1. 分割
- **首选**：SAM2，视频级 propagation，时序自洽（官方用关键点投影作为 point prompt）。
- **退路（已实现）**：上述关键点几何走廊，无需 GPU/torch。
- **产物**：per-frame binary mask（0=背景，1=人手/人臂）。

### 2. Inpainting
- **首选**：E2FGVI 或 ProPainter，时序一致性好。
- **退路（已实现）**：Telea 单帧修复；静态背景可用时序中值填充；动态背景不建议 fallback。
- **验收**：抽帧看边缘无鬼影、连续 3 秒无闪烁。

### 3. 机器人渲染
- 从 Retarget 阶段拿到机器人动作 + 相机轨迹。
- 渲染引擎：MuJoCo（快、无 shader，已实现）/ Rerun（可视化友好）/ Isaac（真实感强）。
- 合成：先渲染机器人（含 alpha/segmask），叠到 Inpainting 背景上；处理阴影与光照一致性。

## 六格对比视频

交付时常要求生成六格对比：

```
+---------------+---------------+---------------+
| 原始 Ego      | 外部视角机器人 | 关键点         |
+---------------+---------------+---------------+
| 手部分割       | 背景 Inpainting| 机器人合成     |
+---------------+---------------+---------------+
```

命令模板：见 `scripts/render_6grid.sh`（脚本副本源自 OpenAoE `aoe-reconstruct-retarget/phantom/`，遵循 Apache 2.0）。

## 质量判定

| 项 | 通过 | 可接受 | 不通过 |
| --- | --- | --- | --- |
| 时序一致性 | 无闪烁 | 局部微闪 | 明显闪烁 |
| 边缘 | 无残留 | 轻微残留 | 明显鬼影 |
| 光照一致 | 阴影自然 | 略突兀 | 明显割裂 |

**任何一项"不通过"**：`usable_for_training` 保持 `requires_qa_validation`，并建议跳过步 6。

## References

- `references/sam2-usage.md` — SAM2 视频分割实操
- `references/e2fgvi-propainter.md` — 两种 Inpainting 的差异

## Scripts（脚本副本，Apache-2.0）

- `scripts/render_6grid.sh` — 六格对比生成
- `scripts/segment_video.py` — SAM2 分割命令包装
- `scripts/inpaint_video.py` — E2FGVI/ProPainter 命令包装
