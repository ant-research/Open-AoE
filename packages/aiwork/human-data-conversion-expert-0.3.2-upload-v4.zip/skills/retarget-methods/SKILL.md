---
name: retarget-methods
description: Human-to-Robot 动作重映射的后端方法与机器人 profile 目录。包含 IK、dex-retargeting、CasADi/IPOPT、学习式方法的适用条件、常见坑、参数建议，以及首批 5 款机器人 profile 的资产要求。人类数据转换专家 Retarget 阶段的核心 skill。
version: 0.2.0
activation: auto
tags:
  - retargeting
  - ik
  - dex-retargeting
  - casadi
---

# Retarget Methods

## 后端选型决策树

```
输入：人手/臂动作 + 机器人 profile
├─ 目标是平行夹爪
│   └─ IK（末端笛卡尔 → 关节）+ 简单夹爪开合曲线
├─ 目标是灵巧手
│   ├─ 有 MANO 参数 → dex-retargeting（Anyteleop 系列）
│   └─ 只有关键点 → 关键点直接映射 + IK 微调
├─ 目标是双臂 / 全身
│   └─ CasADi + IPOPT 优化，把关节限位、避碰、任务目标写成约束
└─ 有大量成对（人 ↔ 机器人）数据
    └─ 可选学习式 retargeting（低置信度时降回上面几种）
```

## 各后端要点

### IK
- 数值 IK（damped least squares）稳，解析 IK 快。
- **常见坑**：奇异位形附近解不唯一；用上一帧的解作 warm start。

### dex-retargeting
- 基于 keypoint 匹配 + 优化，能处理不同拓扑的灵巧手。
- **常见坑**：手型缩放系数敏感，每种手需要标定一次。

### CasADi + IPOPT
- 适合把"关节限位 + 速度上限 + 避碰 + 任务目标"打包成一个约束优化问题。
- **常见坑**：初始猜测差会不收敛；给一个 IK 解作初值。

### 学习式 retargeting
- 只在有大量成对数据时值得上。
- **常见坑**：分布外泛化差；必须监控 out-of-support 检测器。

## 首批机器人 profile

见 `references/robot_profiles/`：

- `g1_dex3_v1.md`：**G1 + Dex3 灵巧手（28 维双臂动作：双臂 14 + 双手 14）——已端到端验证**，
  使用 OpenAoE 官方 MJCF（`aoe-retarget-replay/phantom/assets/robots/g1_dex3/`），
  含已验证的 IK 配置、自动工作空间探测参数与实测误差指标。新任务默认用它。
- `g1_inspire_v1.md`（待补充）：G1 + Inspire 灵巧手，OpenAoE 官方资产在
  `phantom/assets/robots/g1_inspire/g1_mocap_29dof_with_inspire_hands.xml`
- `galbot_v1.md` / `sharpa_v1.md` / `gripper_v1.md`：规划中，资产分别在
  OpenAoE 项目库 `retarget_galbot/assets/` 与 `aoe-training-ready/gr00t_n1d7/scripts/urdf/`

每份 profile 描述：URDF/MJCF 路径、关节顺序与限位、手型定义、控制频率、控制模式、推荐 retarget backend。

## 质量指标

对 retarget 产物要求：

- 关节位置合法（在限位内），越界率 ≤ 1%。
- 一阶差分（速度）分布单峰，无 spike；spike 率 ≤ 2%。
- 二阶差分（加速度）方差在机器人物理可执行范围内。
- 若为 EEF 增量控制：增量幅度分布在物理可行区间。

## References

- `references/robot_profiles/g1_dex3_v1.md` — G1+Dex3 profile（已验证，含实测指标）

## 已验证的端到端命令（openaoe_e2e 包）

```bash
# 1) retarget：MANO hands.npz -> 14 维关节轨迹（自动探测工作空间）
python -m openaoe_e2e.retarget.run --input <ep>/ego_process/ego_hands_reconstruction/hands.npz \
    --camera <ep>/ego_process/ego_hands_reconstruction/camera_traj.npz \
    --profile g1_dex3 --hand-index 1 --out outputs/conv_g1_dex3/ep1
# 2) 真 mesh 渲染回放 + QA 图（需要 GPU 机器，MUJOCO_GL=egl）
MUJOCO_GL=egl python -m openaoe_e2e.render.run \
    --actions outputs/conv_g1_dex3/ep1/actions.npz --profile g1_dex3 \
    --out outputs/conv_g1_dex3/ep1/render
# 3) 打包 LeRobot v2.1 训练数据
python -m openaoe_e2e.dataset.run --episodes outputs/conv_g1_dex3/ep1 \
    --profile g1_dex3 --task "<任务描述>" --out outputs/lerobot_g1_dex3
```
