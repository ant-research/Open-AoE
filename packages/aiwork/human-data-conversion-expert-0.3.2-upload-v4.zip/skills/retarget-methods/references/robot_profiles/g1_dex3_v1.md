# Robot Profile: Unitree G1 + Dex3（v1，已验证）

本 profile 已在 OpenAoE-2000h 样例数据上完成端到端验证（retarget → 渲染回放 → LeRobot v2.1 打包），是唯一一个"跑通过"的 profile，优先使用。

## 模型资产（权威来源）

- MJCF：`g1_dex3/g1_mocap_29dof_with_dex3_hands.xml`（已随 `openaoe_e2e` 包内置，
  位于 `openaoe_e2e/robots/assets/g1_dex3/`）
- 依赖网格：`../g1_base/meshes/*.STL`（同包内置 `robots/assets/g1_base/`）
- 上游出处：OpenAoE 项目库 `aoe-retarget-replay/phantom/assets/robots/g1_dex3/`，
  与 OpenAoE 官方 retarget/遥操作栈使用同一份资产；不要用 mujoco_menagerie
  或 xr_teleoperate 的 URDF 替代（关节定义、限位、mesh 坐标系均不同）。
- 浮动基座（free joint）+ 29 DoF 身体 + 双手各 7 DoF。

## 动作布局（28 维，双臂官方对齐路径）

`[L_arm(7), R_arm(7), L_hand(7), R_hand(7)]`，与 OpenAoE phantom 官方一致：

臂（每侧 7 DoF）：
`<side>_shoulder_pitch/roll/yaw_joint, <side>_elbow_joint, <side>_wrist_roll/pitch/yaw_joint`

手（Dex3，每侧 7 DoF）：
`<side>_hand_thumb_0/1/2_joint, <side>_hand_middle_0/1_joint, <side>_hand_index_0/1_joint`

手腕 body（IK 目标）：`left_wrist_yaw_link` / `right_wrist_yaw_link`
肩部锚点 body：`left/right_shoulder_pitch_link`

## Dex3 关节符号约定（CRITICAL，镜像手）

Dex3 左右手是镜像设计，**所有屈曲关节 0 = 张开**，屈曲端符号因手/关节而异：

| 关节 | 左手 range | 右手 range |
| --- | --- | --- |
| thumb_0（对掌旋转） | [-1.047, +1.047] | [-1.047, +1.047] |
| thumb_1 | [-0.724, +1.047] | [-1.047, +0.724] |
| thumb_2 | [0, +1.745] | [-1.745, 0] |
| middle_0/1 | [-1.571, 0]（负=屈） | [0, +1.571]（正=屈） |
| index_0/1 | [-1.571, 0]（负=屈） | [0, +1.571]（正=屈） |

→ 弯曲度映射必须按"屈曲端 = |range| 较大端"逐关节定号；
统一的 `lo + c*(hi-lo)` 插值会把"张开"错映射到左手全屈端（v0.1.1 实测翻车点）。

## Retarget 管线（官方 phantom 对齐）

`openaoe-retarget --input hands.npz --profile g1_dex3 --mano-dir <MANO pkl 目录> --out <dir>`

1. MANO FK（世界系，需 MANO_LEFT/RIGHT.pkl）→ R_w2c 变换到 cam 系 21 关键点
   （sidecar `keypoints_cam` 随 actions.npz 导出，供 robotize 投影/mask 用）。
   ⚠️ 不要用 `pred_trans_cam` 直接投影：那是 MANO 根节点平移，与真实腕关节差
   ~100mm，会造成 100~350px 投影错位。
2. cam 系合成肩部先验（相机在肩下 20cm，offset y 必须为负）+ 可选 Nelder-Mead 精化。
3. cam→G1：`R_AOE_CAM_TO_G1` + p95 臂长缩放（保双手机械几何）。
4. 双臂 6D DLS-IK（位置 + 姿态，逐帧 warm-start）。
   **浮动基座模型必须用 `jnt_dofadr` 索引 Jacobian 列**（free joint 7 qpos / 6 dof，
   用 `jnt_qposadr` 会整体错位 1 列，IK 误差 ~300-600mm）。
5. Dex3 手指：21 关键点链角弯曲度 → 按上表符号约定写入 7 关节。

## 实测指标（150 帧 ego 样例，2026-09-03）

- cam→G1 scale ≈ 0.708
- IK 位置误差：mean ≈ 11~13mm，max ≈ 64~85mm（左臂更准，~4mm）
- 腕部姿态对齐校验：机器人腕系 +X/+Y 与人手关键点远端方向/掌心法向点积 ≈ 0.99

## 控制参数

- 控制频率：30 Hz（位置控制，动作为关节绝对位置，单位 rad）
- MJCF 不带相机；robotize 渲染时注入 ego 相机（见 robot-video-inpainting Skill）

## 已知限制

- 手指为关键点链角弯曲度的启发式映射，非 dex-retargeting 优化器；
  精细捏取的指型保真度有限（投产可换官方 dex-retargeting 配置 `dex3_hand_<side>.yml`）
- 无身体姿态估计：肩部用固定先验，人体移动幅度大的 episode 会有系统性偏差
