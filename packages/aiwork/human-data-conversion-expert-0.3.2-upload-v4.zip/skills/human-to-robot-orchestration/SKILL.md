---
name: human-to-robot-orchestration
description: 人类数据转换专家的编排 Skill，包含 8 步流水线 checklist、可行性判定表、机器人 profile 需求清单与最终 Dataset Manifest 契约。当人类数据转换专家（human-data-conversion-expert）需要把用户目标翻译成流水线计划、安排执行顺序、生成最终交付说明时使用。
version: 0.1.0
activation: auto
release_default: "on"
tags:
  - orchestration
  - human-to-robot
  - pipeline
---

# Human-to-Robot Orchestration

人类数据转换专家的作战手册。**常驻加载**。

## 1. 8 步流水线 checklist（每步必查）

| 步 | 执行 | 输入 | 产出 | 通过条件 |
| --- | --- | --- | --- | --- |
| 0 环境检查（硬门禁） | 专家本人 | 本机或 SSH 目标 | 环境结论（OS / GPU / execution_host） | `uname -s` = Linux 且 `nvidia-smi` 可用；否则停止本地执行，向用户索取 Linux + GPU 服务器的 SSH 信息，验证连通后所有命令在远程执行 |
| 0.5 代码与资产准备（硬门禁） | 专家本人 | 步 0 确认的执行主机 | Open-AoE 仓库（固定 git_sha）+ 目标机器人/执行器 URDF 资产 | 克隆 `https://github.com/ant-research/Open-AoE` 并固定 commit、依赖安装完成；目标 profile 的 URDF/MJCF 与 mesh 齐全且可解析；任一失败立即停止并报告 |
| 1 理解目标 | 专家本人 | 用户对话 | 目标机器人 profile + 任务描述 + 用途 | 三项全部明确，缺任一必须回问用户 |
| 2 输入检查 | 专家本人 | 原始视频/示范路径 | 数据体检报告 JSON | `feasibility ∈ {A, B, C}`；`D` 则回到 1 |
| 3 重建 | 专家本人 | 通过体检的段落 | 手/臂/身体/相机/物体 3D 关系 | 重建成功率 ≥ 阈值（默认 0.8） |
| 4 坐标与时间对齐 | 专家本人 | 重建产物 | 世界坐标 + 目标控制频率序列 | 单调时序、无丢帧告警 |
| 5 Retarget | 专家本人 | 对齐产物 + 机器人 profile | 机器人动作轨迹 | `success_ratio ≥ 0.8` 且无系统性越界 |
| 6 视觉机器人化（可选） | 专家本人 | 原视频 + 动作 + 相机 | 机器人化视频 | `usable_for_training=requires_qa_validation` |
| 7 回放 QA | 专家本人 | 动作 + 视频 + profile | QA 摘要 + 最差样本清单 | `replay_success_ratio ≥ 0.7` |
| 8 数据打包 | 专家本人 | QA 通过的数据 | 目标格式数据集 + Manifest | Manifest 完整、许可清晰 |

## 2. 可行性判定表（回答"能转到什么程度"）

| 输入类型 | 有标定 | 手部可见 | 帧率 ≥24 | 时序同步 | 结论 |
| --- | --- | --- | --- | --- | --- |
| Ego 头戴 | ✅ | ✅ | ✅ | ✅ | A |
| Ego 手机 | ❌ | ✅ | ✅ | ✅ | B（相机轨迹置信度低） |
| UMI 手持 | ✅ | n/a | ✅ | ✅ | A（EEF 直接可用） |
| 动捕 | ✅ | ✅ | ✅ | ✅ | A |
| 多相机 RGB-D | ✅ | ✅ | ✅ | ✅ | A |
| 单目普通 RGB | ❌ | 部分 | ? | ? | C，仅粗略估计 |
| 已有重建 | n/a | n/a | n/a | ✅ | 跳过 3，直接 4→5 |

## 3. 机器人 profile 需求清单

专家在启动流水线前必须确认目标机器人 profile 齐备。首批支持：

- `g1_inspire_v1`：Unitree G1 + Inspire 灵巧手
- `g1_dex3_v1`：Unitree G1 + Dex3 灵巧手
- `galbot_v1`：Galbot / Galaxea 上半身
- `sharpa_v1`：Sharpa 双臂
- `gripper_v1`：通用平行夹爪

每个 profile 需具备：URDF/MJCF、关节限位、手型定义（若有）、控制频率、控制方式（关节位置 / EEF 增量）。缺则回给用户，或建议由用户在 skill `retarget-methods/references/robot_profiles/` 下补齐。

## 4. 阶段启动清单（每进入一个阶段前自查）

开始任一阶段前，先明确以下要素再动手：

```
输入路径：<...>
目标机器人 profile：<id>
任务描述（自然语言）：<...>
时间窗：<n minutes>
期望输出契约：见专家提示词 `## 阶段产出契约`
失败回报：如遇 <具体条件>，立即停止该阶段并向用户说明
```

## 5. Dataset Manifest 契约（最终交付物）

见 `references/dataset-manifest.md`。**任何一次交付缺 Manifest 均视为未完成**。

## 6. 串行/顺序决策

- 步 0 未通过（本机非 Linux + GPU 且无可用 SSH 目标）：全流水线阻塞，不得假装执行。
- 步 0.5 未通过（Open-AoE 代码或机器人/执行器 URDF 资产未就绪）：全流水线阻塞，不得绕过。
- 步 2 未通过：全流水线阻塞。
- 步 3–5：必须串行（共享重建中间态）。
- 步 6：与步 7 的动作 QA 无先后依赖；步 6 的视频 QA 必须在步 7 内完成。
- 步 8：所有 QA 通过后单独进行。

## 7. 失败与降级

| 失败 | 降级路径 |
| --- | --- |
| 输入 feasibility=D | 不启动流水线，回报用户缺什么 |
| Retarget success_ratio < 0.5 | 换 backend 重跑一次；仍失败则降级为"仅可视化，不入训练" |
| Inpainting 质量 poor | 跳过步 6，只交付动作 + 复核视频 |
| Manifest 不完整 | 不发货，回补 provenance/许可 |

## References

- `references/dataset-manifest.md` — Dataset Manifest 字段规范
- `references/robot-profile-template.md` — 新机器人 profile 需要哪些资产
