---
name: dataset-schema-and-qa
description: 具身数据的 Schema 定义、回放 QA 规则与目标格式打包（LeRobot v2.1 / v3、RLDS、HDF5、Parquet）。包含 Dataset Manifest 契约、QA 阈值默认值、异常样本挑选算法。人类数据转换专家在 QA 与打包阶段使用。
version: 0.1.0
activation: auto
tags:
  - dataset
  - lerobot
  - rlds
  - qa
  - manifest
---

# Dataset Schema and QA

## Dataset Manifest 契约

**这是人类数据转换专家的最终交付契约**。任何一次数据交付都必须附带 `manifest.json`，字段：

```json
{
  "observation_schema": {
    "cameras": ["<name>"],
    "modalities": ["rgb" | "depth" | "tactile"],
    "resolution": [H, W],
    "fps": <int>
  },
  "state_schema": {
    "dim": <int>,
    "layout": ["arm_joints[7]", "hand_joints[15]", ...],
    "units": "rad | m | m/s | ..."
  },
  "action_schema": {
    "dim": <int>,
    "layout": [...],
    "coordinate": "joint_position | eef_pose | eef_delta",
    "delta_or_absolute": "absolute | delta",
    "units": "rad | m | ...",
    "control_hz": <int>
  },
  "task": {"language": "<描述>"},
  "timing": {"control_hz": <int>, "camera_hz": <int>, "sync": "aligned | interpolated"},
  "robot_profile": "<profile id>",
  "quality": {
    "valid_ratio": <float>,
    "smoothness_score": <float>,
    "replay_success_ratio": <float>,
    "worst_segments": [...]
  },
  "license": {"kind": "<SPDX-ish>", "training_allowed": <bool>},
  "provenance": {
    "input_hash": "sha256:...",
    "retarget_backend": "...",
    "code_version": "openaoe@<sha>",
    "config_hash": "sha256:..."
  }
}
```

## 目标格式

| 格式 | 适用 | 备注 |
| --- | --- | --- |
| LeRobot v2.1 | 与 HF LeRobot 生态兼容 | 首批默认 |
| LeRobot v3 | 大规模 / 流式 | 用户显式要求时 |
| RLDS | Open X-Embodiment 兼容 | 跨机构混训 |
| HDF5 | 企业私有链路 | 需明确 group 结构 |
| Parquet / NPZ | 轻量离线分析 | 不含视频 |

## 回放 QA 默认阈值

```yaml
action_valid_ratio: 0.95           # 关节合法帧比例
smoothness_score: 0.85             # 一阶+二阶差分综合分
replay_success_ratio: 0.80         # 仿真回放成功率
video_temporal_consistency: good   # 若启用机器人化视频
video_visual_consistency: good     # 若启用机器人化视频
```

任一项低于阈值：`usable_for_training=false`。

## 异常样本挑选算法

1. 按 `replay_success` 升序，取前 5%。
2. 按 `action_smoothness` 升序，取前 5%。
3. 按 `joint_limit_violation_count` 降序，取前 5%。
4. 三集合并集去重，最多保留 top 50 段。

每段生成对比视频（`retarget vs 回放 vs 原视频`）与原因标签。

## References

- `references/lerobot-v21.md` — LeRobot v2.1 目录结构
- `references/lerobot-v3.md` — v3 设计差异
- `references/rlds.md` — RLDS Episode 结构
- `references/manifest-template.json` — Manifest 空模板

## Scripts（Apache-2.0）

- `scripts/pack_lerobot.py` — 打包为 LeRobot v2.1
- `scripts/qa_replay.py` — 仿真回放 QA
- `scripts/pick_worst_segments.py` — 异常样本挑选
