# License

Copyright 2026 Ant Tianji Lab (OpenAoE Contributors)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this plugin except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

## Component licenses

This plugin bundles or references the following components; each retains its
own license. Consumers must respect the strictest applicable terms.

| Component | Origin | License |
| --- | --- | --- |
| Plugin code (agents, skills, manifests) | This repo | Apache-2.0 |
| Skill script copies under `skills/*/scripts/` | OpenAoE (github.com/ant-research/Open-AoE) | Apache-2.0 |
| MANO hand model | MPI / MPII license (research-only, non-commercial) | MANO License |
| SMPL-X body model | MPI / MPII license (research-only, non-commercial) | SMPL-X License |
| SAM2 checkpoints | Meta AI Apache-2.0 (weights: check upstream) | Apache-2.0 |
| E2FGVI / ProPainter checkpoints | Upstream terms | check upstream |
| Robot profiles (URDF / MJCF) | Vendor-provided | Vendor terms |
| Datasets processed by this plugin | End-user provided | End-user terms |

The presence of a component here does not grant additional rights beyond its
own license. In particular, MANO / SMPL-X weights are typically restricted to
research use; commercial applications require separate agreements with the
respective licensors.
