# Changelog · human-data-conversion-expert

All notable changes to this AiWork expert plugin will be documented here.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/); versioning follows SemVer.

## [0.3.2] — 2026-09-07

### Changed（新增「代码与资产准备」环节）
- **第 0.5 步 代码与资产准备（硬门禁）**：专家提示词与 `human-to-robot-orchestration` Skill 在环境检查（第 0 步）通过之后、执行 demo 之前，新增代码与资产准备环节——从 `https://github.com/ant-research/Open-AoE` 克隆代码并固定 `git_sha`、安装依赖；按目标机器人 profile 拉取机器人本体与执行器（灵巧手/夹爪）URDF/MJCF 及 mesh 资产并逐一校验可解析；任一失败立即停止并如实报告。
- **defaultInitPrompt**：默认指令补充「环境确认可用后，先从 Open-AoE 仓库拉取代码与 URDF 资产，再执行 demo」。
- **硬性禁止** 新增：不得在代码与资产未就绪时开始 demo 或 retarget，不得绕过失败的克隆/依赖/资产校验。

## [0.3.1] — 2026-09-07

### Changed（开箱即跑默认指令 + 环境硬门禁）
- **defaultInitPrompt**：首条默认指令改为可直接运行的开箱任务——从 ModelScope 下载 OpenAoE-2000h 样例数据（https://www.modelscope.cn/datasets/inclusionAI/OpenAoE-2000h）并端到端执行转换流水线，产出机器人训练数据、复核视频与质量报告。
- **环境检查（第 0 步，硬门禁）**：专家提示词与 `human-to-robot-orchestration` Skill 新增「环境检查」环节——本包在 Linux + GPU 系统验证打包，任何执行类环节前先检查 `uname -s` 与 `nvidia-smi`；本机不适配（如 macOS）时停止本地执行，要求用户提供 Linux + GPU 服务器 SSH 信息，验证连通后所有命令在远程服务器执行。环境结论写入体检报告 `environment` 字段。
- **硬性禁止** 新增：不得跳过环境检查直接执行流水线命令，不得在本机不适配且无 SSH 目标时假装执行。

## [0.3.0] — 2026-09-07

### Changed（专家团 → 专家形态改造，功能不变）
- **产品形态**：`product.kind` 由 `expert-team` 改为 `expert`；包名由 `human-data-conversion-team` 更名为 `human-data-conversion-expert`。
- **单专家提示词**：`agents/human-data-conversion-expert.md` 合并原主专家（数据转换总监）与四位成员（数据检查员 / 重映射工程师 / 视频编辑员 / 质量分析师）的全部职责、输出契约与硬性约束；8 步流水线、可行性分级、阶段产出 JSON 契约与 Dataset Manifest 契约保持不变，由单一专家亲自端到端执行。
- **plugin.json**：`primary=human-data-conversion-expert`，`subagents=[]`。
- **manifest.json**：`display.members` 收敛为 1 位 `role=lead`；display 名称改为「人类数据转换专家 / Human-to-Robot Data Conversion Expert」；tags / quickPrompts / defaultInitPrompt 不变。
- **Skill**：5 个 Skill 全部保留，方法内容不变；仅把编排与描述文案中的"主专家/成员/委派"表述改为单专家阶段执行。
- **资产**：移除 4 张成员头像，保留并重命名专家头像 `human-data-conversion-expert.png`。
- 校验：`tools/validate_plugin.py` 未改动，两个正样本 ✅ 通过。

### Removed
- 4 份子 agent markdown（`data-input-inspector` / `retarget-engineer` / `robot-video-editor` / `data-qa-analyst`），其职责与产出契约已并入单专家提示词。

## [0.2.0] — 2026-09-03

### Fixed（配套 `openaoe_e2e-0.2.0`，机器人化效果对齐官方 phantom 可视化）
- **Dex3 手部开合反向**：Dex3 是镜像手（左手 middle/index 负=屈、右手正=屈、thumb 逐关节异号），
  旧的 `lo + c*(hi-lo)` 统一插值把"张开"错映射到左手全屈端；改为"屈曲端 = |range| 较大端"
  逐关节定号，弯曲度改用关键点链角（对遮挡/深度噪声更鲁棒）。
- **mask 只覆盖手部 → 覆盖整臂+手**：对齐官方 SAM2 HandArmSegmenter 语义，
  自包含实现为"21 关键点凸包 ∪ 小臂几何走廊"（方向 wrist−mean(MCP5/9/17)，
  延伸至出画边缘，透视渐宽 ×2）。注：HSV 肤色连通域方案已实测否决
  （厨房深色木纹台面与肤色不可分，会把台面并入 mask）。
- **六联对比布局对齐官方 visualize.py**：`[Ego | Robot(ext) | Keypoints] /
  [Mask(红色半透明叠加) | Inpaint | Composed]`，关键点配色 left=橙 / right=绿，
  新增外景机位（az=135°, el=-20°, d=2.2m）整机渲染 panel。
- inpaint 半径 5→7，配合整臂 mask 消除残留手臂与黑斑。

### Changed
- `retarget-methods` Skill：g1_dex3 profile 文档更新为 28 维双臂官方对齐布局，
  补充 Dex3 镜像关节符号表与实测指标（IK mean ≈ 11~13mm）。
- `robot-video-inpainting` Skill：新增"已实现路径"章节（自包含、无 GPU 依赖），
  重量级 SAM2/E2FGVI 保留为效果上限更高的首选路径。

## [0.1.1] — 2026-09-02

### Changed
- 成员显示名改为简明职位名：数据转换总监 / 数据检查员 / 重映射工程师 / 视频编辑员 / 质量分析师（去掉了 0.1.0 的拟人代号）。

### Added
- 配套真跑实现包 `openaoe_e2e-0.1.1`（单独交付），提供可执行 CLI：`openaoe-retarget / openaoe-render / openaoe-pack`，使本专家团可端到端产出 **training-ready 的 LeRobot v2.1 数据集 + 机器人回放视频 + QA 图**。
- 已在 Linux 服务器 + OpenAoE-2000h 样例数据上真跑验证（G1+Inspire、G1+夹爪两种目标）：IK 误差 mean 2.2mm，产出 800 帧 19 维 LeRobot v2.1 数据集。

## [0.1.0] — 2026-09-02

### Added
- 首次交付，符合《技能/专家/专家团包结构规范 V2》。
- `plugin.json`：`primary=human-data-conversion-lead`，4 个 `subagents`。
- `manifest.json`：`product.kind=expert-team`，双语（zh-CN / en-US）display，含 tags / quickPrompts / defaultInitPrompt / members。
- 5 份 agent markdown：主专家（数据转换总监）+ 4 位成员（数据检查员 / 重映射工程师 / 视频编辑员 / 质量分析师）。
- 5 个 Skill：
  - `human-to-robot-orchestration`（主专家编排）
  - `hand-body-reconstruction`（输入体检 + MANO/SMPL-X）
  - `retarget-methods`（IK / dex-retargeting / CasADi / 学习式）
  - `robot-video-inpainting`（SAM2 + E2FGVI/ProPainter + 渲染）
  - `dataset-schema-and-qa`（Manifest + LeRobot v2.1/v3 / RLDS / HDF5 / Parquet）
- 首批 5 款机器人 profile 骨架：g1_inspire / g1_dex3 / galbot / sharpa / gripper。
- `LICENSE.md`（Apache-2.0）与 `README.md`。

### Known Limits
- 首版脚本副本来自 OpenAoE 仓库，未跟随上游 CI 自动更新。
- 未包含 `commands/` 与 `hooks/`（V2 明确未生效，不得打包）。
- 未包含 `mcp.json`（v0 不引入外部 MCP Server，所有工具走 Skill scripts）。
