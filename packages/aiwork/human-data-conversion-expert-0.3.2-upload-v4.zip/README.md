# 人类数据转换专家 · Human-to-Robot Data Conversion Expert

一个 AiWork Agent Plugin（`product.kind: expert`），把第一视角视频、UMI、动捕、多相机等人类示范数据转换成目标机器人可回放、可检查、可训练的数据。

> v0.3.0 起由「专家团」（expert-team，1 主 + 4 子）改造为「专家」（expert，单一专家）：原主专家与四位成员（数据检查员 / 重映射工程师 / 视频编辑员 / 质量分析师）的职责、输出契约与硬性约束全部合并进单一专家提示词，由一位专家端到端亲自执行，功能与交付物不变。

## 专家能力

| 阶段 | 职责 |
| --- | --- |
| 流水线编排 | 8 步流水线计划、执行顺序安排、Dataset Manifest 交付 |
| 输入检查 | 输入体检、可行性判定（A/B/C/D）、许可与时序核对 |
| 重建与 Retarget | 手/臂/身重建、坐标对齐、Human-to-Robot 重映射 |
| 视觉机器人化 | 分割、Inpainting、机器人渲染 |
| 数据 QA 与打包 | 回放 QA、异常样本、LeRobot/RLDS/HDF5 格式打包 |

## 目录结构

```
human-data-conversion-expert/
├── .aiwork-plugin/
│   ├── plugin.json         # 角色声明（primary，subagents 为空）
│   └── manifest.json       # 产品形态（expert）、组件、双语展示
├── agents/                 # 1 份专家 markdown（单专家端到端）
├── skills/                 # 5 个 Skill（1 编排 + 4 方法）
│   ├── human-to-robot-orchestration/
│   ├── hand-body-reconstruction/
│   ├── retarget-methods/
│   ├── robot-video-inpainting/
│   └── dataset-schema-and-qa/
├── assets/avatars/         # 1 张专家头像 PNG
├── README.md
├── CHANGELOG.md
└── LICENSE.md
```

## 安装

见交付目录中的 `INSTALL.md`。安装后，在 AiWork 专家中心搜索"人类数据转换专家"或"Human-to-Robot Data Conversion"即可激活。

## 使用示例

- "把这批头戴相机数据转换成 G1 + Inspire 的训练数据，先用 30 秒样例验证。"
- "我只有普通 RGB 视频和目标机器人的 URDF，帮我判断能转换到什么程度。"
- "比较这段动作映射到灵巧手和平行夹爪的差异，并生成对比视频。"
- "找出关节越界或动作跳变最严重的片段，并生成 QA 报告。"

## 输入 / 输出契约

**输入**：Ego 视频 / UMI / 动捕 / 多相机 RGB(-D) / 已有重建 + 目标机器人 profile。

**输出**：机器人动作轨迹、回放视频、（可选）机器人化视频、LeRobot/RLDS/HDF5/Parquet 数据集，以及必交付的 `Dataset Manifest`（含 observation/state/action schema、坐标系、频率、绝对/增量、profile、质量、许可、血缘）。

## 依赖与许可

- 本包代码遵循 **Apache License 2.0**（见 `LICENSE.md`）。
- Skill 中的脚本副本来自 [OpenAoE](https://github.com/ant-research/Open-AoE)，同为 Apache 2.0。
- 数据、MANO / SMPL-X、第三方权重、机器人资产的许可各不相同，交付时以 Dataset Manifest 的 `license` 字段为准。
- 首批支持的机器人 profile：G1+Inspire、G1+Dex3、Galbot、Sharpa、通用平行夹爪。

## 版本

见 `CHANGELOG.md`。当前 `0.3.0`（专家团 → 专家形态改造，功能不变）。

## 校验

安装前，用仓库根的校验脚本自查：

```bash
python3 tools/validate_plugin.py plugins/human-data-conversion-expert
```

预期输出：`✅ 全部通过`。
